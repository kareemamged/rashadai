import React from 'react';
import Layout from '../../components/Layout';
import { Shield, FileText, Lock } from 'lucide-react';

const HIPAACompliance: React.FC = () => {
  return (
    <Layout>
      <div className="pt-24 pb-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          {/* Hero Section */}
          <div className="max-w-4xl mx-auto text-center mb-16">
            <h1 className="text-4xl font-bold text-gray-900 mb-6">
              HIPAA Compliance
            </h1>
            <p className="text-xl text-gray-600 leading-relaxed">
              Our commitment to protecting your health information and maintaining compliance with healthcare regulations.
            </p>
            <div className="flex justify-center mt-8">
              <span className="text-sm text-gray-500">Last Updated: May 5, 2025</span>
            </div>
          </div>

          {/* Main Content */}
          <div className="max-w-4xl mx-auto bg-white p-8 rounded-xl shadow-md mb-12">
            <div className="prose prose-lg max-w-none prose-blue">
              <section className="mb-12">
                <h2 className="flex items-center text-2xl font-bold text-gray-900 mb-4">
                  <Shield className="h-6 w-6 text-blue-600 mr-2" />
                  Our Commitment to HIPAA Compliance
                </h2>
                <p className="text-gray-700 mb-4">
                  MedAI is committed to protecting your health information and maintaining compliance with the Health Insurance Portability and Accountability Act (HIPAA) of 1996. We implement strict privacy and security measures to safeguard your Protected Health Information (PHI).
                </p>
                <p className="text-gray-700">
                  As a healthcare service provider, we understand the importance of maintaining the confidentiality, integrity, and availability of your health information. Our platform is designed with privacy and security as fundamental principles.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="flex items-center text-2xl font-bold text-gray-900 mb-4">
                  <Lock className="h-6 w-6 text-blue-600 mr-2" />
                  Security Measures
                </h2>
                <p className="text-gray-700 mb-4">
                  We employ comprehensive security measures to protect your health information:
                </p>
                <ul className="list-disc pl-6 space-y-2 text-gray-700">
                  <li>End-to-end encryption for all data transmission</li>
                  <li>Secure data storage in HIPAA-compliant facilities</li>
                  <li>Regular security audits and assessments</li>
                  <li>Access controls and authentication protocols</li>
                  <li>Employee training on HIPAA compliance</li>
                  <li>Secure backup and disaster recovery procedures</li>
                  <li>Continuous monitoring for unauthorized access attempts</li>
                </ul>
              </section>

              <section className="mb-12">
                <h2 className="flex items-center text-2xl font-bold text-gray-900 mb-4">
                  <FileText className="h-6 w-6 text-blue-600 mr-2" />
                  Your Rights Under HIPAA
                </h2>
                <p className="text-gray-700 mb-4">
                  HIPAA provides you with certain rights regarding your health information:
                </p>
                <ul className="list-disc pl-6 space-y-2 text-gray-700">
                  <li><strong>Right to Access:</strong> You have the right to view and obtain copies of your health information.</li>
                  <li><strong>Right to Amend:</strong> You can request corrections to your health information if you believe it is incorrect or incomplete.</li>
                  <li><strong>Right to an Accounting of Disclosures:</strong> You can request a list of instances where we have disclosed your health information.</li>
                  <li><strong>Right to Request Restrictions:</strong> You can ask us to limit the health information we use or share.</li>
                  <li><strong>Right to Request Confidential Communications:</strong> You can ask us to contact you in a specific way or at a specific location.</li>
                  <li><strong>Right to a Paper Copy of This Notice:</strong> You can ask for a paper copy of this notice at any time.</li>
                </ul>
              </section>

              <section className="mb-12">
                <h2 className="flex items-center text-2xl font-bold text-gray-900 mb-4">
                  <Shield className="h-6 w-6 text-blue-600 mr-2" />
                  Business Associate Agreements
                </h2>
                <p className="text-gray-700 mb-4">
                  We maintain Business Associate Agreements (BAAs) with all third-party vendors who may have access to Protected Health Information (PHI). These agreements ensure that our partners maintain the same high standards of privacy and security that we do.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="flex items-center text-2xl font-bold text-gray-900 mb-4">
                  <FileText className="h-6 w-6 text-blue-600 mr-2" />
                  Breach Notification
                </h2>
                <p className="text-gray-700 mb-4">
                  In the unlikely event of a breach of unsecured protected health information, we will:
                </p>
                <ul className="list-disc pl-6 space-y-2 text-gray-700">
                  <li>Notify affected individuals without unreasonable delay (and no later than 60 days after discovery)</li>
                  <li>Include a description of the breach, the types of information involved, steps individuals should take to protect themselves, what we are doing to investigate and mitigate the breach, and contact procedures for more information</li>
                  <li>Notify the Secretary of Health and Human Services</li>
                  <li>Notify prominent media outlets in certain circumstances</li>
                </ul>
              </section>

              <section>
                <h2 className="flex items-center text-2xl font-bold text-gray-900 mb-4">
                  <FileText className="h-6 w-6 text-blue-600 mr-2" />
                  Contact Us
                </h2>
                <p className="text-gray-700 mb-4">
                  If you have any questions about our HIPAA compliance or to report a concern:
                </p>
                <address className="text-gray-700 not-italic">
                  Privacy Officer<br />
                  MedAI, Inc.<br />
                  123 Innovation Way<br />
                  San Francisco, CA 94103<br />
                  Email: privacy@medai.com<br />
                  Phone: +1 (555) 123-4567
                </address>
              </section>
            </div>
          </div>

          {/* Additional Links */}
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-blue-50 p-6 rounded-xl">
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Privacy Policy</h3>
                <p className="text-gray-600 mb-4">Learn how we collect, use, and protect your personal information.</p>
                <a href="/privacy-policy" className="text-blue-600 hover:text-blue-800 font-medium">Read Privacy Policy →</a>
              </div>
              <div className="bg-blue-50 p-6 rounded-xl">
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Terms and Conditions</h3>
                <p className="text-gray-600 mb-4">Understand the terms governing the use of our services.</p>
                <a href="/terms" className="text-blue-600 hover:text-blue-800 font-medium">Read Terms →</a>
              </div>
              <div className="bg-blue-50 p-6 rounded-xl">
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Cookie Policy</h3>
                <p className="text-gray-600 mb-4">Details about how we use cookies on our website.</p>
                <a href="/cookies" className="text-blue-600 hover:text-blue-800 font-medium">Read Cookie Policy →</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default HIPAACompliance;
