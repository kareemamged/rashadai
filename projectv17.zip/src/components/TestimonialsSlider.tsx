import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Star, Loader } from 'lucide-react';
import { useTestimonialsStore } from '../store/testimonialsStore';
import { Link } from 'react-router-dom';

const TestimonialsSlider = () => {
  const { testimonials, isLoading, fetchTestimonials, getHighRatedTestimonials } = useTestimonialsStore();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [filteredTestimonials, setFilteredTestimonials] = useState<typeof testimonials>([]);

  // Fetch testimonials when component mounts
  useEffect(() => {
    fetchTestimonials();
  }, [fetchTestimonials]);

  // Filter testimonials with rating > 3
  useEffect(() => {
    if (testimonials.length > 0) {
      const highRated = getHighRatedTestimonials();
      setFilteredTestimonials(highRated);
    }
  }, [testimonials, getHighRatedTestimonials]);

  const nextTestimonial = () => {
    if (filteredTestimonials.length === 0) return;
    setCurrentIndex((prevIndex) => (prevIndex + 1) % filteredTestimonials.length);
  };

  const prevTestimonial = () => {
    if (filteredTestimonials.length === 0) return;
    setCurrentIndex((prevIndex) =>
      prevIndex === 0 ? filteredTestimonials.length - 1 : prevIndex - 1
    );
  };

  useEffect(() => {
    if (filteredTestimonials.length > 0) {
      const timer = setInterval(() => {
        nextTestimonial();
      }, 5000);

      return () => clearInterval(timer);
    }
  }, [filteredTestimonials.length]);

  if (isLoading) {
    return (
      <section id="testimonials" className="py-20 bg-gradient-to-b from-white to-blue-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">What Our Users Say</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Read testimonials from our satisfied users and see why they trust our AI medical consultation service.
            </p>
          </div>
          <div className="flex justify-center">
            <Loader className="w-8 h-8 animate-spin text-blue-600" />
          </div>
        </div>
      </section>
    );
  }

  if (filteredTestimonials.length === 0) {
    return null;
  }

  return (
    <section id="testimonials" className="py-20 bg-gradient-to-b from-white to-blue-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">What Our Users Say</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Read testimonials from our satisfied users and see why they trust our AI medical consultation service.
          </p>
        </div>

        <div className="max-w-4xl mx-auto relative">
          <div className="overflow-hidden">
            <div
              className="flex transition-transform duration-500 ease-in-out"
              style={{
                transform: `translateX(-${currentIndex * 100}%)`,
              }}
            >
              {filteredTestimonials.map((testimonial) => (
                <div
                  key={testimonial.id}
                  className="w-full flex-shrink-0 px-4"
                >
                  <div className="bg-white rounded-xl shadow-lg p-8">
                    <div className="flex items-center mb-6">
                      <img
                        src={testimonial.image_url}
                        alt={testimonial.user_name}
                        className="w-16 h-16 rounded-full object-cover"
                        onError={(e) => {
                          // If image fails to load, use a default avatar
                          (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(testimonial.user_name)}&background=random`;
                        }}
                      />
                      <div className="ml-4">
                        <h3 className="font-semibold text-lg">
                          {testimonial.user_name}
                        </h3>
                        <p className="text-gray-600">{testimonial.role}</p>
                        <div className="flex mt-1">
                          {[...Array(testimonial.rating)].map((_, i) => (
                            <Star
                              key={i}
                              className="w-4 h-4 text-yellow-400 fill-current"
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                    <p className="text-gray-700 text-lg leading-relaxed">
                      {testimonial.content}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {filteredTestimonials.length > 1 && (
            <>
              <button
                onClick={prevTestimonial}
                className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 bg-white p-2 rounded-full shadow-lg text-blue-600 hover:text-blue-700 focus:outline-none"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>

              <button
                onClick={nextTestimonial}
                className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 bg-white p-2 rounded-full shadow-lg text-blue-600 hover:text-blue-700 focus:outline-none"
              >
                <ChevronRight className="w-6 h-6" />
              </button>

              <div className="flex justify-center mt-8 gap-2">
                {filteredTestimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentIndex(index)}
                    className={`w-2 h-2 rounded-full transition-all duration-300 ${
                      currentIndex === index
                        ? 'bg-blue-600 w-4'
                        : 'bg-blue-200'
                    }`}
                  />
                ))}
              </div>
            </>
          )}
        </div>

        <div className="text-center mt-12">
          <Link
            to="/testimonials"
            className="inline-flex items-center text-blue-600 hover:text-blue-800 font-medium"
          >
            View all testimonials
            <ChevronRight className="w-4 h-4 ml-1" />
          </Link>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSlider;