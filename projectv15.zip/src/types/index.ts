export interface Post {
  id: string;
  title: string;
  summary: string;
  content: string;
  category: 'news' | 'tip';
  publishedDate: string;
  imageUrl?: string;
  author: {
    name: string;
    avatarUrl?: string;
  };
}

export interface Comment {
  id: string;
  postId: string;
  author: string;
  content: string;
  createdAt: string;
}