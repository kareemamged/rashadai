import React, { useState, useRef, useEffect } from 'react';
import { Send, Loader, Copy, ThumbsUp, ThumbsDown, RefreshCw, Edit, User, Bot, ArrowLeft, Paperclip, Mic, Square, Check, ThumbsUpFill, ThumbsDownFill } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { useConsultationStore } from '../store/consultationStore';
import TypingEffect from '../components/TypingEffect';

const Chat = () => {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const { 
    messages, 
    isLoading, 
    isTyping, 
    typingMessage, 
    sendMessage,
    completeTyping,
    stopTyping 
  } = useConsultationStore();
  const [input, setInput] = useState('');
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  
  // إضافة متغيرات حالة للأزرار التفاعلية
  const [likedMessages, setLikedMessages] = useState<Set<string>>(new Set());
  const [dislikedMessages, setDislikedMessages] = useState<Set<string>>(new Set());
  const [copiedMessageId, setCopiedMessageId] = useState<string | null>(null);

  // إزالة متغير showActions لأننا سنعرض الأزرار دائمًا
  // const [showActions, setShowActions] = useState<string | null>(null);

  // إزالة دالة toggleMessageActions لأننا لن نحتاجها بعد الآن
  // const toggleMessageActions = (messageId: string | null) => {
  //   setShowActions(messageId);
  // };

  // إضافة متغيرات حالة للملفات
  const [attachments, setAttachments] = useState<File[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // دالة لمعالجة اختيار الملفات
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newFiles = Array.from(e.target.files);
      setAttachments(prev => [...prev, ...newFiles]);
    }
  };

  // دالة لإزالة ملف مرفق
  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!input.trim() && attachments.length === 0) || isLoading || isTyping) return;

    try {
      await sendMessage(input, attachments);
      setInput('');
      setAttachments([]);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  // دالة للتعامل مع زر الإعجاب
  const handleLike = (messageId: string) => {
    setLikedMessages(prev => {
      const newSet = new Set(prev);
      if (newSet.has(messageId)) {
        newSet.delete(messageId);
      } else {
        newSet.add(messageId);
        // إزالة الرسالة من قائمة عدم الإعجاب إذا كانت موجودة
        setDislikedMessages(prevDislikes => {
          const newDislikes = new Set(prevDislikes);
          newDislikes.delete(messageId);
          return newDislikes;
        });
      }
      return newSet;
    });
  };

  // دالة للتعامل مع زر عدم الإعجاب
  const handleDislike = (messageId: string) => {
    setDislikedMessages(prev => {
      const newSet = new Set(prev);
      if (newSet.has(messageId)) {
        newSet.delete(messageId);
      } else {
        newSet.add(messageId);
        // إزالة الرسالة من قائمة الإعجاب إذا كانت موجودة
        setLikedMessages(prevLikes => {
          const newLikes = new Set(prevLikes);
          newLikes.delete(messageId);
          return newLikes;
        });
      }
      return newSet;
    });
  };

  // دالة محسنة للنسخ مع تأثير بصري
  const handleCopy = (content: string, messageId: string) => {
    navigator.clipboard.writeText(content).then(() => {
      setCopiedMessageId(messageId);
      setTimeout(() => {
        setCopiedMessageId(null);
      }, 2000); // إعادة أيقونة النسخ بعد ثانيتين
    });
  };

  const handleEdit = (message: any) => {
    setEditingMessageId(message.id);
    setEditText(message.content);
    setTimeout(() => {
      const textarea = document.querySelector('textarea');
      if (textarea) {
        textarea.focus();
        textarea.setSelectionRange(textarea.value.length, textarea.value.length);
      }
    }, 0);
  };

  const handleSaveEdit = async () => {
    if (!editText.trim() || editingMessageId === null) return;
    
    try {
      await sendMessage(editText);
      setEditingMessageId(null);
      setEditText('');
    } catch (error) {
      console.error('Error updating message:', error);
    }
  };

  const handleCancelEdit = () => {
    setEditingMessageId(null);
    setEditText('');
  };

  const handleRegenerate = async (userMessageId: string) => {
    const messageIndex = messages.findIndex(m => m.id === userMessageId);
    if (messageIndex === -1) return;
    
    const userMessage = messages[messageIndex];
    
    try {
      await sendMessage(userMessage.content);
    } catch (error) {
      console.error('Error regenerating response:', error);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const autoGrowTextArea = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const textarea = e.target;
    textarea.style.height = 'auto';
    textarea.style.height = `${Math.min(textarea.scrollHeight, 120)}px`;
  };

  // إزالة دالة toggleMessageActions لأننا لن نحتاجها بعد الآن
  // const toggleMessageActions = (id: string) => {
  //   setShowActions(showActions === id ? null : id);
  // };

  const formatMessageTime = (date: Date) => {
    return new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const goBack = () => {
    navigate('/');
  };

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-blue-50 to-white">
      {/* Chat header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4 shadow-sm flex items-center">
        <button 
          onClick={goBack}
          className="mr-4 p-2 rounded-full hover:bg-gray-100 transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-gray-600" />
        </button>
        <div className="flex items-center">
          <div className="bg-blue-100 p-2 rounded-full">
            <Bot className="h-6 w-6 text-blue-600" />
          </div>
          <div className="ml-3">
            <h1 className="text-lg font-semibold text-gray-800">Medical Assistant</h1>
            <div className="flex items-center">
              <span className="h-2 w-2 bg-green-500 rounded-full mr-2"></span>
              <span className="text-xs text-gray-500">Online</span>
            </div>
          </div>
        </div>
      </div>

      {/* Messages container */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4">
        {/* Welcome message */}
        {messages.length === 0 && !isTyping && !isLoading && (
          <div className="flex flex-col items-center justify-center h-full text-center px-4">
            <div className="bg-blue-100 p-4 rounded-full mb-4">
              <Bot className="h-10 w-10 text-blue-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-2">Welcome to Medical Consultation</h2>
            <p className="text-gray-600 mb-6 max-w-md">
              I'm your AI medical assistant. Please describe your symptoms or ask any health-related questions.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-w-lg w-full">
              {[
                "What are the symptoms of COVID-19?",
                "I have a persistent headache for 3 days",
                "What causes high blood pressure?",
                "How can I improve my sleep quality?"
              ].map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => setInput(suggestion)}
                  className="bg-white border border-gray-300 rounded-lg px-4 py-2 text-sm text-left hover:bg-gray-50 transition-colors"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((message, index) => (
          <div
            key={message.id}
            className={`flex ${message.isAi ? 'justify-start' : 'justify-end'} group`}
            // إزالة أحداث onMouseEnter و onMouseLeave
          >
            <div className={`flex items-start max-w-[85%] md:max-w-[75%] ${message.isAi ? 'flex-row' : 'flex-row-reverse'}`}>
              {/* Avatar */}
              <div className={`flex-shrink-0 ${message.isAi ? 'mr-3' : 'ml-3'} mt-1`}>
                <div className={`rounded-full flex items-center justify-center w-8 h-8 ${
                  message.isAi ? 'bg-blue-100' : 'bg-blue-600'
                }`}>
                  {message.isAi ? 
                    <Bot className="h-5 w-5 text-blue-600" /> : 
                    <User className="h-5 w-5 text-white" />
                  }
                </div>
              </div>

              {/* Message content */}
              <div className="flex flex-col">
                <div
                  className={`rounded-2xl px-4 py-3 shadow-sm ${
                    message.isAi
                      ? 'bg-white border border-gray-200 rounded-tl-none'
                      : 'bg-blue-600 text-white rounded-tr-none'
                  }`}
                >
                  {editingMessageId === message.id ? (
                    <div className="flex flex-col space-y-2">
                      <textarea
                        value={editText}
                        onChange={(e) => {
                          setEditText(e.target.value);
                          autoGrowTextArea(e);
                        }}
                        className="w-full p-2 text-gray-800 bg-white border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        rows={3}
                        ref={inputRef}
                      />
                      <div className="flex justify-end space-x-2">
                        <button
                          onClick={handleCancelEdit}
                          className="px-3 py-1 text-xs bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 transition-colors"
                        >
                          Cancel
                        </button>
                        <button
                          onClick={handleSaveEdit}
                          className="px-3 py-1 text-xs bg-blue-500 text-white rounded-md hover:bg-blue-600 transition-colors"
                        >
                          Save
                        </button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <p className={`text-sm whitespace-pre-wrap ${message.isAi ? 'text-gray-800' : 'text-white'}`}>
                        {message.content}
                      </p>
                      <span className={`text-xs ${message.isAi ? 'text-gray-500' : 'text-blue-100'} mt-1 block text-right`}>
                        {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </>
                  )}
                </div>
                
                {/* عرض المرفقات في الرسائل */}
                {message.attachments && message.attachments.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-2">
                    {message.attachments.map((attachment) => (
                      <div 
                        key={attachment.id} 
                        className="relative border rounded-md overflow-hidden"
                      >
                        {attachment.type.startsWith('image/') ? (
                          <img 
                            src={attachment.preview || attachment.url} 
                            alt={attachment.name}
                            className="h-24 w-auto object-cover"
                          />
                        ) : (
                          <div className="flex items-center p-2 bg-gray-100">
                            <Paperclip className="w-4 h-4 mr-2" />
                            <span className="text-xs truncate max-w-[100px]">{attachment.name}</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
                
                {/* Message actions - always visible with improved UI/UX */}
                <div className={`flex mt-2 space-x-1 ${message.isAi ? 'justify-start' : 'justify-end'}`}>
                  {message.isAi ? (
                    <>
                      <button 
                        onClick={() => handleCopy(message.content, message.id)}
                        className={`p-1.5 bg-white rounded-full shadow-sm transition-all duration-300 transform hover:scale-110 ${
                          copiedMessageId === message.id 
                            ? 'text-green-600 bg-green-50' 
                            : 'text-gray-600 hover:bg-gray-100'
                        }`}
                        title={copiedMessageId === message.id ? "Copied!" : "Copy"}
                      >
                        {copiedMessageId === message.id ? <Check size={14} /> : <Copy size={14} />}
                      </button>
                      <button 
                        onClick={() => handleRegenerate(messages[index - 1]?.id)}
                        className="p-1.5 bg-white text-gray-600 rounded-full hover:bg-gray-100 transition-all duration-300 transform hover:scale-110 shadow-sm"
                        title="Regenerate"
                      >
                        <RefreshCw size={14} className="hover:rotate-180 transition-transform duration-500" />
                      </button>
                      <button 
                        onClick={() => handleLike(message.id)}
                        className={`p-1.5 rounded-full shadow-sm transition-all duration-300 transform hover:scale-110 ${
                          likedMessages.has(message.id)
                            ? 'bg-green-50 text-green-600' 
                            : 'bg-white text-gray-600 hover:bg-gray-100'
                        }`}
                        title={likedMessages.has(message.id) ? "Liked" : "Like"}
                      >
                        {likedMessages.has(message.id) ? (
                          <ThumbsUp size={14} fill="currentColor" />
                        ) : (
                          <ThumbsUp size={14} />
                        )}
                      </button>
                      <button 
                        onClick={() => handleDislike(message.id)}
                        className={`p-1.5 rounded-full shadow-sm transition-all duration-300 transform hover:scale-110 ${
                          dislikedMessages.has(message.id)
                            ? 'bg-red-50 text-red-600' 
                            : 'bg-white text-gray-600 hover:bg-gray-100'
                        }`}
                        title={dislikedMessages.has(message.id) ? "Disliked" : "Dislike"}
                      >
                        {dislikedMessages.has(message.id) ? (
                          <ThumbsDown size={14} fill="currentColor" />
                        ) : (
                          <ThumbsDown size={14} />
                        )}
                      </button>
                    </>
                  ) : (
                    <>
                      <button 
                        onClick={() => handleEdit(message)}
                        className="p-1.5 bg-white text-gray-600 rounded-full hover:bg-gray-100 transition-all duration-300 transform hover:scale-110 shadow-sm"
                        title="Edit"
                      >
                        <Edit size={14} />
                      </button>
                      <button 
                        onClick={() => handleCopy(message.content, message.id)}
                        className={`p-1.5 bg-white rounded-full shadow-sm transition-all duration-300 transform hover:scale-110 ${
                          copiedMessageId === message.id 
                            ? 'text-green-600 bg-green-50' 
                            : 'text-gray-600 hover:bg-gray-100'
                        }`}
                        title={copiedMessageId === message.id ? "Copied!" : "Copy"}
                      >
                        {copiedMessageId === message.id ? <Check size={14} /> : <Copy size={14} />}
                      </button>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
        
        {/* Typing effect */}
        {isTyping && typingMessage && (
          <div className="flex justify-start">
            <div className="flex items-start max-w-[85%] md:max-w-[75%]">
              <div className="flex-shrink-0 mr-3 mt-1">
                <div className="bg-blue-100 rounded-full flex items-center justify-center w-8 h-8">
                  <Bot className="h-5 w-5 text-blue-600" />
                </div>
              </div>
              <div className="bg-white border border-gray-200 rounded-2xl rounded-tl-none px-4 py-3 shadow-sm">
                <TypingEffect 
                  text={typingMessage} 
                  onComplete={completeTyping}
                  className="text-sm text-gray-800 whitespace-pre-wrap"
                />
              </div>
            </div>
          </div>
        )}
        
        {/* Loading indicator */}
        {isLoading && (
          <div className="flex justify-start">
            <div className="flex items-start">
              <div className="flex-shrink-0 mr-3 mt-1">
                <div className="bg-blue-100 rounded-full flex items-center justify-center w-8 h-8">
                  <Bot className="h-5 w-5 text-blue-600" />
                </div>
              </div>
              <div className="bg-white border border-gray-200 rounded-2xl rounded-tl-none px-6 py-4 shadow-sm">
                <div className="flex space-x-2">
                  <div className="w-2 h-2 rounded-full bg-gray-300 animate-bounce" style={{ animationDelay: '0ms' }}></div>
                  <div className="w-2 h-2 rounded-full bg-gray-300 animate-bounce" style={{ animationDelay: '150ms' }}></div>
                  <div className="w-2 h-2 rounded-full bg-gray-300 animate-bounce" style={{ animationDelay: '300ms' }}></div>
                </div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Input form */}
      <div className="border-t border-gray-200 bg-white p-4">
        <form onSubmit={handleSubmit} className="max-w-4xl mx-auto">
          <div className="relative flex items-end bg-gray-50 rounded-2xl border border-gray-300 focus-within:border-blue-400 focus-within:ring-2 focus-within:ring-blue-100 transition-all">
            <textarea
              value={input}
              onChange={(e) => {
                setInput(e.target.value);
                autoGrowTextArea(e);
              }}
              onKeyDown={handleKeyDown}
              placeholder="Type your medical question..."
              className="flex-1 px-4 py-3 bg-transparent border-none focus:outline-none resize-none min-h-[50px] max-h-[120px] text-gray-700"
              disabled={isLoading || isTyping}
              style={{ height: '50px' }}
            />
            
            <div className="flex items-center px-3 py-2">
              {/* تحديث زر المرفقات ليفتح مربع اختيار الملفات */}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="p-2 text-gray-500 rounded-full hover:bg-gray-200 transition-colors mr-1"
                title="Attach file"
              >
                <Paperclip className="w-5 h-5" />
              </button>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileSelect}
                className="hidden"
                multiple
                accept="image/*,.pdf,.doc,.docx,.txt"
              />
              <button
                type="button"
                className="p-2 text-gray-500 rounded-full hover:bg-gray-200 transition-colors mr-1"
                title="Voice input"
              >
                <Mic className="w-5 h-5" />
              </button>
              
              {/* زر الإرسال مع زر إيقاف الكتابة فوقه */}
              <div className="relative">
                {/* زر إيقاف الكتابة - يظهر فقط عندما يكون الذكاء الاصطناعي يكتب */}
                {isTyping && (
                  <button
                    type="button"
                    onClick={stopTyping}
                    className="absolute inset-0 bg-red-500 text-white p-2 rounded-full hover:bg-red-600 transition-colors z-10"
                    title="Stop AI response"
                  >
                    <Square className="w-5 h-5" />
                  </button>
                )}
                
                {/* زر الإرسال */}
                <button
                  type="submit"
                  disabled={isLoading || isTyping || !input.trim()}
                  className="bg-blue-600 text-white p-2 rounded-full hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  title="Send message"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
          
          <div className="mt-2 text-xs text-gray-500 text-center">
            <p>This AI assistant provides general medical information only. Always consult a healthcare professional for medical advice.</p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Chat;













