import React, { useState } from 'react';
import { Star, Loader } from 'lucide-react';
import Layout from '../components/Layout';

interface Testimonial {
  id: string;
  user_name: string;
  role: string;
  content: string;
  rating: number;
  image_url: string;
  created_at: string;
}

const staticTestimonials: Testimonial[] = [
  {
    id: '1',
    user_name: 'Sarah Johnson',
    role: 'Patient',
    content: 'The AI consultation was surprisingly accurate. It identified my condition when I had been misdiagnosed twice before.',
    rating: 5,
    image_url: 'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg',
    created_at: new Date().toISOString()
  },
  {
    id: '2',
    user_name: 'Michael Chen',
    role: 'Healthcare Professional',
    content: 'As a doctor, I was skeptical at first. But this platform has become an invaluable tool in my practice.',
    rating: 5,
    image_url: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg',
    created_at: new Date().toISOString()
  },
  {
    id: '3',
    user_name: 'Emily Rodriguez',
    role: 'Parent',
    content: 'When my daughter developed a rash at midnight, I was able to get immediate guidance without an emergency room visit.',
    rating: 4,
    image_url: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg',
    created_at: new Date().toISOString()
  }
];

const TestimonialsPage = () => {
  const [testimonials] = useState<Testimonial[]>(staticTestimonials);
  const [newTestimonial, setNewTestimonial] = useState({
    user_name: '',
    role: '',
    content: '',
    rating: 5,
    image_url: ''
  });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    setSuccess('');

    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      setSuccess('Thank you for your testimonial! It will be reviewed and published soon.');
      setNewTestimonial({
        user_name: '',
        role: '',
        content: '',
        rating: 5,
        image_url: ''
      });
    } catch (err) {
      setError('Failed to submit testimonial. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-4xl font-bold text-gray-900 mb-8 text-center">Client Testimonials</h1>

            <div className="bg-white rounded-xl shadow-lg p-8 mb-12">
              <h2 className="text-2xl font-semibold mb-6">Share Your Experience</h2>
              
              {error && (
                <div className="bg-red-50 text-red-600 p-4 rounded-lg mb-6">
                  {error}
                </div>
              )}
              
              {success && (
                <div className="bg-green-50 text-green-600 p-4 rounded-lg mb-6">
                  {success}
                </div>
              )}

              <form onSubmit={handleSubmit}>
                <div className="mb-4">
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Name
                  </label>
                  <input
                    type="text"
                    value={newTestimonial.user_name}
                    onChange={(e) => setNewTestimonial({...newTestimonial, user_name: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Role
                  </label>
                  <input
                    type="text"
                    value={newTestimonial.role}
                    onChange={(e) => setNewTestimonial({...newTestimonial, role: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                    placeholder="e.g., Patient, Healthcare Professional"
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Your Experience
                  </label>
                  <textarea
                    value={newTestimonial.content}
                    onChange={(e) => setNewTestimonial({...newTestimonial, content: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    rows={4}
                    required
                  />
                </div>

                <div className="mb-6">
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Rating
                  </label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setNewTestimonial({...newTestimonial, rating: star})}
                        className="focus:outline-none"
                      >
                        <Star
                          className={`w-8 h-8 ${
                            star <= newTestimonial.rating
                              ? 'text-yellow-400 fill-current'
                              : 'text-gray-300'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {submitting ? (
                    <span className="flex items-center justify-center">
                      <Loader className="w-5 h-5 animate-spin mr-2" />
                      Submitting...
                    </span>
                  ) : (
                    'Submit Testimonial'
                  )}
                </button>
              </form>
            </div>

            <div className="space-y-6">
              {testimonials.map((testimonial) => (
                <div
                  key={testimonial.id}
                  className="bg-white rounded-xl shadow-md p-6 transition-transform duration-300 hover:-translate-y-1"
                >
                  <div className="flex items-center mb-4">
                    <img
                      src={testimonial.image_url}
                      alt={testimonial.user_name}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    <div className="ml-4">
                      <h3 className="font-semibold">{testimonial.user_name}</h3>
                      <p className="text-gray-600 text-sm">{testimonial.role}</p>
                      <div className="flex mt-1">
                        {[...Array(testimonial.rating)].map((_, i) => (
                          <Star
                            key={i}
                            className="w-4 h-4 text-yellow-400 fill-current"
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                  <p className="text-gray-700">{testimonial.content}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default TestimonialsPage;