import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { getDefaultCountry } from '../data/countries';
import {
  signUpWithEmail,
  signInWithEmail,
  signOut as supabaseSignOut,
  getCurrentUser,
  updateUserProfile,
  updateUserPassword,
  setupAuthListener,
  uploadAvatar,
  getUserProfile,
  updateProfile as updateSupabaseProfile
} from '../lib/supabase';

export interface User {
  id: string;
  email: string;
  created_at: string;
  name?: string;
  avatar?: string;
  country_code?: string;
  phone?: string;
  bio?: string;
  language?: string;
  updated_at?: string;
  website?: string;
  gender?: string;
  birth_date?: string;
  profession?: string;
}

interface AuthState {
  user: User | null;
  isLoading: boolean;
  signUp: (email: string, password: string, countryCode?: string, name?: string) => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  checkAuth: () => Promise<void>;
  updateProfile: (userData: Partial<User>) => Promise<void>;
  updatePassword: (currentPassword: string, newPassword: string) => Promise<void>;
  uploadProfileImage: (file: File) => Promise<string>;
  setUser: (user: User | null) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isLoading: false,

      setUser: (user) => {
        set({ user });
      },

      signUp: async (email: string, password: string, countryCode?: string, name?: string) => {
        set({ isLoading: true });
        try {
          // Prepare user metadata
          const userData = {
            country_code: countryCode || getDefaultCountry().code,
            name: name || email.split('@')[0],
            avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(name || email.split('@')[0])}&background=random`,
            language: 'ar'
          };

          // Sign up with Supabase
          const { user } = await signUpWithEmail(email, password, userData);

          if (user) {
            const newUser: User = {
              id: user.id,
              email: user.email || email,
              created_at: user.created_at,
              ...userData
            };

            set({ user: newUser });
          }
        } catch (error) {
          console.error('Signup error:', error);
          throw error;
        } finally {
          set({ isLoading: false });
        }
      },

      signIn: async (email: string, password: string) => {
        set({ isLoading: true });
        try {
          // Sign in with Supabase
          const { user } = await signInWithEmail(email, password);

          if (user) {
            // Get user metadata
            const userData = user.user_metadata;

            const loggedInUser: User = {
              id: user.id,
              email: user.email || email,
              created_at: user.created_at,
              name: userData?.name || email.split('@')[0],
              avatar: userData?.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(email.split('@')[0])}&background=random`,
              country_code: userData?.country_code || getDefaultCountry().code,
              phone: userData?.phone,
              bio: userData?.bio,
              language: userData?.language || 'ar'
            };

            set({ user: loggedInUser });
          }
        } catch (error) {
          console.error('Login error:', error);
          throw error;
        } finally {
          set({ isLoading: false });
        }
      },

      signOut: async () => {
        set({ isLoading: true });
        try {
          await supabaseSignOut();
          set({ user: null });
        } catch (error) {
          console.error('Signout error:', error);
          throw error;
        } finally {
          set({ isLoading: false });
        }
      },

      checkAuth: async () => {
        set({ isLoading: true });
        try {
          const user = await getCurrentUser();

          if (user) {
            // Get user metadata from auth
            const userData = user.user_metadata || {};
            console.log('User metadata from auth:', userData);

            try {
              // Try to get additional profile data from profiles table
              const profileData = await getUserProfile(user.id);
              console.log('Profile data from profiles table:', profileData);

              // Create a complete user object with all available fields
              const loggedInUser: User = {
                id: user.id,
                email: user.email || '',
                created_at: user.created_at,
                // Combine data from auth and profiles table, with profiles taking precedence
                name: profileData?.name || userData?.name,
                avatar: profileData?.avatar || userData?.avatar,
                country_code: profileData?.country_code || userData?.country_code,
                phone: profileData?.phone || userData?.phone,
                bio: profileData?.bio || userData?.bio,
                language: profileData?.language || userData?.language,
                updated_at: profileData?.updated_at,
                website: profileData?.website,
                gender: profileData?.gender,
                birth_date: profileData?.birth_date,
                profession: profileData?.profession
              };

              // Log the complete user object for debugging
              console.log('Complete user object:', loggedInUser);

              // Update the user state
              set({ user: loggedInUser });

              // If we got data from auth but not from profiles table, try to create a profile
              if (Object.keys(profileData || {}).length === 0 && Object.keys(userData).length > 0) {
                console.log('Creating profile from auth metadata...');
                try {
                  await updateSupabaseProfile(user.id, {
                    id: user.id,
                    email: user.email,
                    name: userData.name,
                    avatar: userData.avatar,
                    country_code: userData.country_code,
                    phone: userData.phone,
                    bio: userData.bio,
                    language: userData.language,
                    created_at: user.created_at,
                    updated_at: new Date().toISOString()
                  });
                } catch (createError) {
                  console.error('Failed to create profile from auth metadata:', createError);
                }
              }
            } catch (profileError) {
              // If profile doesn't exist yet, just use auth data
              console.log('Profile not found, using auth data only:', profileError);

              const loggedInUser: User = {
                id: user.id,
                email: user.email || '',
                created_at: user.created_at,
                name: userData?.name,
                avatar: userData?.avatar,
                country_code: userData?.country_code,
                phone: userData?.phone,
                bio: userData?.bio,
                language: userData?.language
              };

              set({ user: loggedInUser });
            }
          }
        } catch (error) {
          console.error('Check auth error:', error);
          set({ user: null });
        } finally {
          set({ isLoading: false });
        }
      },

      updateProfile: async (userData: Partial<User>) => {
        const currentUser = get().user;
        if (!currentUser) return;

        set({ isLoading: true });
        try {
          // If name is updated, update avatar as well (if no custom avatar)
          if (userData.name && !userData.avatar && !currentUser.avatar?.includes('http')) {
            userData.avatar = `https://ui-avatars.com/api/?name=${encodeURIComponent(userData.name)}&background=random`;
          }

          // Create a complete profile data object with all fields
          const completeProfileData = {
            id: currentUser.id,
            email: currentUser.email,
            name: userData.name || currentUser.name,
            avatar: userData.avatar || currentUser.avatar,
            country_code: userData.country_code || currentUser.country_code,
            phone: userData.phone || currentUser.phone,
            bio: userData.bio || currentUser.bio,
            language: userData.language || currentUser.language,
            website: userData.website || currentUser.website,
            gender: userData.gender || currentUser.gender,
            birth_date: userData.birth_date || currentUser.birth_date,
            profession: userData.profession || currentUser.profession,
            created_at: currentUser.created_at,
            updated_at: new Date().toISOString()
          };

          // Update both auth metadata and profiles table
          // This function handles both updates and will ensure data is saved in at least one place
          const updatedData = await updateSupabaseProfile(currentUser.id, completeProfileData);

          // Log the updated data for debugging
          console.log('Profile updated successfully:', updatedData);

          // Update local state with the returned data
          const updatedUser = {
            ...currentUser,
            ...updatedData,
            updated_at: new Date().toISOString()
          };

          set({ user: updatedUser });
          return updatedUser;
        } catch (error) {
          console.error('Update profile error:', error);
          throw error;
        } finally {
          set({ isLoading: false });
        }
      },

      updatePassword: async (currentPassword: string, newPassword: string) => {
        set({ isLoading: true });
        try {
          // In a real implementation, we would first verify the current password
          // But Supabase doesn't provide a direct way to do this
          // So we'll just update the password
          await updateUserPassword(newPassword);
        } catch (error) {
          console.error('Update password error:', error);
          throw error;
        } finally {
          set({ isLoading: false });
        }
      },

      uploadProfileImage: async (file: File) => {
        const currentUser = get().user;
        if (!currentUser) throw new Error('User not authenticated');

        set({ isLoading: true });
        try {
          // Import image compression function
          const { compressImage } = await import('../lib/imageUtils');

          // Compress image before upload
          const compressedFile = await compressImage(file);

          // Upload image to Supabase storage (or get data URL if storage fails)
          const imageUrl = await uploadAvatar(compressedFile, currentUser.id);

          // Create a complete profile data object with all fields
          const completeProfileData = {
            id: currentUser.id,
            email: currentUser.email,
            name: currentUser.name,
            avatar: imageUrl,
            country_code: currentUser.country_code,
            phone: currentUser.phone,
            bio: currentUser.bio,
            language: currentUser.language,
            website: currentUser.website,
            gender: currentUser.gender,
            birth_date: currentUser.birth_date,
            profession: currentUser.profession,
            created_at: currentUser.created_at,
            updated_at: new Date().toISOString()
          };

          // Update both auth metadata and profiles table
          // This function handles both updates and will ensure data is saved in at least one place
          await updateSupabaseProfile(currentUser.id, completeProfileData);

          // Update local state
          set({
            user: {
              ...currentUser,
              avatar: imageUrl,
              updated_at: new Date().toISOString()
            }
          });

          return imageUrl;
        } catch (error) {
          console.error('Upload profile image error:', error);

          // Don't throw the error, just return the current avatar or a default one
          return currentUser.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(currentUser.name || currentUser.email)}&background=random`;
        } finally {
          set({ isLoading: false });
        }
      }
    }),
    {
      name: 'auth-storage',
    }
  )
);

// Setup auth listener when the app loads
if (typeof window !== 'undefined') {
  setupAuthListener((user) => {
    if (user) {
      const userData = user.user_metadata;

      const loggedInUser: User = {
        id: user.id,
        email: user.email || '',
        created_at: user.created_at,
        name: userData?.name,
        avatar: userData?.avatar,
        country_code: userData?.country_code,
        phone: userData?.phone,
        bio: userData?.bio,
        language: userData?.language
      };

      useAuthStore.getState().setUser(loggedInUser);
    } else {
      useAuthStore.getState().setUser(null);
    }
  });
}