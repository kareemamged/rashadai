import { Post } from '../types';

// Sample blog posts data
export const posts: Post[] = [
  {
    id: '1',
    title: 'New AI Treatment Breakthrough',
    summary: 'Recent developments in AI-assisted medical treatments show promising results for patients with chronic conditions.',
    content: `
      <p>A groundbreaking development in AI-assisted medical treatments has shown remarkable promise for patients suffering from various chronic conditions. This innovative approach combines machine learning algorithms with traditional medical knowledge to create personalized treatment plans.</p>
      
      <p>The study, conducted over a three-year period, demonstrated a 45% improvement in patient outcomes when compared to standard treatment protocols. Researchers attribute this success to the AI's ability to analyze vast amounts of medical data and identify patterns that might be missed by human practitioners.</p>
      
      <p>"This represents a paradigm shift in how we approach chronic disease management," says Dr. Maria Chen, lead researcher on the project. "By leveraging artificial intelligence, we can create truly personalized medicine that adapts to each patient's unique needs and responses."</p>
      
      <p>The technology is currently being implemented in select hospitals across the country, with plans for wider distribution within the next two years. Patients interested in participating in ongoing trials can contact their healthcare providers for more information.</p>
      
      <p>While the results are promising, medical professionals emphasize that AI serves as a tool to enhance human medical expertise rather than replace it. The most effective applications combine technological capabilities with the nuanced understanding and empathy of trained healthcare providers.</p>
    `,
    category: 'news',
    publishedDate: '2024-05-15',
    imageUrl: 'https://images.pexels.com/photos/3825586/pexels-photo-3825586.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    author: {
      name: 'Dr. James Wilson',
      avatarUrl: 'https://images.pexels.com/photos/5452293/pexels-photo-5452293.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    }
  },
  {
    id: '2',
    title: '5 Ways to Improve Your Heart Health',
    summary: 'Simple lifestyle changes that can significantly reduce your risk of heart disease and improve overall cardiovascular health.',
    content: `
      <p>Heart disease remains one of the leading causes of death worldwide, but the good news is that many risk factors are within our control. By making these five simple lifestyle changes, you can significantly improve your heart health and reduce your risk of cardiovascular problems.</p>
      
      <h3>1. Adopt a Heart-Healthy Diet</h3>
      <p>Focus on consuming a variety of fruits, vegetables, whole grains, and lean proteins. Limit saturated fats, trans fats, sodium, and added sugars. The Mediterranean and DASH diets have been shown to be particularly beneficial for heart health.</p>
      
      <h3>2. Engage in Regular Physical Activity</h3>
      <p>Aim for at least 150 minutes of moderate-intensity aerobic exercise or 75 minutes of vigorous activity each week. Even small amounts of movement throughout the day can make a difference. Find activities you enjoy so you're more likely to stick with them.</p>
      
      <h3>3. Maintain a Healthy Weight</h3>
      <p>Excess weight, especially around the midsection, puts additional strain on your heart. Even modest weight loss can reduce this burden and improve blood pressure, cholesterol levels, and blood sugar control.</p>
      
      <h3>4. Prioritize Quality Sleep</h3>
      <p>Poor sleep quality and insufficient sleep duration are associated with increased risk of heart disease. Most adults need 7-9 hours of quality sleep each night. Establish a regular sleep schedule and create a restful environment to improve sleep quality.</p>
      
      <h3>5. Manage Stress Effectively</h3>
      <p>Chronic stress can contribute to heart disease through various mechanisms, including elevated blood pressure and inflammation. Find healthy stress management techniques that work for you, such as mindfulness, deep breathing exercises, or regular physical activity.</p>
      
      <p>Remember, it's never too late to start making heart-healthy choices. Even small changes can have significant benefits when maintained over time. Consult with your healthcare provider before making major lifestyle changes, especially if you have existing health conditions.</p>
    `,
    category: 'tip',
    publishedDate: '2024-05-10',
    imageUrl: 'https://images.pexels.com/photos/4386467/pexels-photo-4386467.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    author: {
      name: 'Dr. Sarah Johnson',
      avatarUrl: 'https://images.pexels.com/photos/5327656/pexels-photo-5327656.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    }
  },
  {
    id: '3',
    title: 'RashadAI Launches New Mobile App',
    summary: 'Our new mobile application brings AI-powered medical consultation to your smartphone, making healthcare more accessible than ever.',
    content: `
      <p>We're excited to announce the launch of our new RashadAI mobile application, designed to bring the power of AI-assisted medical consultation directly to your smartphone. This innovative app represents our commitment to making healthcare more accessible, affordable, and convenient for everyone.</p>
      
      <p>The RashadAI mobile app includes all the features you've come to expect from our web platform, optimized for a seamless mobile experience. Key features include:</p>
      
      <ul>
        <li><strong>Symptom Assessment:</strong> Describe your symptoms and receive AI-generated guidance</li>
        <li><strong>Medication Reminders:</strong> Never miss a dose with customizable medication alerts</li>
        <li><strong>Secure Health Records:</strong> Store and access your medical information safely</li>
        <li><strong>Direct Messaging:</strong> Communicate with healthcare providers through our secure platform</li>
        <li><strong>Appointment Scheduling:</strong> Book consultations with specialists with just a few taps</li>
      </ul>
      
      <p>"The launch of our mobile app represents a significant step forward in our mission to democratize healthcare," says RashadAI CEO Emma Richards. "By putting these powerful tools in people's pockets, we're helping them take control of their health in unprecedented ways."</p>
      
      <p>The app is now available for download on both iOS and Android platforms. New users can sign up for a free 30-day trial to experience the full range of premium features before deciding on a subscription plan.</p>
      
      <p>We're committed to continually improving the app based on user feedback and the latest advancements in AI and healthcare technology. Regular updates will introduce new features and enhance existing functionality to provide the best possible experience for our users.</p>
    `,
    category: 'news',
    publishedDate: '2024-05-05',
    imageUrl: 'https://images.pexels.com/photos/6476590/pexels-photo-6476590.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    author: {
      name: 'Emma Richards',
      avatarUrl: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    }
  },
  {
    id: '4',
    title: 'Understanding Telemedicine: Benefits and Limitations',
    summary: 'A comprehensive guide to telemedicine services, explaining when they\'re most useful and when you should seek in-person care.',
    content: `
      <p>Telemedicine has revolutionized healthcare delivery, especially in recent years. This comprehensive guide explains the benefits and limitations of virtual healthcare services to help you make informed decisions about your medical care.</p>
      
      <h3>Benefits of Telemedicine</h3>
      
      <h4>Convenience and Accessibility</h4>
      <p>Telemedicine eliminates travel time and reduces waiting room delays. It's particularly valuable for people in rural areas, those with mobility issues, or busy individuals who struggle to fit healthcare appointments into their schedules.</p>
      
      <h4>Cost-Effectiveness</h4>
      <p>Virtual visits often cost less than in-person appointments, both in terms of direct medical expenses and indirect costs like transportation and time off work. Many insurance plans now cover telemedicine services.</p>
      
      <h4>Continuity of Care</h4>
      <p>Telemedicine makes it easier to maintain regular contact with healthcare providers for chronic condition management, medication adjustments, and follow-up appointments.</p>
      
      <h4>Reduced Exposure to Illness</h4>
      <p>Virtual appointments eliminate potential exposure to contagious illnesses that might be present in waiting rooms and healthcare facilities.</p>
      
      <h3>Limitations and Considerations</h3>
      
      <h4>Physical Examination Constraints</h4>
      <p>Some conditions require hands-on physical examinations that simply cannot be conducted virtually. Diagnostic procedures like lab tests, imaging studies, and biopsies must be performed in person.</p>
      
      <h4>Technology Barriers</h4>
      <p>Not everyone has access to reliable internet connections or devices needed for virtual appointments. Some patients, particularly older adults, may not be comfortable with the technology.</p>
      
      <h4>Communication Challenges</h4>
      <p>Virtual interactions may miss subtle non-verbal cues that can be important in diagnosis and treatment. Some patients find it more difficult to build rapport with healthcare providers through screens.</p>
      
      <h3>When to Choose Telemedicine</h3>
      <p>Telemedicine is generally well-suited for:</p>
      <ul>
        <li>Minor illnesses like colds, allergies, and rashes</li>
        <li>Mental health consultations</li>
        <li>Follow-up appointments for stable chronic conditions</li>
        <li>Medication management and prescription renewals</li>
        <li>Reviewing test results</li>
        <li>Nutritional counseling</li>
      </ul>
      
      <h3>When to Seek In-Person Care</h3>
      <p>Consider in-person visits for:</p>
      <ul>
        <li>Emergency situations and severe symptoms</li>
        <li>Conditions requiring physical examination</li>
        <li>Diagnostic testing and procedures</li>
        <li>Complex health issues with multiple symptoms</li>
        <li>New, undiagnosed conditions</li>
      </ul>
      
      <p>The future of healthcare likely involves a hybrid approach that combines the convenience of telemedicine with traditional in-person care. By understanding the strengths and limitations of each approach, you can make the best choices for your specific healthcare needs.</p>
    `,
    category: 'tip',
    publishedDate: '2024-05-01',
    imageUrl: 'https://images.pexels.com/photos/7579831/pexels-photo-7579831.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    author: {
      name: 'Dr. Michael Chen',
      avatarUrl: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    }
  },
  {
    id: '5',
    title: 'New Research on Sleep and Immune Function',
    summary: 'Recent studies highlight the critical role of quality sleep in maintaining a robust immune system and overall health.',
    content: `
      <p>Recent research has shed new light on the intricate relationship between sleep and immune function, emphasizing the critical importance of quality sleep for maintaining overall health and preventing disease.</p>
      
      <p>A groundbreaking study published last month in the Journal of Immunology Research demonstrated that consistent sleep deprivation—even mild shortfalls of 1-2 hours per night—can reduce immune cell activity by up to 30% after just one week. This reduction in immune function makes the body significantly more vulnerable to infections and may contribute to chronic inflammation.</p>
      
      <p>"We've known for some time that sleep and immunity are connected, but these new findings reveal just how quickly and dramatically sleep deficiency can impact our body's defense systems," explains Dr. Rebecca Torres, immunologist and lead researcher on the study.</p>
      
      <h3>Key Findings from Recent Research</h3>
      
      <p>Multiple studies over the past year have contributed to our understanding of the sleep-immunity connection:</p>
      
      <ul>
        <li>During sleep, especially deep sleep, the body produces and releases cytokines—proteins that target infection and inflammation</li>
        <li>Sleep deprivation decreases the production of protective cytokines while increasing inflammatory markers</li>
        <li>Regular sleep of 7-9 hours improves T-cell functioning, enhancing the body's ability to fight viral infections</li>
        <li>Quality of sleep matters as much as quantity—fragmented sleep provides fewer immune benefits than continuous sleep</li>
        <li>Consistent sleep schedules support the body's circadian rhythms, which regulate immune system activity</li>
      </ul>
      
      <h3>Practical Applications</h3>
      
      <p>Based on these findings, health experts recommend several strategies to optimize sleep for immune support:</p>
      
      <ol>
        <li><strong>Prioritize sleep consistency</strong> by going to bed and waking up at the same times, even on weekends</li>
        <li><strong>Create a sleep-conducive environment</strong> that is dark, quiet, and cool</li>
        <li><strong>Limit screen time</strong> for at least one hour before bedtime to reduce exposure to sleep-disrupting blue light</li>
        <li><strong>Manage stress</strong> through relaxation techniques such as meditation or deep breathing exercises</li>
        <li><strong>Avoid caffeine and alcohol</strong> close to bedtime, as both can interfere with sleep quality</li>
      </ol>
      
      <p>"These findings emphasize that quality sleep should be considered a pillar of immune health, alongside nutrition, physical activity, and stress management," notes Dr. Torres. "In our busy society, we often sacrifice sleep, but these studies show that doing so comes at a considerable cost to our health."</p>
      
      <p>As research in this area continues, scientists hope to develop more targeted interventions to help those with sleep disorders improve their immune function and overall health outcomes.</p>
    `,
    category: 'news',
    publishedDate: '2024-04-28',
    imageUrl: 'https://images.pexels.com/photos/3771069/pexels-photo-3771069.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    author: {
      name: 'Dr. Rebecca Torres',
      avatarUrl: 'https://images.pexels.com/photos/3764119/pexels-photo-3764119.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    }
  },
  {
    id: '6',
    title: 'Managing Seasonal Allergies: Expert Tips',
    summary: 'Practical strategies to minimize allergy symptoms and enjoy the changing seasons without discomfort.',
    content: `
      <p>For millions of people, the changing seasons bring not just new weather but also the misery of seasonal allergies. While complete avoidance of allergens isn't always possible, these expert-recommended strategies can help you manage symptoms effectively and enjoy seasonal changes with minimal discomfort.</p>
      
      <h3>Understanding Seasonal Allergies</h3>
      
      <p>Seasonal allergies, also known as allergic rhinitis or hay fever, occur when your immune system overreacts to environmental allergens like pollen, mold spores, or grass. This hypersensitivity triggers the release of histamines and other chemicals that cause familiar symptoms like sneezing, runny nose, itchy eyes, and congestion.</p>
      
      <h3>Preventive Strategies</h3>
      
      <h4>Track Pollen Counts</h4>
      <p>Use weather apps or websites to monitor local pollen forecasts. When counts are high, limit outdoor activities, especially in the morning when pollen levels typically peak. After a rainstorm is often the best time to venture outdoors, as rain helps clear pollen from the air.</p>
      
      <h4>Create an Allergen Barrier</h4>
      <p>Consider wearing wraparound sunglasses to protect your eyes from airborne allergens. For those with severe allergies, wearing a mask during outdoor activities can significantly reduce exposure, particularly when doing yard work or exercising outdoors.</p>
      
      <h4>Modify Your Home Environment</h4>
      <ul>
        <li>Keep windows closed during high pollen seasons, using air conditioning if needed</li>
        <li>Use high-efficiency air purifiers in bedrooms and frequently used living spaces</li>
        <li>Change clothes and shower after spending time outdoors to remove pollen</li>
        <li>Wash bedding weekly in hot water to remove allergen accumulation</li>
        <li>Consider removing shoes at the door to avoid tracking allergens inside</li>
      </ul>
      
      <h3>Treatment Options</h3>
      
      <h4>Over-the-Counter Medications</h4>
      <p>Several effective options are available without prescription:</p>
      <ul>
        <li><strong>Antihistamines</strong> block the action of histamine, reducing sneezing, itching, and runny nose</li>
        <li><strong>Decongestants</strong> reduce nasal congestion but should be used sparingly and not by those with certain health conditions</li>
        <li><strong>Nasal corticosteroid sprays</strong> reduce inflammation and are considered among the most effective allergy treatments</li>
        <li><strong>Saline nasal irrigation</strong> helps flush allergens from nasal passages</li>
      </ul>
      
      <h4>Prescription Treatments</h4>
      <p>If over-the-counter options aren't providing relief, consult with a healthcare provider about:</p>
      <ul>
        <li>Prescription-strength antihistamines or corticosteroids</li>
        <li>Leukotriene modifiers for allergy symptoms resistant to other treatments</li>
        <li>Immunotherapy (allergy shots or sublingual tablets) for long-term symptom reduction</li>
      </ul>
      
      <h3>Natural Approaches</h3>
      
      <p>Some people find relief through complementary approaches:</p>
      <ul>
        <li>Local honey consumption (though scientific evidence is limited)</li>
        <li>Nasal irrigation with saline solution</li>
        <li>Certain herbal supplements like butterbur (consult healthcare providers before trying)</li>
        <li>Acupuncture, which some studies suggest may help with allergy symptoms</li>
      </ul>
      
      <p>"The key to managing seasonal allergies is developing a multi-faceted approach that combines environmental modifications, medication when needed, and lifestyle adjustments," explains allergist Dr. Sophia Martinez. "With the right strategy, most people can significantly reduce their allergy burden."</p>
      
      <p>Consider tracking your symptoms and their correlation with activities, locations, and weather conditions to develop a personalized management plan that works best for your specific allergy profile.</p>
    `,
    category: 'tip',
    publishedDate: '2024-04-22',
    imageUrl: 'https://images.pexels.com/photos/5939401/pexels-photo-5939401.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    author: {
      name: 'Dr. Sophia Martinez',
      avatarUrl: 'https://images.pexels.com/photos/5215024/pexels-photo-5215024.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    }
  }
];

export const getPostById = (id: string): Post | undefined => {
  console.log("Looking for post with ID:", id, typeof id);
  console.log("Available IDs:", posts.map(post => post.id));
  return posts.find(post => post.id === id);
};