import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './store/authStore';

// صفحات الموقع
import Layout from './components/Layout';
import Hero from './components/Hero';
import Features from './components/Features';
import HowItWorks from './components/HowItWorks';
import TestimonialsSlider from './components/TestimonialsSlider';
import FAQ from './components/FAQ';
import CTA from './components/CTA';
import TestimonialsPage from './pages/Testimonials';
import Blog from './pages/BlogPage';
import PostDetailPage from './pages/PostDetailPage';
import ConsultationForm from './pages/Consultation';
import AboutUs from './pages/AboutUs';
import ContactUs from './pages/ContactUs';
import TermsAndConditions from './pages/TermsAndConditions';
import AdminPanel from './pages/admin/AdminPanel';
import HIPAACompliance from './pages/legal/HIPAACompliance';
import PrivacyPolicy from './pages/legal/PrivacyPolicy';
import Cookies from './pages/legal/Cookies';
import Chat from './pages/Chat';
import NotFound from './pages/NotFound';

// صفحات المصادقة
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import ForgotPassword from './pages/auth/ForgotPassword';
import ResetPassword from './pages/auth/ResetPassword';

// صفحات الملف الشخصي والإعدادات
import Profile from './pages/Profile';
import Settings from './pages/Settings';

// مكون الحماية للمسارات التي تتطلب تسجيل الدخول
const ProtectedRoute = ({ children }: { children: JSX.Element }) => {
  const { user, isLoading } = useAuthStore();
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }
  
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  
  return children;
};

function App() {
  const { checkAuth } = useAuthStore();
  
  useEffect(() => {
    checkAuth();
  }, [checkAuth]);
  
  return (
    // <Router>
    //   <Routes>
        
        
        
    //     <Route path="/chat" element={<Chat />} />
        
        
        
        
        
    //     <Route path="/login" element={<Login />} />
    //     <Route path="/register" element={<Register />} />
    //     <Route path="/auth/callback" element={<Navigate to="/chat" replace />} />
    //     <Route path="*" element={<Navigate to="/" replace />} />
    //   </Routes>
    // </Router>
    <Router>
      <Routes>
        {/* الصفحات العامة */}
        <Route path="/" element={
          <Layout>
            <Hero />
            <Features />
            <HowItWorks />
            <TestimonialsSlider />
            <FAQ />
            <CTA />
          </Layout>
        } />
        <Route path="/about" element={<AboutUs />} />
        <Route path="/blog" element={<Blog />} />
        <Route path="/blog/category/:category" element={<Blog />} />
        <Route path="/blog/:id" element={<PostDetailPage />} />
        <Route path="/post/:id" element={<PostDetailPage />} />
        <Route path="/consultation" element={<ConsultationForm />} />
        <Route path="/testimonials" element={<TestimonialsPage />} />
        <Route path="/admin" element={<AdminPanel />} />
        <Route path="/privacy-policy" element={<PrivacyPolicy />} />
        <Route path="/about" element={<AboutUs />} />
        <Route path="/terms" element={<TermsAndConditions />} />
        <Route path="/contact" element={<ContactUs />} />
        <Route path="/hipaa-compliance" element={<HIPAACompliance />} />
        <Route path="/cookies" element={<Cookies />} />
        
        {/* صفحات المصادقة */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/auth/callback" element={<Navigate to="/chat" replace />} />
        
        {/* الصفحات المحمية (تتطلب تسجيل الدخول) */}
        <Route path="/chat" element={
          <ProtectedRoute>
            <Chat />
          </ProtectedRoute>
        } />
        <Route path="/profile" element={
          <ProtectedRoute>
            <Profile />
          </ProtectedRoute>
        } />
        <Route path="/settings" element={
          <ProtectedRoute>
            <Settings />
          </ProtectedRoute>
        } />
        
        {/* صفحة 404 */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Router>
  );
}

export default App;

