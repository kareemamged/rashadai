import { create } from 'zustand';

// نقطة نهاية Gemini API
const GEMINI_ENDPOINT = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent';
const GEMINI_API_KEY = 'YOUR_GEMINI_API_KEY'; // استبدل بمفتاح API الخاص بك

// النص الأساسي للنظام
const SYSTEM_PROMPT = `أنت مساعد طبي ذكي يقدم استشارات طبية أولية. يجب عليك اتباع هذه الإرشادات:

1. قدم معلومات طبية دقيقة ومفيدة بناءً على أحدث الأبحاث والمعرفة الطبية.
2. لا تقدم تشخيصًا نهائيًا، بل اقترح احتمالات وأوصِ بزيارة الطبيب عند الضرورة.
3. اسأل عن المزيد من المعلومات إذا كانت الأعراض غير واضحة.
4. قدم نصائح للرعاية الذاتية عندما يكون ذلك مناسبًا.
5. كن واضحًا ودقيقًا ومتعاطفًا في إجاباتك.
6. لا تقدم وصفات طبية محددة أو جرعات دوائية.
7. أشر إلى الحالات التي تتطلب عناية طبية عاجلة.
8. تحدث باللغة العربية الفصحى البسيطة.`;

// تعريف نوع المرفق
interface Attachment {
  name: string;
  type: string;
  url: string;
  size: number;
}

// تعريف نوع الرسالة
interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
  attachments?: Attachment[];
}

// تعريف حالة المخزن
interface ConsultationState {
  messages: Message[];
  isLoading: boolean;
  isTyping: boolean;
  typingMessage: string | null;
  attachments: Attachment[];
  
  // الأفعال
  startConsultation: (symptoms: string, age: number, gender: string) => Promise<void>;
  sendMessage: (content: string) => Promise<void>;
  completeTyping: () => void;
  stopTyping: () => void;
  addAttachment: (attachment: Attachment) => void;
  removeAttachment: (index: number) => void;
  clearAttachments: () => void;
}

// استدعاء Gemini API
const callGeminiAPI = async (apiMessages: any[], attachments: Attachment[] = []) => {
  try {
    // إضافة الصور إلى الرسالة الأخيرة إذا كانت موجودة
    if (attachments.length > 0 && apiMessages.length > 0) {
      const lastMessage = apiMessages[apiMessages.length - 1];
      
      // إضافة وصف للصور في نص الرسالة
      const imageDescriptions = attachments
        .filter(att => att.type.startsWith('image/'))
        .map(att => `[Image: ${att.name}]`)
        .join(' ');
      
      if (imageDescriptions) {
        lastMessage.parts[0].text += `\n\n${imageDescriptions}`;
      }
      
      // إضافة الصور كأجزاء منفصلة للرسالة (ملاحظة: Gemini يدعم الصور)
      attachments
        .filter(att => att.type.startsWith('image/'))
        .forEach(att => {
          // استخراج البيانات من URL البيانات
          const base64Data = att.url.split(',')[1];
          lastMessage.parts.push({
            inlineData: {
              mimeType: att.type,
              data: base64Data
            }
          });
        });
    }

    const response = await fetch(`${GEMINI_ENDPOINT}?key=${GEMINI_API_KEY}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: apiMessages
      })
    });
    
    if (!response.ok) {
      throw new Error(`API request failed with status ${response.status}`);
    }
    
    const data = await response.json();
    return data.candidates[0].content.parts[0].text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    return "I apologize, but I couldn't process your request. Please try again.";
  }
};

export const useConsultationStore = create<ConsultationState>((set, get) => ({
  messages: [],
  isLoading: false,
  isTyping: false,
  typingMessage: null,
  attachments: [],

  startConsultation: async (symptoms, age, gender) => {
    set({ isLoading: true });
    
    try {
      // إنشاء رسالة النظام الأولية مع معلومات المريض
      const initialMessage = `مريض ${gender === 'male' ? 'ذكر' : 'أنثى'} عمره ${age} سنة يعاني من الأعراض التالية: ${symptoms}`;
      
      // إعداد الرسائل للـ API
      const apiMessages = [
        { role: "user", parts: [{ text: SYSTEM_PROMPT }] },
        { role: "model", parts: [{ text: "I understand my role as a medical assistant. I'll follow these guidelines in our conversation." }] },
        { role: "user", parts: [{ text: initialMessage }] }
      ];
      
      // استدعاء Gemini API
      const aiResponse = await callGeminiAPI(apiMessages);
      
      // إضافة رسالة المستخدم والرد الأولي
      set(state => ({ 
        messages: [
          {
            id: Date.now().toString(),
            content: initialMessage,
            role: 'user',
            timestamp: new Date()
          },
          {
            id: (Date.now() + 1).toString(),
            content: aiResponse,
            role: 'assistant',
            timestamp: new Date()
          }
        ],
        isLoading: false
      }));
      
      return Promise.resolve();
    } catch (error) {
      console.error('Error starting consultation:', error);
      set({ isLoading: false });
      return Promise.reject(error);
    }
  },

  completeTyping: () => {
    const { typingMessage } = get();
    if (typingMessage) {
      set(state => ({
        messages: [...state.messages, {
          id: Date.now().toString(),
          content: typingMessage,
          role: 'assistant',
          timestamp: new Date()
        }],
        isTyping: false,
        typingMessage: null
      }));
    }
  },
  
  stopTyping: () => {
    const { typingMessage } = get();
    if (typingMessage) {
      // إضافة الرسالة الحالية كما هي (غير مكتملة)
      const currentDisplayedText = document.querySelector('.typing-effect-text')?.textContent || '';
      
      if (currentDisplayedText) {
        set(state => ({
          messages: [...state.messages, {
            id: Date.now().toString(),
            content: currentDisplayedText,
            role: 'assistant',
            timestamp: new Date()
          }],
          isTyping: false,
          typingMessage: null
        }));
      } else {
        // إذا لم نتمكن من الحصول على النص المعروض، استخدم النص الكامل
        set(state => ({
          messages: [...state.messages, {
            id: Date.now().toString(),
            content: typingMessage + " [response interrupted]",
            role: 'assistant',
            timestamp: new Date()
          }],
          isTyping: false,
          typingMessage: null
        }));
      }
    }
  },
  
  addAttachment: (attachment) => {
    set(state => ({
      attachments: [...state.attachments, attachment]
    }));
  },
  
  removeAttachment: (index) => {
    set(state => ({
      attachments: state.attachments.filter((_, i) => i !== index)
    }));
  },
  
  clearAttachments: () => {
    set({ attachments: [] });
  },
  
  sendMessage: async (content) => {
    const { messages, attachments } = get();
    
    // إضافة رسالة المستخدم
    const userMessage = {
      id: Date.now().toString(),
      content,
      role: 'user' as const,
      timestamp: new Date(),
      attachments: attachments.length > 0 ? [...attachments] : undefined
    };
    
    set(state => ({ 
      messages: [...state.messages, userMessage],
      isLoading: true 
    }));
    
    try {
      // إعداد الرسائل للـ API
      const apiMessages = [
        { role: "user", parts: [{ text: SYSTEM_PROMPT }] },
        { role: "model", parts: [{ text: "I understand my role as a medical assistant. I'll follow these guidelines in our conversation." }] }
      ];
      
      // إضافة سجل المحادثة السابقة
      messages.forEach(msg => {
        apiMessages.push({
          role: msg.role,
          parts: [{ text: msg.content }]
        });
      });
      
      // إضافة رسالة المستخدم الحالية
      apiMessages.push({
        role: "user",
        parts: [{ text: content }]
      });
      
      // استدعاء Gemini API
      const aiResponse = await callGeminiAPI(apiMessages, attachments);
      
      // تعيين تأثير الكتابة بدلاً من إضافة الرسالة مباشرة
      set({ 
        isLoading: false,
        isTyping: true,
        typingMessage: aiResponse,
        attachments: [] // مسح المرفقات بعد الإرسال
      });
      
    } catch (error) {
      console.error('Error sending message:', error);
      set({ 
        isLoading: false,
        messages: [...get().messages, {
          id: Date.now().toString(),
          content: "عذرًا، حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى.",
          role: 'assistant',
          timestamp: new Date()
        }],
        attachments: [] // مسح المرفقات في حالة الخطأ
      });
    }
  }
}));


