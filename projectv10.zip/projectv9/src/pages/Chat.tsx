import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Loader, 
  Copy, 
  ThumbsUp, 
  ThumbsDown, 
  RefreshCw, 
  Edit, 
  User, 
  Bot, 
  ArrowLeft, 
  Paperclip, 
  Mic, 
  Square, 
  Check, 
  ThumbsUpFill, 
  ThumbsDownFill,
  UserCircle,
  ChevronDown,
  Settings,
  LogOut
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { useConsultationStore } from '../store/consultationStore';
import TypingEffect from '../components/TypingEffect';

const Chat = () => {
  const navigate = useNavigate();
  const { user, signOut, isLoading: authLoading } = useAuthStore();
  const { 
    messages, 
    isLoading, 
    isTyping, 
    typingMessage, 
    sendMessage,
    attachments,
    addAttachment,
    removeAttachment,
    clearAttachments
  } = useConsultationStore();
  
  const [userInput, setUserInput] = useState('');
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const profileMenuRef = useRef<HTMLDivElement>(null);
  
  // التحقق من تسجيل الدخول
  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login');
    }
  }, [user, authLoading, navigate]);
  
  // التمرير إلى آخر رسالة
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);
  
  // إغلاق قائمة البروفايل عند النقر خارجها
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (profileMenuRef.current && !profileMenuRef.current.contains(event.target as Node)) {
        setShowProfileMenu(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (userInput.trim()) {
      sendMessage(userInput);
      setUserInput('');
    }
  };
  
  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };
  
  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }
  
  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* هيدر الشات مع صورة البروفايل */}
      <header className="bg-white shadow-sm py-4 px-6 flex items-center justify-between">
        <div className="flex items-center">
          <button 
            onClick={() => navigate('/')}
            className="mr-4 text-gray-500 hover:text-gray-700"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div className="flex items-center">
            <Bot className="h-6 w-6 text-blue-600 mr-2" />
            <h1 className="text-xl font-semibold text-gray-800">استشارة طبية</h1>
          </div>
        </div>
        
        {/* قائمة البروفايل */}
        <div className="relative" ref={profileMenuRef}>
          <button 
            onClick={() => setShowProfileMenu(!showProfileMenu)}
            className="flex items-center space-x-2 text-gray-700 hover:text-blue-600 focus:outline-none"
          >
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              {user?.avatar_url ? (
                <img 
                  src={user.avatar_url} 
                  alt="Profile" 
                  className="h-8 w-8 rounded-full object-cover border border-gray-200"
                />
              ) : (
                <UserCircle className="h-8 w-8 text-gray-400" />
              )}
              <span className="font-medium text-sm hidden md:block">
                {user?.full_name || user?.email?.split('@')[0] || 'المستخدم'}
              </span>
              <ChevronDown className="h-4 w-4" />
            </div>
          </button>
          
          {showProfileMenu && (
            <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10 border border-gray-200">
              <div className="px-4 py-2 border-b border-gray-100">
                <p className="text-sm font-medium text-gray-900 truncate">
                  {user?.full_name || 'المستخدم'}
                </p>
                <p className="text-xs text-gray-500 truncate">{user?.email}</p>
              </div>
              
              <a 
                href="/profile" 
                className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center"
              >
                <User className="h-4 w-4 mr-2" />
                الملف الشخصي
              </a>
              
              <a 
                href="/settings" 
                className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center"
              >
                <Settings className="h-4 w-4 mr-2" />
                الإعدادات
              </a>
              
              <button 
                onClick={handleSignOut}
                className="block w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-gray-100 flex items-center"
              >
                <LogOut className="h-4 w-4 mr-2" />
                تسجيل الخروج
              </button>
            </div>
          )}
        </div>
      </header>
      
      {/* محتوى الشات */}
      <div className="flex-1 overflow-y-auto p-6">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <Bot className="h-16 w-16 text-blue-500 mb-4" />
            <h2 className="text-2xl font-bold text-gray-800 mb-2">مرحباً بك في الاستشارة الطبية</h2>
            <p className="text-gray-600 max-w-md">
              أنا مساعدك الطبي الذكي. يمكنك سؤالي عن أي استفسارات طبية وسأحاول مساعدتك.
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {messages.map((msg, index) => (
              <div 
                key={index} 
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div 
                  className={`max-w-3xl rounded-lg px-4 py-3 ${
                    msg.role === 'user' 
                      ? 'bg-blue-600 text-white' 
                      : 'bg-white text-gray-800 border border-gray-200'
                  }`}
                >
                  <div className="whitespace-pre-wrap">{msg.content}</div>
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex justify-start">
                <div className="max-w-3xl rounded-lg px-4 py-3 bg-white text-gray-800 border border-gray-200">
                  <div className="whitespace-pre-wrap">
                    {typingMessage || (
                      <div className="flex space-x-2 rtl:space-x-reverse">
                        <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce"></div>
                        <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce delay-75"></div>
                        <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce delay-150"></div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>
      
      {/* نموذج إرسال الرسائل */}
      <div className="border-t border-gray-200 bg-white p-4">
        <form onSubmit={handleSubmit} className="flex items-end space-x-2 rtl:space-x-reverse">
          <div className="flex-1">
            <textarea
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              placeholder="اكتب رسالتك هنا..."
              className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
              rows={3}
            />
            
            {/* عرض المرفقات */}
            {attachments.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-2">
                {attachments.map((attachment, index) => (
                  <div key={index} className="relative bg-gray-100 rounded-md p-2 flex items-center">
                    <span className="text-sm truncate max-w-xs">
                      {attachment.name}
                    </span>
                    <button
                      type="button"
                      onClick={() => removeAttachment(index)}
                      className="ml-2 text-gray-500 hover:text-red-500"
                    >
                      &times;
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          <button
            type="submit"
            disabled={isLoading || !userInput.trim()}
            className="bg-blue-600 text-white rounded-lg px-4 py-2 font-medium hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
          >
            إرسال
          </button>
        </form>
      </div>
    </div>
  );
};

export default Chat;





























