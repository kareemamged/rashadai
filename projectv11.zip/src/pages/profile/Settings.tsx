import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Settings as SettingsIcon, User, Lock, Bell, Shield, HelpCircle, Loader, Save } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import ChatHeader from '../../components/ChatHeader';

const Settings = () => {
  const navigate = useNavigate();
  const { user, updateProfile } = useAuthStore();
  const [isLoading, setIsLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [settings, setSettings] = useState({
    notifications: {
      email: true,
      app: true,
    },
    privacy: {
      saveHistory: true,
      shareData: false,
    },
    appearance: {
      theme: 'light',
      fontSize: 'medium',
    },
  });

  useEffect(() => {
    if (!user) {
      navigate('/login');
    }
  }, [user, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setSuccessMessage('');

    try {
      // في تطبيق حقيقي، سنقوم بحفظ الإعدادات في الخادم
      // هنا نستخدم setTimeout للمحاكاة
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setSuccessMessage('تم حفظ الإعدادات بنجاح');
      setTimeout(() => setSuccessMessage(''), 3000);
    } catch (error) {
      console.error('Error saving settings:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <ChatHeader />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-2xl font-bold text-gray-900 mb-6">الإعدادات</h1>
          
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="md:flex">
              {/* Sidebar */}
              <div className="md:w-64 bg-gray-50 p-6 border-r border-gray-200">
                <nav className="space-y-1">
                  <Link
                    to="/profile"
                    className="flex items-center px-3 py-2 text-sm font-medium text-gray-700 rounded-md hover:bg-gray-100"
                  >
                    <User className="h-5 w-5 mr-2 text-gray-500" />
                    الملف الشخصي
                  </Link>
                  <Link
                    to="/change-password"
                    className="flex items-center px-3 py-2 text-sm font-medium text-gray-700 rounded-md hover:bg-gray-100"
                  >
                    <Lock className="h-5 w-5 mr-2 text-gray-500" />
                    تغيير كلمة المرور
                  </Link>
                  <Link
                    to="/settings"
                    className="flex items-center px-3 py-2 text-sm font-medium text-blue-700 bg-blue-50 rounded-md"
                  >
                    <SettingsIcon className="h-5 w-5 mr-2 text-blue-500" />
                    الإعدادات العامة
                  </Link>
                </nav>
              </div>
              
              {/* Main content */}
              <div className="flex-1 p-6">
                {successMessage && (
                  <div className="mb-6 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg">
                    {successMessage}
                  </div>
                )}
                
                <form onSubmit={handleSubmit} className="space-y-8">
                  {/* Notifications */}
                  <div>
                    <h2 className="text-lg font-medium text-gray-900 flex items-center">
                      <Bell className="h-5 w-5 mr-2 text-gray-500" />
                      إعدادات الإشعارات
                    </h2>
                    <div className="mt-4 space-y-4">
                      <div className="flex items-center">
                        <input
                          id="email-notifications"
                          type="checkbox"
                          checked={settings.notifications.email}
                          onChange={(e) => setSettings({
                            ...settings,
                            notifications: {
                              ...settings.notifications,
                              email: e.target.checked
                            }
                          })}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                        />
                        <label htmlFor="email-notifications" className="mr-3 block text-sm text-gray-700">
                          إشعارات البريد الإلكتروني
                        </label>
                      </div>
                      <div className="flex items-center">
                        <input
                          id="app-notifications"
                          type="checkbox"
                          checked={settings.notifications.app}
                          onChange={(e) => setSettings({
                            ...settings,
                            notifications: {
                              ...settings.notifications,
                              app: e.target.checked
                            }
                          })}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                        />
                        <label htmlFor="app-notifications" className="mr-3 block text-sm text-gray-700">
                          إشعارات التطبيق
                        </label>
                      </div>
                    </div>
                  </div>
                  
                  {/* Privacy */}
                  <div>
                    <h2 className="text-lg font-medium text-gray-900 flex items-center">
                      <Shield className="h-5 w-5 mr-2 text-gray-500" />
                      إعدادات الخصوصية
                    </h2>
                    <div className="mt-4 space-y-4">
                      <div className="flex items-center">
                        <input
                          id="save-history"
                          type="checkbox"
                          checked={settings.privacy.saveHistory}
                          onChange={(e) => setSettings({
                            ...settings,
                            privacy: {
                              ...settings.privacy,
                              saveHistory: e.target.checked
                            }
                          })}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                        />
                        <label htmlFor="save-history" className="mr-3 block text-sm text-gray-700">
                          حفظ سجل المحادثات
                        </label>
                      </div>
                      <div className="flex items-center">
                        <input
                          id="share-data"
                          type="checkbox"
                          checked={settings.privacy.shareData}
                          onChange={(e) => setSettings({
                            ...settings,
                            privacy: {
                              ...settings.privacy,
                              shareData: e.target.checked
                            }
                          })}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                        />
                        <label htmlFor="share-data" className="mr-3 block text-sm text-gray-700">
                          مشاركة البيانات لتحسين الخدمة
                        </label>
                      </div>
                    </div>
                  </div>
                  
                  {/* Appearance */}
                  <div>
                    <h2 className="text-lg font-medium text-gray-900 flex items-center">
                      <HelpCircle className="h-5 w-5 mr-2 text-gray-500" />
                      إعدادات المظهر
                    </h2>
                    <div className="mt-4 space-y-4">
                      <div>
                        <label htmlFor="theme" className="block text-sm font-medium text-gray-700 mb-1">
                          السمة
                        </label>
                        <select
                          id="theme"
                          value={settings.appearance.theme}
                          onChange={(e) => setSettings({
                            ...settings,
                            appearance: {
                              ...settings.appearance,
                              theme: e.target.value
                            }
                          })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        >
                          <option value="light">فاتح</option>
                          <option value="dark">داكن</option>
                          <option value="system">حسب النظام</option>
                        </select>
                      </div>
                      <div>
                        <label htmlFor="font-size" className="block text-sm font-medium text-gray-700 mb-1">
                          حجم الخط
                        </label>
                        <select
                          id="font-size"
                          value={settings.appearance.fontSize}
                          onChange={(e) => setSettings({
                            ...settings,
                            appearance: {
                              ...settings.appearance,
                              fontSize: e.target.value
                            }
                          })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        >
                          <option value="small">صغير</option>
                          <option value="medium">متوسط</option>
                          <option value="large">كبير</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex justify-end">
                    <button
                      type="submit"
                      disabled={isLoading}
                      className="flex items-center justify-center px-6 py-2 border border-transparent rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {isLoading ? (
                        <>
                          <Loader className="animate-spin h-4 w-4 mr-2" />
                          جاري الحفظ...
                        </>
                      ) : (
                        <>
                          <Save className="h-4 w-4 mr-2" />
                          حفظ الإعدادات
                        </>
                      )}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
