import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { MessageSquare, Search, Trash2, Calendar, Download, Filter } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import ChatHeader from '../../components/ChatHeader';

// نموذج لبيانات المحادثات
interface ChatSession {
  id: string;
  title: string;
  preview: string;
  date: Date;
  messageCount: number;
}

const ChatHistory = () => {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [selectedChats, setSelectedChats] = useState<string[]>([]);
  
  // بيانات وهمية للمحادثات
  const [chatSessions, setChatSessions] = useState<ChatSession[]>([
    {
      id: '1',
      title: 'استشارة حول آلام الظهر',
      preview: 'أعاني من آلام في أسفل الظهر منذ أسبوع...',
      date: new Date(2023, 5, 15),
      messageCount: 12
    },
    {
      id: '2',
      title: 'استفسار عن أعراض الإنفلونزا',
      preview: 'ما هي أعراض الإنفلونزا الموسمية وكيف...',
      date: new Date(2023, 5, 10),
      messageCount: 8
    },
    {
      id: '3',
      title: 'نصائح للتغذية السليمة',
      preview: 'أريد نظام غذائي صحي لتحسين صحتي العامة...',
      date: new Date(2023, 5, 5),
      messageCount: 15
    },
    {
      id: '4',
      title: 'استشارة طبية عامة',
      preview: 'أعاني من صداع مستمر وأرق في النوم...',
      date: new Date(2023, 4, 28),
      messageCount: 10
    },
    {
      id: '5',
      title: 'استفسار عن لقاح كورونا',
      preview: 'ما هي الآثار الجانبية المحتملة للقاح كورونا...',
      date: new Date(2023, 4, 20),
      messageCount: 7
    }
  ]);

  useEffect(() => {
    if (!user) {
      navigate('/login');
    }
  }, [user, navigate]);

  const handleChatClick = (chatId: string) => {
    // في تطبيق حقيقي، سننتقل إلى المحادثة المحددة
    console.log(`Opening chat: ${chatId}`);
  };

  const handleDeleteSelected = () => {
    if (selectedChats.length === 0) return;
    
    setChatSessions(prev => prev.filter(chat => !selectedChats.includes(chat.id)));
    setSelectedChats([]);
  };

  const handleSelectChat = (chatId: string) => {
    setSelectedChats(prev => {
      if (prev.includes(chatId)) {
        return prev.filter(id => id !== chatId);
      } else {
        return [...prev, chatId];
      }
    });
  };

  const handleSelectAll = () => {
    if (selectedChats.length === filteredChats.length) {
      setSelectedChats([]);
    } else {
      setSelectedChats(filteredChats.map(chat => chat.id));
    }
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  // تصفية المحادثات حسب البحث والفلتر
  const filteredChats = chatSessions.filter(chat => {
    const matchesSearch = chat.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         chat.preview.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (selectedFilter === 'all') return matchesSearch;
    if (selectedFilter === 'recent') {
      const oneMonthAgo = new Date();
      oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
      return matchesSearch && chat.date >= oneMonthAgo;
    }
    if (selectedFilter === 'older') {
      const oneMonthAgo = new Date();
      oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
      return matchesSearch && chat.date < oneMonthAgo;
    }
    
    return matchesSearch;
  });

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <ChatHeader />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold text-gray-900">سجل المحادثات</h1>
            
            <div className="flex space-x-2">
              <button
                onClick={handleDeleteSelected}
                disabled={selectedChats.length === 0}
                className="flex items-center px-3 py-1.5 text-sm text-red-600 border border-red-200 rounded-md hover:bg-red-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Trash2 className="h-4 w-4 mr-1" />
                حذف المحدد
              </button>
              <button className="flex items-center px-3 py-1.5 text-sm text-blue-600 border border-blue-200 rounded-md hover:bg-blue-50">
                <Download className="h-4 w-4 mr-1" />
                تصدير
              </button>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            {/* Search and filter */}
            <div className="p-4 border-b border-gray-200 flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-3 sm:space-y-0">
              <div className="relative flex-1 max-w-md">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder="البحث في المحادثات..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm"
                />
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <select
                    value={selectedFilter}
                    onChange={(e) => setSelectedFilter(e.target.value)}
                    className="appearance-none block pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm"
                  >
                    <option value="all">جميع المحادثات</option>
                    <option value="recent">آخر شهر</option>
                    <option value="older">أقدم من شهر</option>
                  </select>
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Filter className="h-4 w-4 text-gray-400" />
                  </div>
                </div>
              </div>
            </div>
            
            {/* Chat list */}
            {filteredChats.length > 0 ? (
              <div>
                <div className="border-b border-gray-200 px-4 py-3 flex items-center bg-gray-50">
                  <input
                    type="checkbox"
                    checked={selectedChats.length === filteredChats.length && filteredChats.length > 0}
                    onChange={handleSelectAll}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded ml-2"
                  />
                  <span className="text-sm font-medium text-gray-700">
                    {selectedChats.length > 0 ? `تم تحديد ${selectedChats.length} محادثة` : 'تحديد الكل'}
                  </span>
                </div>
                
                <ul className="divide-y divide-gray-200">
                  {filteredChats.map((chat) => (
                    <li key={chat.id} className="hover:bg-gray-50">
                      <div className="flex items-center px-4 py-4">
                        <input
                          type="checkbox"
                          checked={selectedChats.includes(chat.id)}
                          onChange={() => handleSelectChat(chat.id)}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded ml-4"
                        />
                        
                        <div 
                          className="flex-1 min-w-0 cursor-pointer"
                          onClick={() => handleChatClick(chat.id)}
                        >
                          <div className="flex justify-between items-start">
                            <h3 className="text-sm font-medium text-gray-900 truncate">{chat.title}</h3>
                            <div className="flex items-center text-xs text-gray-500">
                              <Calendar className="h-3 w-3 mr-1" />
                              {formatDate(chat.date)}
                            </div>
                          </div>
                          <p className="mt-1 text-sm text-gray-500 truncate">{chat.preview}</p>
                          <div className="mt-1 flex items-center">
                            <MessageSquare className="h-3 w-3 text-gray-400 mr-1" />
                            <span className="text-xs text-gray-400">{chat.messageCount} رسالة</span>
                          </div>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            ) : (
              <div className="py-12 px-4 text-center">
                <MessageSquare className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-1">لا توجد محادثات</h3>
                <p className="text-gray-500 mb-4">لم يتم العثور على أي محادثات تطابق معايير البحث</p>
                {searchTerm && (
                  <button
                    onClick={() => setSearchTerm('')}
                    className="text-blue-600 hover:text-blue-800"
                  >
                    مسح البحث
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatHistory;
