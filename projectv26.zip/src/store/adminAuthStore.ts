import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { supabase } from '../lib/supabase';

// تعريف نوع بيانات المشرف
export interface AdminUser {
  id: string;
  email: string;
  name?: string;
  role: 'super_admin' | 'content_admin' | 'moderator';
  created_at: string;
  last_login?: string;
  avatar?: string;
}

// تعريف حالة مخزن المشرف
interface AdminAuthState {
  adminUser: AdminUser | null;
  isLoading: boolean;
  error: string | null;
  signInAdmin: (email: string, password: string) => Promise<void>;
  signOutAdmin: () => Promise<void>;
  changeAdminPassword: (oldPassword: string, newPassword: string) => Promise<void>;
  setAdminUser: (user: AdminUser | null) => void;
}

// إنشاء مخزن المشرف
export const useAdminAuthStore = create<AdminAuthState>()(
  persist(
    (set, get) => ({
      adminUser: null,
      isLoading: false,
      error: null,

      // تعيين مستخدم المشرف
      setAdminUser: (user) => {
        set({ adminUser: user });
      },

      // تسجيل دخول المشرف
      signInAdmin: async (email: string, password: string) => {
        set({ isLoading: true, error: null });
        try {
          console.log('Attempting to sign in admin with email:', email);

          // استخدام الوظيفة الجديدة للتحقق من صحة بيانات المشرف
          const { data, error } = await supabase.rpc('verify_admin_login', {
            admin_email: email,
            admin_password: password
          });

          if (error) {
            console.error('Admin login error:', error);
            // إذا كان الخطأ متعلق بحقل avatar، نستخدم صورة افتراضية
            if (error.message.includes('avatar')) {
              // محاولة تسجيل الدخول مرة أخرى بعد إصلاح وظيفة SQL
              console.log('Retrying admin login after SQL function fix...');
              set({ error: 'جاري إعادة المحاولة...' });

              // إعادة تحميل الصفحة لتطبيق التغييرات الجديدة
              window.location.reload();
              return;
            } else {
              set({ error: error.message });
              throw new Error(error.message);
            }
          }

          if (!data || !data.success) {
            const message = data ? data.message : 'فشل تسجيل الدخول';
            console.error('Admin login failed:', message);
            set({ error: message });
            throw new Error(message);
          }

          // التأكد من وجود بيانات المشرف
          if (!data.admin) {
            console.error('Admin login successful but no admin data returned');
            set({ error: 'تم تسجيل الدخول بنجاح ولكن لم يتم إرجاع بيانات المشرف' });
            throw new Error('تم تسجيل الدخول بنجاح ولكن لم يتم إرجاع بيانات المشرف');
          }

          // إضافة صورة افتراضية إذا لم تكن موجودة
          const adminData = {
            ...data.admin,
            avatar: data.admin.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(data.admin.name || data.admin.email)}&background=random`
          };

          console.log('Admin login successful:', adminData);

          // تأخير قصير لضمان تحديث الواجهة بشكل صحيح
          await new Promise(resolve => setTimeout(resolve, 300));

          set({ adminUser: adminData });
        } catch (error: any) {
          console.error('Error in signInAdmin:', error);
          set({ error: error.message });
          throw error;
        } finally {
          set({ isLoading: false });
        }
      },

      // تسجيل خروج المشرف
      signOutAdmin: async () => {
        set({ isLoading: true, error: null });
        try {
          // لا نحتاج إلى تسجيل الخروج من Supabase هنا
          // فقط نقوم بمسح بيانات المشرف من المخزن
          set({ adminUser: null });

          // تأخير قصير لضمان تحديث الواجهة بشكل صحيح
          await new Promise(resolve => setTimeout(resolve, 300));
        } catch (error: any) {
          console.error('Error in signOutAdmin:', error);
          set({ error: error.message });
          throw error;
        } finally {
          set({ isLoading: false });
        }
      },

      // تغيير كلمة مرور المشرف
      changeAdminPassword: async (oldPassword: string, newPassword: string) => {
        set({ isLoading: true, error: null });
        try {
          const adminUser = get().adminUser;
          if (!adminUser) {
            throw new Error('No admin user logged in');
          }

          // استخدام الوظيفة الجديدة لتغيير كلمة مرور المشرف
          const { data, error } = await supabase.rpc('change_admin_password', {
            admin_email: adminUser.email,
            old_password: oldPassword,
            new_password: newPassword
          });

          if (error) {
            console.error('Change admin password error:', error);
            set({ error: error.message });
            throw new Error(error.message);
          }

          if (!data.success) {
            console.error('Change admin password failed:', data.message);
            set({ error: data.message });
            throw new Error(data.message);
          }

          console.log('Admin password changed successfully');
        } catch (error: any) {
          console.error('Error in changeAdminPassword:', error);
          set({ error: error.message });
          throw error;
        } finally {
          set({ isLoading: false });
        }
      }
    }),
    {
      name: 'admin-auth-storage', // اسم مخزن المشرف في localStorage
      partialize: (state) => ({
        adminUser: state.adminUser
      })
    }
  )
);
