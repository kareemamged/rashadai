import React from 'react';
import Layout from '../../components/Layout';

const Cookies = () => {
  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-4xl font-bold text-gray-900 mb-8">Cookie Policy</h1>
            
            <div className="bg-white rounded-xl shadow-lg p-8 space-y-8">
              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">What Are Cookies</h2>
                <p className="text-gray-700 leading-relaxed">
                  Cookies are small text files that are placed on your computer or mobile device when you visit our website. They are widely used to make websites work more efficiently and provide useful information to website owners.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">How We Use Cookies</h2>
                <ul className="list-disc pl-6 space-y-2 text-gray-700">
                  <li>To remember your preferences and settings</li>
                  <li>To keep you signed in to your account</li>
                  <li>To understand how you use our website</li>
                  <li>To improve our services based on your usage</li>
                  <li>To provide personalized content and recommendations</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Types of Cookies We Use</h2>
                <div className="space-y-4">
                  <div>
                    <h3 className="font-semibold text-gray-800">Essential Cookies</h3>
                    <p className="text-gray-700">Required for the website to function properly. Cannot be disabled.</p>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800">Functional Cookies</h3>
                    <p className="text-gray-700">Remember your preferences and settings.</p>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800">Analytics Cookies</h3>
                    <p className="text-gray-700">Help us understand how visitors use our website.</p>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800">Marketing Cookies</h3>
                    <p className="text-gray-700">Used to deliver relevant advertisements and track their effectiveness.</p>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Managing Cookies</h2>
                <p className="text-gray-700 leading-relaxed">
                  You can control and manage cookies in various ways:
                </p>
                <ul className="list-disc pl-6 mt-4 space-y-2 text-gray-700">
                  <li>Browser settings to block or delete cookies</li>
                  <li>Our cookie consent tool to manage preferences</li>
                  <li>Third-party opt-out tools for specific services</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Third-Party Cookies</h2>
                <p className="text-gray-700 leading-relaxed">
                  Some cookies are placed by third-party services that appear on our pages:
                </p>
                <ul className="list-disc pl-6 mt-4 space-y-2 text-gray-700">
                  <li>Analytics (e.g., Google Analytics)</li>
                  <li>Social media plugins</li>
                  <li>Payment processors</li>
                  <li>Advertising networks</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Updates to This Policy</h2>
                <p className="text-gray-700 leading-relaxed">
                  We may update this Cookie Policy from time to time. We will notify you of any changes by posting the new policy on this page and updating the "Last Updated" date.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Contact Us</h2>
                <p className="text-gray-700 leading-relaxed">
                  If you have any questions about our Cookie Policy, please contact us:
                </p>
                <div className="mt-4 text-gray-700">
                  <p>Email: privacy@medai.com</p>
                  <p>Phone: (555) 123-4567</p>
                </div>
              </section>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Cookies;