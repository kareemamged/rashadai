export interface Country {
  code: string;
  name: string;
  flag: string;
}

export const countries: Country[] = [
  { code: 'SA', name: 'المملكة العربية السعودية', flag: '🇸🇦' },
  { code: 'AE', name: 'الإمارات العربية المتحدة', flag: '🇦🇪' },
  { code: 'KW', name: 'الكويت', flag: '🇰🇼' },
  { code: 'QA', name: 'قطر', flag: '🇶🇦' },
  { code: 'BH', name: 'البحرين', flag: '🇧🇭' },
  { code: 'OM', name: 'عمان', flag: '🇴🇲' },
  { code: 'EG', name: 'مصر', flag: '🇪🇬' },
  { code: 'JO', name: 'الأردن', flag: '🇯🇴' },
  { code: 'IQ', name: 'العراق', flag: '🇮🇶' },
  { code: 'LB', name: 'لبنان', flag: '🇱🇧' },
  { code: 'PS', name: 'فلسطين', flag: '🇵🇸' },
  { code: 'SY', name: 'سوريا', flag: '🇸🇾' },
  { code: 'YE', name: 'اليمن', flag: '🇾🇪' },
  { code: 'LY', name: 'ليبيا', flag: '🇱🇾' },
  { code: 'TN', name: 'تونس', flag: '🇹🇳' },
  { code: 'DZ', name: 'الجزائر', flag: '🇩🇿' },
  { code: 'MA', name: 'المغرب', flag: '🇲🇦' },
  { code: 'SD', name: 'السودان', flag: '🇸🇩' },
  { code: 'SO', name: 'الصومال', flag: '🇸🇴' },
  { code: 'MR', name: 'موريتانيا', flag: '🇲🇷' },
  { code: 'DJ', name: 'جيبوتي', flag: '🇩🇯' },
  { code: 'KM', name: 'جزر القمر', flag: '🇰🇲' },
  { code: 'US', name: 'الولايات المتحدة', flag: '🇺🇸' },
  { code: 'GB', name: 'المملكة المتحدة', flag: '🇬🇧' },
  { code: 'CA', name: 'كندا', flag: '🇨🇦' },
  { code: 'AU', name: 'أستراليا', flag: '🇦🇺' },
  { code: 'FR', name: 'فرنسا', flag: '🇫🇷' },
  { code: 'DE', name: 'ألمانيا', flag: '🇩🇪' },
  { code: 'IT', name: 'إيطاليا', flag: '🇮🇹' },
  { code: 'ES', name: 'إسبانيا', flag: '🇪🇸' },
];

export const getCountryByCode = (code: string): Country | undefined => {
  return countries.find(country => country.code === code);
};

export const getDefaultCountry = (): Country => {
  return countries[0]; // السعودية كدولة افتراضية
};
