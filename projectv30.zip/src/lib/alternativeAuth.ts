import { supabase } from './supabase';
import { User } from '../store/authStore';
import * as CryptoJS from 'crypto-js';

// مفتاح التشفير للجلسة المحلية - يجب أن يكون سرياً
const ENCRYPTION_KEY = 'rashadai-secure-key-2024';

// مسح أي تجزئات كلمات مرور مخزنة في localStorage عند تحميل الملف
if (typeof window !== 'undefined') {
  try {
    const storageKeys = Object.keys(localStorage);
    const passwordHashKeys = storageKeys.filter(key => key.startsWith('password_hash_'));

    // مسح كل مفاتيح تجزئات كلمات المرور
    passwordHashKeys.forEach(key => {
      localStorage.removeItem(key);
    });

    if (passwordHashKeys.length > 0) {
      console.log(`Cleared ${passwordHashKeys.length} stored password hashes from localStorage`);
    }
  } catch (error) {
    console.error('Error clearing password hashes from localStorage:', error);
  }
}

/**
 * تسجيل الدخول باستخدام البريد الإلكتروني وكلمة المرور
 * هذه الوظيفة تتجاوز نظام Supabase Auth وتستخدم جدول profiles مباشرة
 */
export const alternativeSignIn = async (email: string, password: string) => {
  try {
    console.log('Using alternative sign in method for:', email);

    // 1. التحقق من وجود المستخدم في جدول profiles
    const { data: profileData, error: profileError } = await supabase
      .from('profiles')
      .select('*')
      .eq('email', email)
      .single();

    if (profileError) {
      console.error('Error fetching profile:', profileError);
      throw new Error('Invalid login credentials');
    }

    if (!profileData) {
      console.error('User not found in profiles table');
      throw new Error('Invalid login credentials');
    }

    // 2. التحقق من كلمة المرور باستخدام وظيفة RPC مخصصة
    // نستخدم وظيفة verify_password إذا كانت متاحة
    try {
      // استخدام أسماء المعلمات الصحيحة (email_param و password_param) بدلاً من (p_email و p_password)
      const { data: verifyData, error: verifyError } = await supabase.rpc(
        'verify_password',
        { email_param: email, password_param: password }
      );

      if (verifyError) {
        console.warn('Error verifying password with RPC:', verifyError);
        // إذا فشلت وظيفة RPC، نرمي خطأ لإيقاف عملية تسجيل الدخول
        throw new Error('Invalid login credentials');
      } else if (verifyData && verifyData.success === true) {
        console.log('Password verified successfully with RPC');
        // كلمة المرور صحيحة، نستمر في إنشاء الجلسة
      } else {
        console.warn('Password verification failed with RPC');
        throw new Error('Invalid login credentials');
      }
    } catch (verifyError) {
      console.error('Exception during password verification with RPC:', verifyError);
      // نرمي الخطأ مرة أخرى لإيقاف عملية تسجيل الدخول
      throw new Error('Invalid login credentials');
    }

    // 4. التحقق من حالة المستخدم
    if (profileData.status === 'blocked') {
      if (profileData.block_expires_at) {
        const expiresDate = new Date(profileData.block_expires_at);

        // التحقق من انتهاء مدة الحظر
        if (expiresDate > new Date()) {
          const options = { year: 'numeric', month: 'long', day: 'numeric' };
          const formattedDate = expiresDate.toLocaleDateString(undefined, options as Intl.DateTimeFormatOptions);
          throw new Error(`Your account is temporarily blocked until ${formattedDate}.`);
        }
      } else {
        throw new Error('Your account has been permanently blocked. Please contact support.');
      }
    }

    // 5. إنشاء كائن المستخدم
    const user: User = {
      id: profileData.id,
      email: profileData.email,
      created_at: profileData.created_at,
      name: profileData.name,
      avatar: profileData.avatar,
      country_code: profileData.country_code,
      phone: profileData.phone,
      bio: profileData.bio,
      language: profileData.language,
      website: profileData.website,
      gender: profileData.gender,
      birth_date: profileData.birth_date,
      profession: profileData.profession
    };

    // 6. إنشاء جلسة وتخزينها في localStorage
    const session = {
      user,
      expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // تنتهي بعد 7 أيام
      created_at: new Date().toISOString()
    };

    // تشفير الجلسة قبل تخزينها
    const encryptedSession = CryptoJS.AES.encrypt(
      JSON.stringify(session),
      ENCRYPTION_KEY
    ).toString();

    localStorage.setItem('alternative_session', encryptedSession);
    console.log('Alternative session created and stored');

    return { user };
  } catch (error) {
    console.error('Error in alternativeSignIn:', error);
    throw error;
  }
};

/**
 * تسجيل الخروج
 */
export const alternativeSignOut = () => {
  try {
    // مسح الجلسة من localStorage
    localStorage.removeItem('alternative_session');

    // مسح أي بيانات أخرى متعلقة بالمصادقة
    const storageKeys = Object.keys(localStorage);
    const authKeys = storageKeys.filter(key =>
      key.startsWith('sb-') ||
      key.includes('supabase') ||
      key === 'auth-storage' ||
      key === 'last_logged_in_email' ||
      key.startsWith('user_id_') ||
      key.startsWith('profile_') ||
      key.startsWith('avatar_') ||
      key.startsWith('password_hash_') // إضافة مسح تجزئات كلمات المرور المخزنة
    );

    // مسح كل مفتاح متعلق بالمصادقة
    authKeys.forEach(key => {
      localStorage.removeItem(key);
    });

    console.log('Alternative session cleared');
    return { success: true };
  } catch (error) {
    console.error('Error in alternativeSignOut:', error);
    return { success: false, error };
  }
};

/**
 * الحصول على المستخدم الحالي من الجلسة المخزنة
 */
export const getCurrentUserFromSession = (): User | null => {
  try {
    const encryptedSession = localStorage.getItem('alternative_session');
    if (!encryptedSession) {
      return null;
    }

    // فك تشفير الجلسة
    const decryptedSession = CryptoJS.AES.decrypt(
      encryptedSession,
      ENCRYPTION_KEY
    ).toString(CryptoJS.enc.Utf8);

    const session = JSON.parse(decryptedSession);

    // التحقق من صلاحية الجلسة
    if (new Date(session.expires_at) < new Date()) {
      console.log('Session has expired');
      localStorage.removeItem('alternative_session');
      return null;
    }

    return session.user;
  } catch (error) {
    console.error('Error getting current user from session:', error);
    return null;
  }
};

/**
 * تحديث الجلسة الحالية
 */
export const updateCurrentSession = (user: User) => {
  try {
    const currentUser = getCurrentUserFromSession();
    if (!currentUser) {
      console.error('No active session to update');
      return false;
    }

    const session = {
      user,
      expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // تمديد الجلسة لمدة 7 أيام
      created_at: new Date().toISOString()
    };

    // تشفير الجلسة قبل تخزينها
    const encryptedSession = CryptoJS.AES.encrypt(
      JSON.stringify(session),
      ENCRYPTION_KEY
    ).toString();

    localStorage.setItem('alternative_session', encryptedSession);
    console.log('Session updated successfully');
    return true;
  } catch (error) {
    console.error('Error updating session:', error);
    return false;
  }
};
