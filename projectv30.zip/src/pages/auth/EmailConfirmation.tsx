import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Activity, Mail, AlertCircle, CheckCircle, Clock, RefreshCw } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { resendConfirmationEmail, supabase } from '../../lib/supabase';
import { useToast } from '../../components/ToastContainer';
import LanguageSwitcher from '../../components/LanguageSwitcher';
import { useLanguageStore } from '../../store/languageStore';

const EmailConfirmation = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const location = useLocation();
  const { showToast } = useToast();
  const { language } = useLanguageStore();

  const [email, setEmail] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [resendStatus, setResendStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [countdown, setCountdown] = useState<number>(0);
  const [nextAvailableAt, setNextAvailableAt] = useState<Date | null>(null);
  const [emailSendCount, setEmailSendCount] = useState<number>(0);
  const [maxAttempts, setMaxAttempts] = useState<number>(5);

  // Extract email from location state or query params
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const emailParam = searchParams.get('email');

    if (location.state?.email) {
      setEmail(location.state.email);
    } else if (emailParam) {
      setEmail(emailParam);
    }

    if (location.state?.emailSendCount) {
      setEmailSendCount(location.state.emailSendCount);
    }

    if (location.state?.nextAvailableAt) {
      setNextAvailableAt(new Date(location.state.nextAvailableAt));
      const now = new Date();
      const diff = Math.max(0, Math.floor((new Date(location.state.nextAvailableAt).getTime() - now.getTime()) / 1000));
      setCountdown(diff);
    }
  }, [location]);

  // Countdown timer
  useEffect(() => {
    if (countdown <= 0) return;

    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [countdown]);

  const handleResendEmail = async () => {
    if (!email) {
      showToast(t('auth.emailConfirmation.enterEmail'), 'error');
      return;
    }

    if (countdown > 0) {
      showToast(t('auth.emailConfirmation.waitBeforeResend', { seconds: countdown }), 'error');
      return;
    }

    setIsLoading(true);
    setResendStatus('loading');

    try {
      // تمرير اللغة الحالية إلى وظيفة إعادة إرسال البريد الإلكتروني
      const result = await resendConfirmationEmail(email, undefined, language);
      console.log('Resend result:', result);

      if (result.success) {
        setResendStatus('success');
        showToast(t('auth.emailConfirmation.success'), 'success');

        // Update state with new information
        setEmailSendCount(result.email_send_count);
        if (result.next_available_at) {
          setNextAvailableAt(new Date(result.next_available_at));
          const now = new Date();
          const diff = Math.max(0, Math.floor((new Date(result.next_available_at).getTime() - now.getTime()) / 1000));
          setCountdown(diff);
        }
      } else {
        setResendStatus('error');
        showToast(result.message || t('auth.emailConfirmation.error'), 'error');

        if (result.next_available_at) {
          setNextAvailableAt(new Date(result.next_available_at));
          const now = new Date();
          const diff = Math.max(0, Math.floor((new Date(result.next_available_at).getTime() - now.getTime()) / 1000));
          setCountdown(diff);
        }
      }
    } catch (error: any) {
      console.error('Error resending confirmation email:', error);
      setResendStatus('error');
      showToast(error.message || t('auth.emailConfirmation.error'), 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const formatCountdown = (seconds: number): string => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative">
      {/* Language Switcher */}
      <LanguageSwitcher position="top-right" showLabel={true} />

      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <Mail className="h-12 w-12 text-blue-600" />
        </div>
        <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
          {t('auth.emailConfirmation.title')}
        </h2>
        <p className="mt-2 text-center text-sm text-gray-600">
          {t('auth.emailConfirmation.subtitle')}
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
          <div className="text-center mb-6">
            <AlertCircle className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
            <p className="text-lg font-medium">
              {t('auth.emailConfirmation.emailNotConfirmed')}
            </p>
            <p className="mt-2 text-gray-600">
              {t('auth.emailConfirmation.description')}
              <span className="font-bold block mt-1 text-gray-800 dir-ltr">{email}</span>
              {t('auth.emailConfirmation.checkInbox')}
            </p>
          </div>

          <div className="mt-6">
            <button
              onClick={handleResendEmail}
              disabled={isLoading || countdown > 0 || emailSendCount >= maxAttempts}
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary hover:brightness-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                t('auth.emailConfirmation.resending')
              ) : countdown > 0 ? (
                <>{t('auth.emailConfirmation.waitBeforeResend', { seconds: formatCountdown(countdown) })}</>
              ) : emailSendCount >= maxAttempts ? (
                t('auth.emailConfirmation.maxAttemptsReached')
              ) : (
                t('auth.emailConfirmation.resendButton')
              )}
            </button>
          </div>

          {emailSendCount > 0 && (
            <div className="mt-4 text-sm text-gray-600 text-center">
              <Clock className="inline-block h-4 w-4 mr-1" />
              {t('auth.emailConfirmation.attemptsRemaining', { count: maxAttempts - emailSendCount })}
            </div>
          )}

          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">{t('common.or')}</span>
              </div>
            </div>

            <div className="mt-4">
              <button
                onClick={async () => {
                  if (!email) {
                    showToast(t('auth.emailConfirmation.enterEmail'), 'error');
                    return;
                  }

                  setIsLoading(true);
                  try {
                    const { data, error } = await supabase.rpc('sync_email_confirmation', {
                      p_email: email
                    });

                    if (error) {
                      console.error('Error syncing email confirmation:', error);
                      showToast(error.message || t('auth.emailConfirmation.syncError'), 'error');
                    } else if (data.success) {
                      showToast(t('auth.emailConfirmation.syncSuccess'), 'success');
                      // إذا تم تأكيد البريد الإلكتروني بنجاح، توجيه المستخدم إلى صفحة تسجيل الدخول
                      if (data.confirmed) {
                        setTimeout(() => navigate('/login'), 1500);
                      }
                    } else {
                      showToast(data.message || t('auth.emailConfirmation.syncError'), 'info');
                    }
                  } catch (error: any) {
                    console.error('Error syncing email confirmation:', error);
                    showToast(error.message || t('auth.emailConfirmation.syncError'), 'error');
                  } finally {
                    setIsLoading(false);
                  }
                }}
                className="w-full flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                {t('auth.emailConfirmation.syncConfirmation')}
              </button>
            </div>

            <div className="mt-4 text-center">
              <Link to="/login" className="text-primary hover:text-primary-dark">
                {t('auth.emailConfirmation.backToLogin')}
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmailConfirmation;
