import React from 'react';
import Layout from '../../components/Layout';
import { Shield, FileText, Eye, Lock } from 'lucide-react';

const PrivacyPolicy: React.FC = () => {
  return (
    <Layout>
      <div className="pt-24 pb-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          {/* Hero Section */}
          <div className="max-w-4xl mx-auto text-center mb-16">
            <h1 className="text-4xl font-bold text-gray-900 mb-6">
              Privacy Policy
            </h1>
            <p className="text-xl text-gray-600 leading-relaxed">
              How we collect, use, and protect your personal information.
            </p>
            <div className="flex justify-center mt-8">
              <span className="text-sm text-gray-500">Last Updated: May 5, 2025</span>
            </div>
          </div>

          {/* Main Content */}
          <div className="max-w-4xl mx-auto bg-white p-8 rounded-xl shadow-md mb-12">
            <div className="prose prose-lg max-w-none prose-blue">
              <section className="mb-12">
                <h2 className="flex items-center text-2xl font-bold text-gray-900 mb-4">
                  <FileText className="h-6 w-6 text-blue-600 mr-2" />
                  Introduction
                </h2>
                <p className="text-gray-700 mb-4">
                  RashadAI ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our service.
                </p>
                <p className="text-gray-700">
                  Please read this Privacy Policy carefully. By accessing or using our platform, you acknowledge that you have read, understood, and agree to be bound by all the terms of this Privacy Policy. If you do not agree with our policies and practices, please do not use our services.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="flex items-center text-2xl font-bold text-gray-900 mb-4">
                  <Eye className="h-6 w-6 text-blue-600 mr-2" />
                  Information We Collect
                </h2>
                <p className="text-gray-700 mb-4">
                  We collect several types of information from and about users of our platform:
                </p>
                <ul className="list-disc pl-6 space-y-2 text-gray-700">
                  <li><strong>Personal Information:</strong> This includes information that can identify you as an individual, such as your name, email address, telephone number, and postal address.</li>
                  <li><strong>Health Information:</strong> Information about your health conditions, medical history, and other health-related data that you provide during consultations.</li>
                  <li><strong>Usage Data:</strong> Information about how you access and use our platform, including your IP address, browser type, device information, pages visited, and time spent on the platform.</li>
                  <li><strong>Communication Data:</strong> Records of your communications with us, including customer support inquiries and feedback.</li>
                </ul>
              </section>

              <section className="mb-12">
                <h2 className="flex items-center text-2xl font-bold text-gray-900 mb-4">
                  <FileText className="h-6 w-6 text-blue-600 mr-2" />
                  How We Use Your Information
                </h2>
                <p className="text-gray-700 mb-4">
                  We use the information we collect for various purposes, including:
                </p>
                <ul className="list-disc pl-6 space-y-2 text-gray-700">
                  <li>To provide and maintain our services</li>
                  <li>To process and complete transactions</li>
                  <li>To send you service-related notifications</li>
                  <li>To respond to your inquiries and provide customer support</li>
                  <li>To improve our platform and user experience</li>
                  <li>To monitor usage patterns and analyze trends</li>
                  <li>To protect against fraudulent or unauthorized activity</li>
                  <li>To comply with legal obligations</li>
                </ul>
              </section>

              <section className="mb-12">
                <h2 className="flex items-center text-2xl font-bold text-gray-900 mb-4">
                  <Shield className="h-6 w-6 text-blue-600 mr-2" />
                  Information Sharing and Disclosure
                </h2>
                <p className="text-gray-700 mb-4">
                  We may share your information in the following circumstances:
                </p>
                <ul className="list-disc pl-6 space-y-2 text-gray-700">
                  <li><strong>With Service Providers:</strong> We may share your information with third-party vendors who provide services on our behalf, such as hosting, data analysis, payment processing, and customer service.</li>
                  <li><strong>For Legal Reasons:</strong> We may disclose your information if required by law, such as to comply with a subpoena or similar legal process.</li>
                  <li><strong>With Your Consent:</strong> We may share your information with third parties when you have given us your consent to do so.</li>
                  <li><strong>Business Transfers:</strong> In the event of a merger, acquisition, or sale of all or a portion of our assets, your information may be transferred as part of the transaction.</li>
                </ul>
                <p className="text-gray-700 mt-4">
                  We do not sell, rent, or lease your personal information to third parties.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="flex items-center text-2xl font-bold text-gray-900 mb-4">
                  <Lock className="h-6 w-6 text-blue-600 mr-2" />
                  Data Security
                </h2>
                <p className="text-gray-700 mb-4">
                  We implement appropriate technical and organizational measures to protect your personal information:
                </p>
                <ul className="list-disc pl-6 space-y-2 text-gray-700">
                  <li>End-to-end encryption for data transmission</li>
                  <li>Secure data storage with encryption at rest</li>
                  <li>Regular security assessments and penetration testing</li>
                  <li>Access controls and authentication mechanisms</li>
                  <li>Employee training on data protection and privacy</li>
                </ul>
                <p className="text-gray-700 mt-4">
                  While we strive to use commercially acceptable means to protect your personal information, no method of transmission over the Internet or method of electronic storage is 100% secure. We cannot guarantee absolute security.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="flex items-center text-2xl font-bold text-gray-900 mb-4">
                  <FileText className="h-6 w-6 text-blue-600 mr-2" />
                  Your Rights
                </h2>
                <p className="text-gray-700 mb-4">
                  Depending on your location, you may have certain rights regarding your personal information:
                </p>
                <ul className="list-disc pl-6 space-y-2 text-gray-700">
                  <li><strong>Access:</strong> You can request access to your personal information.</li>
                  <li><strong>Correction:</strong> You can request that we correct inaccurate or incomplete information.</li>
                  <li><strong>Deletion:</strong> You can request that we delete your personal information in certain circumstances.</li>
                  <li><strong>Restriction:</strong> You can request that we restrict the processing of your information.</li>
                  <li><strong>Data Portability:</strong> You can request a copy of your information in a structured, commonly used, and machine-readable format.</li>
                  <li><strong>Objection:</strong> You can object to our processing of your personal information.</li>
                </ul>
                <p className="text-gray-700 mt-4">
                  To exercise any of these rights, please contact us using the information provided in the "Contact Us" section.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="flex items-center text-2xl font-bold text-gray-900 mb-4">
                  <FileText className="h-6 w-6 text-blue-600 mr-2" />
                  Children's Privacy
                </h2>
                <p className="text-gray-700 mb-4">
                  Our services are not intended for individuals under the age of 18. We do not knowingly collect personal information from children. If you are a parent or guardian and believe that your child has provided us with personal information, please contact us, and we will take steps to delete such information.
                </p>
              </section>

              <section className="mb-12">
                <h2 className="flex items-center text-2xl font-bold text-gray-900 mb-4">
                  <FileText className="h-6 w-6 text-blue-600 mr-2" />
                  Changes to This Privacy Policy
                </h2>
                <p className="text-gray-700 mb-4">
                  We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last Updated" date. You are advised to review this Privacy Policy periodically for any changes.
                </p>
              </section>

              <section>
                <h2 className="flex items-center text-2xl font-bold text-gray-900 mb-4">
                  <FileText className="h-6 w-6 text-blue-600 mr-2" />
                  Contact Us
                </h2>
                <p className="text-gray-700 mb-4">
                  If you have any questions about this Privacy Policy, please contact us:
                </p>
                <address className="text-gray-700 not-italic">
                  Privacy Officer<br />
                  RashadAI, Inc.<br />
                  123 Innovation Way<br />
                  San Francisco, CA 94103<br />
                  Email: privacy@rashadai.com<br />
                  Phone: +201286904277
                </address>
              </section>
            </div>
          </div>

          {/* Additional Links */}
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-blue-50 p-6 rounded-xl">
                <h3 className="text-lg font-semibold text-gray-800 mb-2">HIPAA Compliance</h3>
                <p className="text-gray-600 mb-4">Learn about our healthcare data protection practices.</p>
                <a href="/hipaa-compliance" className="text-blue-600 hover:text-blue-800 font-medium">Read HIPAA Statement →</a>
              </div>
              <div className="bg-blue-50 p-6 rounded-xl">
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Terms and Conditions</h3>
                <p className="text-gray-600 mb-4">Understand the terms governing the use of our services.</p>
                <a href="/terms" className="text-blue-600 hover:text-blue-800 font-medium">Read Terms →</a>
              </div>
              <div className="bg-blue-50 p-6 rounded-xl">
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Cookie Policy</h3>
                <p className="text-gray-600 mb-4">Details about how we use cookies on our website.</p>
                <a href="/cookies" className="text-blue-600 hover:text-blue-800 font-medium">Read Cookie Policy →</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default PrivacyPolicy;
