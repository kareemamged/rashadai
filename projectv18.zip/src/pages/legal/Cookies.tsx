import React, { useState } from 'react';
import Layout from '../../components/Layout';
import { Shield, FileText, Cookie, Settings, Bell, ExternalLink, Info, HelpCircle, ChevronDown, ChevronUp, Check, AlertCircle } from 'lucide-react';

const Cookies: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('all');
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  const toggleFaq = (index: number) => {
    if (activeFaq === index) {
      setActiveFaq(null);
    } else {
      setActiveFaq(index);
    }
  };

  const faqs = [
    {
      question: "What happens if I disable cookies?",
      answer: "Disabling cookies may affect your browsing experience. Essential cookies are necessary for the website to function properly. If you disable functional or analytics cookies, some features may not work as expected."
    },
    {
      question: "Do you use cookies to track my personal information?",
      answer: "We use cookies to improve your experience on our website, but we do not use them to collect personally identifiable information without your consent. Our analytics cookies collect anonymous data to help us understand how users interact with our website."
    },
    {
      question: "How long do cookies stay on my device?",
      answer: "The duration varies depending on the type of cookie. Session cookies are temporary and expire when you close your browser. Persistent cookies remain on your device until they expire or you delete them manually."
    },
    {
      question: "Can I selectively allow certain cookies?",
      answer: "Yes, you can manage your cookie preferences through our cookie consent tool or your browser settings. This allows you to accept or reject specific categories of cookies based on your preferences."
    }
  ];

  return (
    <Layout>
      <div className="pt-24 pb-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          {/* Hero Section */}
          <div className="max-w-4xl mx-auto text-center mb-16">
            <h1 className="text-4xl font-bold text-gray-900 mb-6">
              Cookie Policy
            </h1>
            <p className="text-xl text-gray-600 leading-relaxed">
              Information about how RashadAI uses cookies and similar technologies on our platform.
            </p>
            <div className="flex justify-center mt-8">
              <span className="text-sm text-gray-500">Last Updated: May 10, 2024</span>
            </div>

            {/* Quick Navigation */}
            <div className="mt-8 flex flex-wrap justify-center gap-2">
              {['What Are Cookies', 'How We Use Cookies', 'Types of Cookies', 'Managing Cookies', 'Cookie Consent', 'FAQ'].map((section) => (
                <a
                  key={section}
                  href={`#${section.toLowerCase().replace(/\s+/g, '-')}`}
                  className="px-4 py-2 bg-blue-50 text-blue-600 rounded-full text-sm font-medium hover:bg-blue-100 transition-colors"
                >
                  {section}
                </a>
              ))}
            </div>
          </div>

          {/* Main Content */}
          <div className="max-w-4xl mx-auto bg-white p-8 rounded-xl shadow-md mb-12">
            <div className="prose prose-lg max-w-none prose-blue">
              <section id="what-are-cookies" className="mb-12">
                <h2 className="flex items-center text-2xl font-bold text-gray-900 mb-4">
                  <Cookie className="h-6 w-6 text-blue-600 mr-2" />
                  What Are Cookies
                </h2>
                <p className="text-gray-700 mb-4">
                  Cookies are small text files that are placed on your computer or mobile device when you visit our website.
                  They are widely used to make websites work more efficiently and provide useful information to website owners.
                </p>
                <p className="text-gray-700 mb-4">
                  Cookies allow us to recognize your device and provide you with a personalized experience on our website.
                  They also help us understand how our website is being used so we can improve its functionality and content.
                </p>
                <div className="bg-blue-50 p-4 rounded-lg mt-4">
                  <div className="flex items-start">
                    <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5 mr-2 flex-shrink-0" />
                    <p className="text-blue-800 text-sm">
                      When you visit our website for the first time, we will show you a cookie banner that allows you to choose
                      which types of cookies you want to accept. You can change your preferences at any time through our Cookie Consent tool.
                    </p>
                  </div>
                </div>
              </section>

              <section id="how-we-use-cookies" className="mb-12">
                <h2 className="flex items-center text-2xl font-bold text-gray-900 mb-4">
                  <Info className="h-6 w-6 text-blue-600 mr-2" />
                  How We Use Cookies
                </h2>
                <p className="text-gray-700 mb-4">
                  At RashadAI, we use cookies for various purposes, including:
                </p>
                <ul className="list-disc pl-6 space-y-2 text-gray-700">
                  <li><strong>Authentication and Security</strong> - To keep you signed in to your account and protect your data</li>
                  <li><strong>Preferences</strong> - To remember your settings and preferences for future visits</li>
                  <li><strong>Analytics</strong> - To understand how visitors interact with our website</li>
                  <li><strong>Performance</strong> - To improve the speed and functionality of our website</li>
                  <li><strong>Personalization</strong> - To provide personalized content and recommendations</li>
                  <li><strong>Functionality</strong> - To enhance the features and services available to you</li>
                </ul>
                <p className="text-gray-700 mt-4">
                  We respect your privacy and only use cookies that are necessary for the proper functioning of our website or that improve your experience.
                  You can control which cookies you accept through our Cookie Consent tool.
                </p>
              </section>

              <section id="types-of-cookies" className="mb-12">
                <h2 className="flex items-center text-2xl font-bold text-gray-900 mb-4">
                  <FileText className="h-6 w-6 text-blue-600 mr-2" />
                  Types of Cookies We Use
                </h2>

                {/* Cookie Type Tabs */}
                <div className="mb-6 border-b border-gray-200">
                  <ul className="flex flex-wrap -mb-px text-sm font-medium text-center">
                    <li className="mr-2">
                      <button
                        onClick={() => setActiveTab('all')}
                        className={`inline-block p-4 rounded-t-lg ${activeTab === 'all' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-600'}`}
                      >
                        All Cookies
                      </button>
                    </li>
                    <li className="mr-2">
                      <button
                        onClick={() => setActiveTab('essential')}
                        className={`inline-block p-4 rounded-t-lg ${activeTab === 'essential' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-600'}`}
                      >
                        Essential
                      </button>
                    </li>
                    <li className="mr-2">
                      <button
                        onClick={() => setActiveTab('functional')}
                        className={`inline-block p-4 rounded-t-lg ${activeTab === 'functional' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-600'}`}
                      >
                        Functional
                      </button>
                    </li>
                    <li className="mr-2">
                      <button
                        onClick={() => setActiveTab('analytics')}
                        className={`inline-block p-4 rounded-t-lg ${activeTab === 'analytics' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-600'}`}
                      >
                        Analytics
                      </button>
                    </li>
                    <li>
                      <button
                        onClick={() => setActiveTab('marketing')}
                        className={`inline-block p-4 rounded-t-lg ${activeTab === 'marketing' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-600'}`}
                      >
                        Marketing
                      </button>
                    </li>
                  </ul>
                </div>

                <div className="space-y-6">
                  {(activeTab === 'all' || activeTab === 'essential') && (
                    <div className="bg-gray-50 p-4 rounded-lg border-l-4 border-green-500">
                      <div className="flex items-center mb-2">
                        <Check className="h-5 w-5 text-green-500 mr-2" />
                        <h3 className="font-semibold text-gray-800">Essential Cookies</h3>
                      </div>
                      <p className="text-gray-700">
                        These cookies are required for the website to function properly. They enable core functionality such as security,
                        network management, and account access. You cannot disable these cookies as the website would not function properly without them.
                      </p>
                      <div className="mt-3 text-sm text-gray-500">
                        <span className="font-medium">Duration:</span> Session to 1 year
                      </div>
                    </div>
                  )}

                  {(activeTab === 'all' || activeTab === 'functional') && (
                    <div className="bg-gray-50 p-4 rounded-lg border-l-4 border-blue-500">
                      <div className="flex items-center mb-2">
                        <Check className="h-5 w-5 text-blue-500 mr-2" />
                        <h3 className="font-semibold text-gray-800">Functional Cookies</h3>
                      </div>
                      <p className="text-gray-700">
                        These cookies enable us to provide enhanced functionality and personalization. They may be set by us or by third-party
                        providers whose services we have added to our pages. If you disable these cookies, some or all of these services may not function properly.
                      </p>
                      <div className="mt-3 text-sm text-gray-500">
                        <span className="font-medium">Duration:</span> 30 days to 1 year
                      </div>
                    </div>
                  )}

                  {(activeTab === 'all' || activeTab === 'analytics') && (
                    <div className="bg-gray-50 p-4 rounded-lg border-l-4 border-purple-500">
                      <div className="flex items-center mb-2">
                        <Check className="h-5 w-5 text-purple-500 mr-2" />
                        <h3 className="font-semibold text-gray-800">Analytics Cookies</h3>
                      </div>
                      <p className="text-gray-700">
                        These cookies help us understand how visitors interact with our website by collecting and reporting information anonymously.
                        They allow us to count visits and traffic sources so we can measure and improve the performance of our site.
                      </p>
                      <div className="mt-3 text-sm text-gray-500">
                        <span className="font-medium">Duration:</span> 1 day to 2 years
                      </div>
                    </div>
                  )}

                  {(activeTab === 'all' || activeTab === 'marketing') && (
                    <div className="bg-gray-50 p-4 rounded-lg border-l-4 border-orange-500">
                      <div className="flex items-center mb-2">
                        <Check className="h-5 w-5 text-orange-500 mr-2" />
                        <h3 className="font-semibold text-gray-800">Marketing Cookies</h3>
                      </div>
                      <p className="text-gray-700">
                        These cookies are used to track visitors across websites. They are set to display targeted advertisements based on your interests
                        and online behavior. They also help measure the effectiveness of advertising campaigns.
                      </p>
                      <div className="mt-3 text-sm text-gray-500">
                        <span className="font-medium">Duration:</span> 30 days to 1 year
                      </div>
                    </div>
                  )}
                </div>

                {/* Cookie Table */}
                <div className="mt-8 overflow-hidden shadow ring-1 ring-black ring-opacity-5 rounded-lg">
                  <table className="min-w-full divide-y divide-gray-300">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900">Cookie Name</th>
                        <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Type</th>
                        <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Purpose</th>
                        <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Duration</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200 bg-white">
                      <tr>
                        <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900">auth_session</td>
                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">Essential</td>
                        <td className="px-3 py-4 text-sm text-gray-500">Authentication and session management</td>
                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">Session</td>
                      </tr>
                      <tr>
                        <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900">user_preferences</td>
                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">Functional</td>
                        <td className="px-3 py-4 text-sm text-gray-500">Stores user preferences and settings</td>
                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">1 year</td>
                      </tr>
                      <tr>
                        <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900">_ga</td>
                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">Analytics</td>
                        <td className="px-3 py-4 text-sm text-gray-500">Google Analytics - Distinguishes users</td>
                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">2 years</td>
                      </tr>
                      <tr>
                        <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900">_fbp</td>
                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">Marketing</td>
                        <td className="px-3 py-4 text-sm text-gray-500">Facebook Pixel - Tracks conversions</td>
                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">90 days</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </section>

              <section id="managing-cookies" className="mb-12">
                <h2 className="flex items-center text-2xl font-bold text-gray-900 mb-4">
                  <Settings className="h-6 w-6 text-blue-600 mr-2" />
                  Managing Cookies
                </h2>
                <p className="text-gray-700 mb-4">
                  You can control and manage cookies in various ways. Please keep in mind that removing or blocking cookies can impact your user experience
                  and parts of our website may no longer be fully accessible.
                </p>

                <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded mb-6">
                  <h3 className="text-lg font-semibold text-yellow-800 mb-2">Browser Controls</h3>
                  <p className="text-yellow-700">
                    Most browsers automatically accept cookies, but you can modify your browser settings to decline cookies or alert you when a website is attempting to place a cookie on your computer.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
                    <h3 className="font-semibold text-gray-800 mb-2">Google Chrome</h3>
                    <ol className="list-decimal pl-5 text-sm text-gray-700 space-y-1">
                      <li>Click the three dots in the top-right corner</li>
                      <li>Select "Settings"</li>
                      <li>Click on "Privacy and security"</li>
                      <li>Select "Cookies and other site data"</li>
                      <li>Choose your preferred cookie settings</li>
                    </ol>
                  </div>

                  <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
                    <h3 className="font-semibold text-gray-800 mb-2">Mozilla Firefox</h3>
                    <ol className="list-decimal pl-5 text-sm text-gray-700 space-y-1">
                      <li>Click the menu button (three lines) in the top-right</li>
                      <li>Select "Settings"</li>
                      <li>Click on "Privacy & Security"</li>
                      <li>Go to the "Cookies and Site Data" section</li>
                      <li>Choose your preferred cookie settings</li>
                    </ol>
                  </div>

                  <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
                    <h3 className="font-semibold text-gray-800 mb-2">Safari</h3>
                    <ol className="list-decimal pl-5 text-sm text-gray-700 space-y-1">
                      <li>Click "Safari" in the menu bar</li>
                      <li>Select "Preferences"</li>
                      <li>Go to the "Privacy" tab</li>
                      <li>Choose your cookie and website data settings</li>
                    </ol>
                  </div>

                  <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
                    <h3 className="font-semibold text-gray-800 mb-2">Microsoft Edge</h3>
                    <ol className="list-decimal pl-5 text-sm text-gray-700 space-y-1">
                      <li>Click the three dots in the top-right corner</li>
                      <li>Select "Settings"</li>
                      <li>Click on "Cookies and site permissions"</li>
                      <li>Select "Manage and delete cookies and site data"</li>
                      <li>Choose your preferred cookie settings</li>
                    </ol>
                  </div>
                </div>

                <p className="text-gray-700 mb-4">
                  You can manage your cookie preferences through:
                </p>
                <ul className="list-disc pl-6 mt-4 space-y-2 text-gray-700">
                  <li><strong>Browser settings</strong> - As shown above, to block or delete cookies</li>
                  <li><strong>Our cookie consent tool</strong> - Available at the bottom of our website to manage preferences</li>
                  <li><strong>Third-party opt-out tools</strong> - For specific services like Google Analytics (visit <a href="https://tools.google.com/dlpage/gaoptout" className="text-blue-600 hover:underline" target="_blank" rel="noopener noreferrer">Google Analytics Opt-out</a>)</li>
                </ul>
              </section>

              <section id="cookie-consent" className="mb-12">
                <h2 className="flex items-center text-2xl font-bold text-gray-900 mb-4">
                  <Check className="h-6 w-6 text-blue-600 mr-2" />
                  Cookie Consent
                </h2>
                <p className="text-gray-700 mb-4">
                  When you visit our website for the first time, you will see a cookie banner at the bottom of the screen. This banner allows you to:
                </p>
                <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-4">
                  <li>Accept all cookies</li>
                  <li>Reject non-essential cookies</li>
                  <li>Customize your cookie preferences</li>
                </ul>

                <div className="bg-gray-100 p-5 rounded-lg border border-gray-200 mb-6">
                  <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-4">
                    <div>
                      <h3 className="font-semibold text-gray-800 mb-2">Cookie Consent Example</h3>
                      <p className="text-sm text-gray-600">This is how our cookie consent banner appears on our website.</p>
                    </div>
                    <div className="flex space-x-2">
                      <button className="px-4 py-2 bg-gray-200 text-gray-700 rounded text-sm font-medium">Customize</button>
                      <button className="px-4 py-2 bg-gray-200 text-gray-700 rounded text-sm font-medium">Reject All</button>
                      <button className="px-4 py-2 bg-blue-600 text-white rounded text-sm font-medium">Accept All</button>
                    </div>
                  </div>
                  <p className="text-xs text-gray-500">
                    We use cookies to enhance your browsing experience, serve personalized ads or content, and analyze our traffic. By clicking "Accept All", you consent to our use of cookies.
                  </p>
                </div>

                <p className="text-gray-700 mb-4">
                  You can change your cookie preferences at any time by clicking on the "Cookie Settings" link in the footer of our website.
                </p>

                <div className="bg-blue-50 p-4 rounded-lg">
                  <div className="flex items-start">
                    <Info className="h-5 w-5 text-blue-600 mt-0.5 mr-2 flex-shrink-0" />
                    <p className="text-blue-800 text-sm">
                      Even if you reject all optional cookies, we will still set essential cookies that are necessary for the proper functioning of our website.
                      These cookies do not track your browsing activity for marketing purposes.
                    </p>
                  </div>
                </div>
              </section>

              <section id="third-party-cookies" className="mb-12">
                <h2 className="flex items-center text-2xl font-bold text-gray-900 mb-4">
                  <ExternalLink className="h-6 w-6 text-blue-600 mr-2" />
                  Third-Party Cookies
                </h2>
                <p className="text-gray-700 mb-4">
                  Some cookies are placed by third-party services that appear on our pages. We do not control these third parties or their cookies.
                  These cookies may be used by the third-party service providers to collect information about your online activities over time and across different websites.
                </p>
                <p className="text-gray-700 mb-4">
                  Third-party services we use that may place cookies include:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
                    <h3 className="font-semibold text-gray-800 mb-2">Analytics</h3>
                    <ul className="list-disc pl-5 text-sm text-gray-700">
                      <li>Google Analytics</li>
                      <li>Hotjar</li>
                      <li>Mixpanel</li>
                    </ul>
                  </div>
                  <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
                    <h3 className="font-semibold text-gray-800 mb-2">Social Media</h3>
                    <ul className="list-disc pl-5 text-sm text-gray-700">
                      <li>Facebook Pixel</li>
                      <li>Twitter</li>
                      <li>LinkedIn</li>
                    </ul>
                  </div>
                  <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
                    <h3 className="font-semibold text-gray-800 mb-2">Other Services</h3>
                    <ul className="list-disc pl-5 text-sm text-gray-700">
                      <li>Payment processors</li>
                      <li>Content delivery networks</li>
                      <li>Customer support tools</li>
                    </ul>
                  </div>
                </div>
                <p className="text-gray-700 mt-4">
                  Each of these third parties should have their own privacy policy and cookie policy which will govern their use of cookies.
                  You can find links to their policies on our <a href="/privacy" className="text-blue-600 hover:underline">Privacy Policy</a> page.
                </p>
              </section>

              <section id="faq" className="mb-12">
                <h2 className="flex items-center text-2xl font-bold text-gray-900 mb-4">
                  <HelpCircle className="h-6 w-6 text-blue-600 mr-2" />
                  Frequently Asked Questions
                </h2>
                <div className="space-y-4">
                  {faqs.map((faq, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg overflow-hidden">
                      <button
                        onClick={() => toggleFaq(index)}
                        className="w-full flex justify-between items-center p-4 text-left bg-gray-50 hover:bg-gray-100 transition-colors"
                      >
                        <span className="font-medium text-gray-900">{faq.question}</span>
                        {activeFaq === index ? (
                          <ChevronUp className="h-5 w-5 text-gray-500" />
                        ) : (
                          <ChevronDown className="h-5 w-5 text-gray-500" />
                        )}
                      </button>
                      {activeFaq === index && (
                        <div className="p-4 bg-white">
                          <p className="text-gray-700">{faq.answer}</p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </section>

              <section id="updates" className="mb-12">
                <h2 className="flex items-center text-2xl font-bold text-gray-900 mb-4">
                  <Bell className="h-6 w-6 text-blue-600 mr-2" />
                  Updates to This Policy
                </h2>
                <p className="text-gray-700 mb-4">
                  We may update this Cookie Policy from time to time to reflect changes in technology, regulation, or our business practices.
                  Any changes will become effective when we post the revised policy on this page.
                </p>
                <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 mb-4">
                  <h3 className="font-semibold text-gray-800 mb-2">Policy Update History</h3>
                  <ul className="text-sm text-gray-700 space-y-2">
                    <li><strong>May 10, 2024:</strong> Updated cookie policy with enhanced information about cookie types and management.</li>
                    <li><strong>January 15, 2024:</strong> Added information about third-party analytics providers.</li>
                    <li><strong>October 5, 2023:</strong> Initial cookie policy published.</li>
                  </ul>
                </div>
                <p className="text-gray-700">
                  We will notify you of any significant changes by posting a notice on our website or by sending you an email notification.
                  We encourage you to periodically review this page to stay informed about our use of cookies.
                </p>
              </section>

              <section id="contact-us">
                <h2 className="flex items-center text-2xl font-bold text-gray-900 mb-4">
                  <Shield className="h-6 w-6 text-blue-600 mr-2" />
                  Contact Us
                </h2>
                <p className="text-gray-700 mb-4">
                  If you have any questions about our Cookie Policy or how we use cookies, please contact us:
                </p>
                <div className="bg-white border border-gray-200 rounded-lg p-6 shadow-sm">
                  <address className="text-gray-700 not-italic">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <p className="font-medium mb-1">RashadAI, Inc.</p>
                        <p>123 Innovation Way</p>
                        <p>San Francisco, CA 94103</p>
                      </div>
                      <div>
                        <p><span className="font-medium">Email:</span> <a href="mailto:privacy@rashadai.com" className="text-blue-600 hover:underline">privacy@rashadai.com</a></p>
                        <p><span className="font-medium">Phone:</span> +201286904277</p>
                        <p><span className="font-medium">Hours:</span> Monday-Friday, 9am-5pm PT</p>
                      </div>
                    </div>
                  </address>
                </div>
              </section>
            </div>
          </div>

          {/* Additional Links */}
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-blue-50 p-6 rounded-xl">
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Terms and Conditions</h3>
                <p className="text-gray-600 mb-4">Our terms of service and user agreement.</p>
                <a href="/terms" className="text-blue-600 hover:text-blue-800 font-medium">Read Terms →</a>
              </div>
              <div className="bg-blue-50 p-6 rounded-xl">
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Privacy Policy</h3>
                <p className="text-gray-600 mb-4">Learn how we collect, use, and protect your personal information.</p>
                <a href="/privacy" className="text-blue-600 hover:text-blue-800 font-medium">Read Privacy Policy →</a>
              </div>
              <div className="bg-blue-50 p-6 rounded-xl">
                <h3 className="text-lg font-semibold text-gray-800 mb-2">HIPAA Compliance</h3>
                <p className="text-gray-600 mb-4">Details about our healthcare data protection practices.</p>
                <a href="/hipaa-compliance" className="text-blue-600 hover:text-blue-800 font-medium">Read HIPAA Statement →</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Cookies;