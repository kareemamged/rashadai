import React from 'react';
import Layout from '../components/Layout';
import {
  Stethoscope,
  Brain,
  MessageCircle,
  FileText,
  Clock,
  Shield,
  Users,
  Award,
  Zap,
  BookOpen,
  Activity,
  Heart
} from 'lucide-react';

const Services: React.FC = () => {
  return (
    <Layout>
      <div className="pt-24 pb-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          {/* Hero Section */}
          <div className="max-w-4xl mx-auto text-center mb-16">
            <h1 className="text-4xl font-bold text-gray-900 mb-6">
              Our Services
            </h1>
            <p className="text-xl text-gray-600 leading-relaxed">
              We provide a comprehensive range of AI-powered medical consultation services
            </p>
          </div>

          {/* Main Services Section */}
          <div className="max-w-7xl mx-auto mb-20">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">

              {/* AI Medical Consultation */}
              <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
                <div className="p-8">
                  <div className="flex items-center justify-center w-16 h-16 bg-blue-100 text-blue-600 rounded-full mb-6 mx-auto">
                    <Brain className="h-8 w-8" />
                  </div>
                  <h3 className="text-xl font-semibold text-center text-gray-900 mb-4">AI Medical Consultation</h3>
                  <p className="text-gray-600 text-center mb-6">
                    Instant consultations powered by the latest AI technology to answer your medical inquiries with accuracy and speed.
                  </p>
                  <div className="flex justify-center">
                    <a href="/consultation" className="text-blue-600 hover:text-blue-800 font-medium">Request Consultation →</a>
                  </div>
                </div>
              </div>

              {/* Specialist Consultation */}
              <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
                <div className="p-8">
                  <div className="flex items-center justify-center w-16 h-16 bg-blue-100 text-blue-600 rounded-full mb-6 mx-auto">
                    <Stethoscope className="h-8 w-8" />
                  </div>
                  <h3 className="text-xl font-semibold text-center text-gray-900 mb-4">Specialist Consultation <span className="text-sm font-normal text-amber-600 ml-1">(Coming Soon)</span></h3>
                  <p className="text-gray-600 text-center mb-6">
                    Connect with specialized doctors across various medical fields to get expert medical opinions and appropriate treatment plans.
                  </p>
                  <div className="flex justify-center">
                    <a href="/consultation" className="text-blue-600 hover:text-blue-800 font-medium">Book Appointment →</a>
                  </div>
                </div>
              </div>

              {/* Follow-up Care */}
              <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
                <div className="p-8">
                  <div className="flex items-center justify-center w-16 h-16 bg-blue-100 text-blue-600 rounded-full mb-6 mx-auto">
                    <Clock className="h-8 w-8" />
                  </div>
                  <h3 className="text-xl font-semibold text-center text-gray-900 mb-4">Continuous Follow-up <span className="text-sm font-normal text-amber-600 ml-1">(Coming Soon)</span></h3>
                  <p className="text-gray-600 text-center mb-6">
                    Periodic follow-up services to evaluate progress in health status and adjust treatment plans when needed.
                  </p>
                  <div className="flex justify-center">
                    <a href="/consultation" className="text-blue-600 hover:text-blue-800 font-medium">Request Follow-up →</a>
                  </div>
                </div>
              </div>

              {/* Medical Reports Analysis */}
              <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
                <div className="p-8">
                  <div className="flex items-center justify-center w-16 h-16 bg-blue-100 text-blue-600 rounded-full mb-6 mx-auto">
                    <FileText className="h-8 w-8" />
                  </div>
                  <h3 className="text-xl font-semibold text-center text-gray-900 mb-4">Medical Reports Analysis <span className="text-sm font-normal text-amber-600 ml-1">(Coming Soon)</span></h3>
                  <p className="text-gray-600 text-center mb-6">
                    Analysis and interpretation of test results and medical reports in simplified language with appropriate recommendations.
                  </p>
                  <div className="flex justify-center">
                    <a href="/consultation" className="text-blue-600 hover:text-blue-800 font-medium">Analyze Report →</a>
                  </div>
                </div>
              </div>

              {/* Health Chat */}
              <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
                <div className="p-8">
                  <div className="flex items-center justify-center w-16 h-16 bg-blue-100 text-blue-600 rounded-full mb-6 mx-auto">
                    <MessageCircle className="h-8 w-8" />
                  </div>
                  <h3 className="text-xl font-semibold text-center text-gray-900 mb-4">Health Chat</h3>
                  <p className="text-gray-600 text-center mb-6">
                    Instant conversation with our AI system to answer general health questions and provide medical advice.
                  </p>
                  <div className="flex justify-center">
                    <a href="/chat" className="text-blue-600 hover:text-blue-800 font-medium">Start Chat →</a>
                  </div>
                </div>
              </div>

              {/* Health Education */}
              <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
                <div className="p-8">
                  <div className="flex items-center justify-center w-16 h-16 bg-blue-100 text-blue-600 rounded-full mb-6 mx-auto">
                    <BookOpen className="h-8 w-8" />
                  </div>
                  <h3 className="text-xl font-semibold text-center text-gray-900 mb-4">Health Education</h3>
                  <p className="text-gray-600 text-center mb-6">
                    Comprehensive educational resources about various health conditions, disease prevention, and healthy lifestyle practices.
                  </p>
                  <div className="flex justify-center">
                    <a href="/blog" className="text-blue-600 hover:text-blue-800 font-medium">Browse Content →</a>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Premium Services Section */}
          <div className="max-w-4xl mx-auto text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Our Premium Services
            </h2>
            <p className="text-lg text-gray-600 leading-relaxed mb-12">
              Advanced services specially designed for specialized medical needs
            </p>
          </div>

          <div className="max-w-7xl mx-auto mb-20">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">

              {/* Premium Service 1 */}
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl shadow-md overflow-hidden p-8">
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <div className="flex items-center justify-center w-16 h-16 bg-blue-600 text-white rounded-full">
                      <Activity className="h-8 w-8" />
                    </div>
                  </div>
                  <div className="ml-6">
                    <h3 className="text-xl font-semibold text-gray-900 mb-3">Personalized Healthcare Plan</h3>
                    <p className="text-gray-600 mb-4">
                      Customized healthcare plan based on your medical history and personal needs, with periodic follow-up from a specialized medical team.
                    </p>
                    <ul className="list-disc list-inside text-gray-600 mb-4">
                      <li>Comprehensive health assessment</li>
                      <li>Customized treatment plan</li>
                      <li>Periodic follow-up with a specialist</li>
                      <li>Monthly progress reports</li>
                    </ul>
                    <a href="/consultation" className="text-blue-600 hover:text-blue-800 font-medium">Learn More →</a>
                  </div>
                </div>
              </div>

              {/* Premium Service 2 */}
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl shadow-md overflow-hidden p-8">
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <div className="flex items-center justify-center w-16 h-16 bg-blue-600 text-white rounded-full">
                      <Heart className="h-8 w-8" />
                    </div>
                  </div>
                  <div className="ml-6">
                    <h3 className="text-xl font-semibold text-gray-900 mb-3">Chronic Care Program</h3>
                    <p className="text-gray-600 mb-4">
                      Comprehensive program for managing chronic conditions such as diabetes, hypertension, and heart disease, with continuous monitoring and medical support.
                    </p>
                    <ul className="list-disc list-inside text-gray-600 mb-4">
                      <li>Vital signs monitoring</li>
                      <li>Treatment plan adjustments</li>
                      <li>Regular consultations</li>
                      <li>Psychological and nutritional support</li>
                    </ul>
                    <a href="/consultation" className="text-blue-600 hover:text-blue-800 font-medium">Learn More →</a>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Why Choose Us Section */}
          <div className="max-w-4xl mx-auto text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Why Choose Us?
            </h2>
            <p className="text-lg text-gray-600 leading-relaxed mb-12">
              We are committed to providing the best healthcare supported by the latest technologies
            </p>
          </div>

          <div className="max-w-7xl mx-auto mb-16">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">

              {/* Feature 1 */}
              <div className="text-center">
                <div className="flex items-center justify-center w-16 h-16 bg-blue-100 text-blue-600 rounded-full mb-4 mx-auto">
                  <Zap className="h-8 w-8" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Fast Response</h3>
                <p className="text-gray-600">
                  Instant consultations available 24/7 without the need to wait.
                </p>
              </div>

              {/* Feature 2 */}
              <div className="text-center">
                <div className="flex items-center justify-center w-16 h-16 bg-blue-100 text-blue-600 rounded-full mb-4 mx-auto">
                  <Award className="h-8 w-8" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">High Quality</h3>
                <p className="text-gray-600">
                  Distinguished medical team and advanced technologies to ensure accurate diagnosis and recommendations.
                </p>
              </div>

              {/* Feature 3 */}
              <div className="text-center">
                <div className="flex items-center justify-center w-16 h-16 bg-blue-100 text-blue-600 rounded-full mb-4 mx-auto">
                  <Shield className="h-8 w-8" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Privacy & Security</h3>
                <p className="text-gray-600">
                  Complete protection of your health data according to the highest security and privacy standards.
                </p>
              </div>

              {/* Feature 4 */}
              <div className="text-center">
                <div className="flex items-center justify-center w-16 h-16 bg-blue-100 text-blue-600 rounded-full mb-4 mx-auto">
                  <Users className="h-8 w-8" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Personal Care</h3>
                <p className="text-gray-600">
                  Customized services that suit your individual needs and medical history.
                </p>
              </div>
            </div>
          </div>

          {/* CTA Section */}
          <div className="max-w-4xl mx-auto bg-gradient-to-r from-blue-600 to-indigo-700 rounded-xl shadow-lg overflow-hidden">
            <div className="px-8 py-12 text-center">
              <h2 className="text-3xl font-bold text-white mb-4">
                Start Your Health Journey Today
              </h2>
              <p className="text-xl text-blue-100 mb-8">
                Get an instant medical consultation or connect with one of our specialist doctors
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <a href="/consultation" className="inline-block bg-white text-blue-700 font-semibold px-6 py-3 rounded-lg shadow hover:bg-blue-50 transition-colors duration-300">
                  Request Consultation
                </a>
                <a href="/chat" className="inline-block bg-transparent text-white border border-white font-semibold px-6 py-3 rounded-lg hover:bg-white hover:bg-opacity-10 transition-colors duration-300">
                  Start Chat
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Services;
