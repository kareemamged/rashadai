import React from 'react';
import { Facebook, Twitter, Instagram, Linkedin, Activity } from 'lucide-react';
import '../index.css';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center mb-4">
              <Activity className="h-8 w-8 text-blue-400 mr-2" />
              <span className="text-xl font-bold">RashadAI</span>
            </div>
            <p className="text-gray-400 mb-4">
              Revolutionizing healthcare with AI-powered medical consultations that are accessible, accurate, and affordable.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Services</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">AI Consultation</a></li>
              <li><a href="#soon" className="text-gray-400 opacity-25 disabled hover:text-white transition-colors">Health Monitoring</a></li>
              <li><a href="#soon" className="text-gray-400 opacity-25 disabled hover:text-white transition-colors">Specialist Referrals</a></li>
              <li><a href="#soon" className="text-gray-400 opacity-25 disabled hover:text-white transition-colors">Medication Management</a></li>
              <li><a href="#soon" className="text-gray-400 opacity-25 disabled hover:text-white transition-colors">Healthcare Plans</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Company</h3>
            <ul className="space-y-2">
              <li><a href="/services" className="text-gray-400 hover:text-white transition-colors">Services</a></li>
              <li><a href="/vision" className="text-gray-400 hover:text-white transition-colors">Our Vision</a></li>
              <li><a href="/blog" className="text-gray-400 hover:text-white transition-colors">Our Blog</a></li>
              <li><a href="/testimonials" className="text-gray-400 hover:text-white transition-colors">Testimonials</a></li>
              <li><a href="/about" className="text-gray-400 hover:text-white transition-colors">About Us</a></li>
              <li><a href="/contact" className="text-gray-400 hover:text-white transition-colors">Contact</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Legal</h3>
            <ul className="space-y-2">
              <li><a href="/terms" className="text-gray-400 hover:text-white transition-colors">Terms of Service</a></li>
              <li><a href="/privacy" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</a></li>
              <li><a href="/hipaa-compliance" className="text-gray-400 hover:text-white transition-colors">HIPAA Compliance</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-500 text-sm mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} RashadAI. All rights reserved.
          </p>
          <div className="flex space-x-6">
            <a href="/terms" className="text-gray-500 hover:text-white text-sm transition-colors">Terms</a>
            <a href="/privacy" className="text-gray-500 hover:text-white text-sm transition-colors">Privacy</a>
            <a href="/cookies" className="text-gray-500 hover:text-white text-sm transition-colors">Cookies</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;