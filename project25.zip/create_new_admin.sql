-- Script para crear un nuevo usuario administrador desde cero
-- Este script:
-- 1. Elimina el usuario existente si existe
-- 2. Crea un nuevo usuario en auth.users
-- 3. Crea un registro en admin_users
-- 4. Crea un registro en profiles (si es necesario)

-- Habilitar extensiones necesarias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

DO $$
DECLARE
  new_user_id UUID;
BEGIN
  -- Eliminar el usuario existente si existe
  DELETE FROM admin_users WHERE email = 'kemoamego@icloud.com';
  DELETE FROM profiles WHERE email = 'kemoamego@icloud.com';
  DELETE FROM auth.users WHERE email = 'kemoamego@icloud.com';
  
  -- Generar un nuevo UUID
  new_user_id := uuid_generate_v4();
  
  -- Crear un nuevo usuario en auth.users
  INSERT INTO auth.users (
    id,
    email,
    encrypted_password,
    email_confirmed_at,
    raw_user_meta_data,
    created_at,
    updated_at,
    role
  ) VALUES (
    new_user_id,
    'kemoamego@icloud.com',
    crypt('Kk1704048', gen_salt('bf')),
    NOW(), -- Email ya confirmado
    jsonb_build_object(
      'name', 'kareem amged',
      'avatar', 'https://ui-avatars.com/api/?name=kareem+amged&background=random',
      'country_code', 'EG',
      'language', 'ar'
    ),
    NOW(),
    NOW(),
    'authenticated'
  );
  
  -- Crear un registro en admin_users
  INSERT INTO admin_users (
    id,
    name,
    email,
    role,
    avatar,
    created_at,
    updated_at
  ) VALUES (
    new_user_id,
    'kareem amged',
    'kemoamego@icloud.com',
    'super_admin',
    'https://ui-avatars.com/api/?name=kareem+amged&background=random',
    NOW(),
    NOW()
  );
  
  -- Intentar crear un registro en profiles
  BEGIN
    INSERT INTO profiles (
      id,
      name,
      email,
      avatar,
      country_code,
      language,
      created_at,
      updated_at
    ) VALUES (
      new_user_id,
      'kareem amged',
      'kemoamego@icloud.com',
      'https://ui-avatars.com/api/?name=kareem+amged&background=random',
      'EG',
      'ar',
      NOW(),
      NOW()
    );
  EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'No se pudo crear el perfil, pero esto no es crítico para el acceso de administrador';
  END;
  
  RAISE NOTICE 'Nuevo usuario administrador creado con ID: %', new_user_id;
END $$;
