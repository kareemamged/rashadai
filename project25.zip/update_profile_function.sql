-- نسخة احتياطية أساسية لقاعدة البيانات
-- تاريخ النسخ: 2025-05-10 05:43:55.825213+00

BEGIN;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

-- إنشاء جدول public.access_logs
CREATE TABLE IF NOT EXISTS public.access_logs (
    id uuid DEFAULT uuid_generate_v4() NOT NULL,
    user_id uuid,
    action text NOT NULL,
    resource text NOT NULL,
    status text NOT NULL,
    ip_address text,
    user_agent text,
    created_at timestamp with time zone DEFAULT now()
);

-- إنشاء جدول public.admin_roles
CREATE TABLE IF NOT EXISTS public.admin_roles (
    id uuid DEFAULT uuid_generate_v4() NOT NULL,
    name text NOT NULL,
    description text,
    permissions jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);

-- إنشاء جدول public.admin_users
CREATE TABLE IF NOT EXISTS public.admin_users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    name text,
    password text NOT NULL,
    role text DEFAULT 'admin'::text,
    avatar text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);

-- إنشاء جدول public.auth_errors
CREATE TABLE IF NOT EXISTS public.auth_errors (
    id integer DEFAULT nextval('auth_errors_id_seq'::regclass) NOT NULL,
    error_message text,
    error_detail text,
    error_context text,
    created_at timestamp with time zone DEFAULT now()
);

-- إنشاء جدول public.blog_comments
CREATE TABLE IF NOT EXISTS public.blog_comments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    post_id uuid,
    user_id uuid,
    content text NOT NULL,
    likes_count integer DEFAULT 0,
    dislikes_count integer DEFAULT 0,
    approved boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);

-- إنشاء جدول public.blog_comments_old
CREATE TABLE IF NOT EXISTS public.blog_comments_old (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    post_id uuid,
    user_id uuid,
    user_name text NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);

-- إنشاء جدول public.blog_posts
CREATE TABLE IF NOT EXISTS public.blog_posts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    author_id uuid,
    title_en text NOT NULL,
    title_ar text NOT NULL,
    content_en text NOT NULL,
    content_ar text NOT NULL,
    category text NOT NULL,
    image_url text,
    likes_count integer DEFAULT 0,
    dislikes_count integer DEFAULT 0,
    published boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);

-- إنشاء جدول public.blog_posts_old
CREATE TABLE IF NOT EXISTS public.blog_posts_old (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    excerpt text,
    author_id uuid,
    author_name text NOT NULL,
    category text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    featured boolean DEFAULT false,
    publish_date timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    views integer DEFAULT 0,
    likes integer DEFAULT 0
);

-- إنشاء جدول public.consultations
CREATE TABLE IF NOT EXISTS public.consultations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    doctor_id uuid,
    title text NOT NULL,
    description text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    category text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    scheduled_at timestamp with time zone,
    completed_at timestamp with time zone
);

-- إنشاء جدول public.debug_logs
CREATE TABLE IF NOT EXISTS public.debug_logs (
    id integer DEFAULT nextval('debug_logs_id_seq'::regclass) NOT NULL,
    operation text,
    user_id uuid,
    data jsonb,
    notes text,
    created_at timestamp with time zone DEFAULT now()
);

-- إنشاء جدول public.design_settings
CREATE TABLE IF NOT EXISTS public.design_settings (
    id uuid DEFAULT uuid_generate_v4() NOT NULL,
    colors jsonb NOT NULL,
    fonts jsonb NOT NULL,
    logo text,
    favicon text,
    is_active boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);

-- إنشاء جدول public.design_themes
CREATE TABLE IF NOT EXISTS public.design_themes (
    id uuid DEFAULT uuid_generate_v4() NOT NULL,
    name text NOT NULL,
    description text,
    colors jsonb NOT NULL,
    fonts jsonb NOT NULL,
    logo text,
    favicon text,
    is_active boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);

-- إنشاء جدول public.doctors
CREATE TABLE IF NOT EXISTS public.doctors (
    id uuid NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    specialty text NOT NULL,
    bio text,
    avatar text,
    years_experience integer,
    rating numeric DEFAULT 0,
    available boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);

-- إنشاء جدول public.notifications
CREATE TABLE IF NOT EXISTS public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    title text NOT NULL,
    message text NOT NULL,
    type text DEFAULT 'info'::text NOT NULL,
    read boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    action_url text
);

-- إنشاء جدول public.profile_updates_log
CREATE TABLE IF NOT EXISTS public.profile_updates_log (
    id integer DEFAULT nextval('profile_updates_log_id_seq'::regclass) NOT NULL,
    user_id uuid NOT NULL,
    updated_fields jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

-- إنشاء جدول public.profiles
CREATE TABLE IF NOT EXISTS public.profiles (
    id uuid NOT NULL,
    email text,
    name text,
    avatar text,
    country_code text,
    phone text,
    bio text,
    language text DEFAULT 'ar'::text,
    website text,
    gender text,
    birth_date date,
    profession text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);

-- إنشاء جدول public.site_settings
CREATE TABLE IF NOT EXISTS public.site_settings (
    id integer DEFAULT 1 NOT NULL,
    site_name text DEFAULT 'Medical Consultation Platform'::text NOT NULL,
    site_description text,
    contact_email text,
    contact_phone text,
    social_links jsonb DEFAULT '{}'::jsonb,
    theme_settings jsonb DEFAULT '{}'::jsonb,
    updated_at timestamp with time zone DEFAULT now(),
    updated_by uuid
);

-- إنشاء جدول public.testimonials
CREATE TABLE IF NOT EXISTS public.testimonials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    user_name text NOT NULL,
    content text NOT NULL,
    rating integer NOT NULL,
    approved boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);

-- إنشاء جدول public.user_reports
CREATE TABLE IF NOT EXISTS public.user_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    title text NOT NULL,
    description text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    resolved_at timestamp with time zone,
    resolved_by uuid,
    resolution_notes text
);

-- إنشاء جدول public.visitors
CREATE TABLE IF NOT EXISTS public.visitors (
    id uuid DEFAULT uuid_generate_v4() NOT NULL,
    ip_address text,
    user_agent text,
    page_visited text,
    referrer text,
    user_id uuid,    created_at timestamp with time zone DEFAULT now()
);

COMMIT;
