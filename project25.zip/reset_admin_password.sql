-- Script para restablecer la contraseña del administrador
-- Este script se enfoca solo en restablecer la contraseña correctamente

-- Restablecer la contraseña para kemoamego@icloud.com
UPDATE auth.users
SET 
  encrypted_password = crypt('Kk1704048', gen_salt('bf')),
  raw_user_meta_data = jsonb_build_object(
    'name', 'kareem amged',
    'avatar', 'https://ui-avatars.com/api/?name=kareem+amged&background=random',
    'country_code', 'EG',
    'language', 'ar'
  ),
  updated_at = NOW(),
  last_sign_in_at = NULL,
  confirmation_token = NULL,
  recovery_token = NULL,
  email_change_token_new = NULL
WHERE email = 'kemoamego@icloud.com';

-- Limpiar tokens de sesión existentes
DELETE FROM auth.refresh_tokens 
WHERE user_id = (SELECT id FROM auth.users WHERE email = 'kemoamego@icloud.com');

-- Verificar que el usuario esté en la tabla admin_users
DO $$
DECLARE
  user_id UUID;
BEGIN
  -- Obtener el ID del usuario
  SELECT id INTO user_id
  FROM auth.users
  WHERE email = 'kemoamego@icloud.com';
  
  -- Si el usuario existe en auth.users pero no en admin_users, agregarlo
  IF user_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM admin_users WHERE id = user_id) THEN
    INSERT INTO admin_users (
      id,
      name,
      email,
      role,
      avatar,
      created_at,
      updated_at
    ) VALUES (
      user_id,
      'kareem amged',
      'kemoamego@icloud.com',
      'super_admin',
      'https://ui-avatars.com/api/?name=kareem+amged&background=random',
      NOW(),
      NOW()
    );
  END IF;
END $$;
