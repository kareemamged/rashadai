import React from 'react';
import { useAuthStore } from '../../store/authStore';
import { Navigate, useLocation } from 'react-router-dom';
import AdminLayout from '../../components/admin/AdminLayout';
import ContentManagement from '../../components/admin/ContentManagement';

const ContentManagementPage = () => {
  const user = useAuthStore((state) => state.user);
  const location = useLocation();

  if (!user) {
    return <Navigate to="/admin/login" state={{ from: location }} replace />;
  }

  return (
    <AdminLayout>
      <ContentManagement />
    </AdminLayout>
  );
};

export default ContentManagementPage;
