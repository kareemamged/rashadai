-- Script para verificar el estado del usuario administrador

-- Verificar si el usuario existe en auth.users
SELECT 
  id, 
  email, 
  role, 
  email_confirmed_at IS NOT NULL AS is_confirmed,
  last_sign_in_at,
  created_at,
  updated_at
FROM auth.users
WHERE email = 'kemoamego@icloud.com';

-- Verificar si el usuario existe en admin_users
SELECT 
  id, 
  email, 
  role, 
  created_at, 
  updated_at, 
  last_login
FROM admin_users
WHERE email = 'kemoamego@icloud.com';

-- Verificar si el usuario existe en profiles
SELECT 
  id, 
  email, 
  name, 
  avatar, 
  country_code, 
  language, 
  created_at, 
  updated_at
FROM profiles
WHERE email = 'kemoamego@icloud.com';
