-- Script simple para restablecer la contraseña
-- Este script solo actualiza la contraseña en auth.users

-- Restablecer la contraseña para kemoamego@icloud.com
UPDATE auth.users
SET encrypted_password = crypt('Kk1704048', gen_salt('bf'))
WHERE email = 'kemoamego@icloud.com';

-- Limpiar tokens de sesión existentes
DELETE FROM auth.refresh_tokens 
WHERE user_id = (SELECT id FROM auth.users WHERE email = 'kemoamego@icloud.com');
