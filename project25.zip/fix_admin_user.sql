-- Script para corregir el usuario administrador y su contraseña
-- Este script:
-- 1. Verifica si el usuario existe en auth.users
-- 2. Actualiza la contraseña si existe o crea el usuario si no existe
-- 3. Asegura que el usuario esté en la tabla admin_users con el rol correcto

-- Habilitar extensiones necesarias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

DO $$
DECLARE
  user_id UUID;
  user_exists BOOLEAN;
BEGIN
  -- Verificar si el usuario existe en auth.users
  SELECT id, TRUE INTO user_id, user_exists
  FROM auth.users
  WHERE email = 'kemoamego@icloud.com';
  
  IF user_exists THEN
    -- El usuario existe, actualizar la contraseña
    RAISE NOTICE 'Usuario encontrado con ID: %', user_id;
    
    -- Actualizar la contraseña y los metadatos
    UPDATE auth.users
    SET 
      encrypted_password = crypt('Kk1704048', gen_salt('bf')),
      raw_user_meta_data = jsonb_build_object(
        'name', 'kareem amged',
        'avatar', 'https://ui-avatars.com/api/?name=kareem+amged&background=random',
        'country_code', 'EG',
        'language', 'ar'
      ),
      updated_at = NOW(),
      last_sign_in_at = NULL, -- Resetear el último inicio de sesión
      confirmation_token = NULL, -- Limpiar tokens
      recovery_token = NULL,
      email_change_token_new = NULL
    WHERE id = user_id;
    
    RAISE NOTICE 'Contraseña actualizada para el usuario: %', user_id;
  ELSE
    -- El usuario no existe, crearlo
    RAISE NOTICE 'Usuario no encontrado, creando nuevo usuario';
    
    -- Generar un nuevo UUID
    user_id := uuid_generate_v4();
    
    -- Insertar el nuevo usuario en auth.users
    INSERT INTO auth.users (
      id,
      email,
      encrypted_password,
      email_confirmed_at,
      raw_user_meta_data,
      created_at,
      updated_at,
      role
    ) VALUES (
      user_id,
      'kemoamego@icloud.com',
      crypt('Kk1704048', gen_salt('bf')),
      NOW(), -- Email ya confirmado
      jsonb_build_object(
        'name', 'kareem amged',
        'avatar', 'https://ui-avatars.com/api/?name=kareem+amged&background=random',
        'country_code', 'EG',
        'language', 'ar'
      ),
      NOW(),
      NOW(),
      'authenticated'
    );
    
    RAISE NOTICE 'Nuevo usuario creado con ID: %', user_id;
  END IF;
  
  -- Verificar si el usuario existe en admin_users
  IF EXISTS (SELECT 1 FROM admin_users WHERE id = user_id) THEN
    -- Actualizar el registro existente
    UPDATE admin_users
    SET 
      name = 'kareem amged',
      email = 'kemoamego@icloud.com',
      role = 'super_admin',
      updated_at = NOW()
    WHERE id = user_id;
    
    RAISE NOTICE 'Registro de admin_users actualizado para el usuario: %', user_id;
  ELSE
    -- Crear un nuevo registro en admin_users
    INSERT INTO admin_users (
      id,
      name,
      email,
      role,
      avatar,
      created_at,
      updated_at
    ) VALUES (
      user_id,
      'kareem amged',
      'kemoamego@icloud.com',
      'super_admin',
      'https://ui-avatars.com/api/?name=kareem+amged&background=random',
      NOW(),
      NOW()
    );
    
    RAISE NOTICE 'Nuevo registro de admin_users creado para el usuario: %', user_id;
  END IF;
  
  -- Verificar si el usuario existe en profiles
  IF EXISTS (SELECT 1 FROM profiles WHERE id = user_id) THEN
    -- Actualizar el perfil existente
    UPDATE profiles
    SET 
      name = 'kareem amged',
      email = 'kemoamego@icloud.com',
      avatar = 'https://ui-avatars.com/api/?name=kareem+amged&background=random',
      country_code = 'EG',
      language = 'ar',
      updated_at = NOW()
    WHERE id = user_id;
    
    RAISE NOTICE 'Perfil actualizado para el usuario: %', user_id;
  ELSE
    -- Intentar crear un nuevo perfil
    BEGIN
      INSERT INTO profiles (
        id,
        name,
        email,
        avatar,
        country_code,
        language,
        created_at,
        updated_at
      ) VALUES (
        user_id,
        'kareem amged',
        'kemoamego@icloud.com',
        'https://ui-avatars.com/api/?name=kareem+amged&background=random',
        'EG',
        'ar',
        NOW(),
        NOW()
      );
      
      RAISE NOTICE 'Nuevo perfil creado para el usuario: %', user_id;
    EXCEPTION WHEN OTHERS THEN
      RAISE NOTICE 'No se pudo crear el perfil, pero esto no es crítico para el acceso de administrador';
    END;
  END IF;
  
  -- Limpiar cualquier token de sesión existente
  DELETE FROM auth.refresh_tokens WHERE user_id = user_id;
  
  RAISE NOTICE 'Proceso completado. El usuario ahora debería poder iniciar sesión como administrador.';
END $$;
