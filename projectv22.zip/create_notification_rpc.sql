-- إنشاء دالة RPC لإنشاء إشعار

-- إنشاء الدالة
CREATE OR REPLACE FUNCTION public.create_notification(
    user_id UUID,
    title TEXT,
    content TEXT,
    type TEXT
) RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    result JSONB;
    current_user_id UUID;
    is_admin BOOLEAN;
BEGIN
    -- التحقق من أن المستخدم الحالي هو مشرف
    current_user_id := auth.uid();
    
    SELECT (raw_user_meta_data->>'is_admin')::BOOLEAN INTO is_admin
    FROM auth.users
    WHERE id = current_user_id;
    
    IF is_admin IS NOT TRUE THEN
        RAISE EXCEPTION 'Only admins can create notifications';
    END IF;
    
    -- إنشاء إشعار جديد
    INSERT INTO public.notifications (
        user_id,
        title,
        content,
        type,
        is_read,
        created_at,
        updated_at
    ) VALUES (
        user_id,
        title,
        content,
        type,
        false,
        NOW(),
        NOW()
    )
    RETURNING to_jsonb(notifications.*) INTO result;
    
    RETURN result;
END;
$$;

-- منح صلاحيات تنفيذ الدالة للمستخدمين المصادق عليهم
GRANT EXECUTE ON FUNCTION public.create_notification TO authenticated;

-- منح صلاحيات تنفيذ الدالة للخدمة نفسها
GRANT EXECUTE ON FUNCTION public.create_notification TO service_role;
