-- إصلاح سياسات الأمان لجدول profiles

-- تفعيل RLS على جدول profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- حذف السياسات الموجودة
DROP POLICY IF EXISTS "Users can view their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can insert their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can delete their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Admins can do anything" ON public.profiles;

-- إنشاء سياسة للقراءة: يمكن للمستخدم قراءة ملفه الشخصي فقط
CREATE POLICY "Users can view their own profile"
  ON public.profiles FOR SELECT
  USING (auth.uid() = id);

-- إنشاء سياسة للإدخال: يمكن للمستخدم إنشاء ملفه الشخصي فقط
CREATE POLICY "Users can insert their own profile"
  ON public.profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

-- إنشاء سياسة للتحديث: يمكن للمستخدم تحديث ملفه الشخصي فقط
CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

-- إنشاء سياسة للحذف: يمكن للمستخدم حذف ملفه الشخصي فقط
CREATE POLICY "Users can delete their own profile"
  ON public.profiles FOR DELETE
  USING (auth.uid() = id);

-- إنشاء سياسة للمشرفين: يمكن للمشرفين الوصول إلى جميع الملفات الشخصية
CREATE POLICY "Admins can do anything"
  ON public.profiles
  USING (
    auth.uid() IN (
      SELECT id FROM auth.users WHERE raw_user_meta_data->>'is_admin' = 'true'
    )
  );

-- إنشاء سياسة للتسجيل: يمكن للنظام إنشاء ملفات شخصية للمستخدمين الجدد
CREATE POLICY "System can create profiles for new users"
  ON public.profiles FOR INSERT
  WITH CHECK (true);

-- منح صلاحيات للمستخدمين المصادق عليهم
GRANT SELECT, UPDATE ON public.profiles TO authenticated;

-- منح صلاحيات للمستخدمين غير المصادق عليهم (للتسجيل)
GRANT INSERT ON public.profiles TO anon;

-- منح صلاحيات للخدمة نفسها
GRANT ALL ON public.profiles TO service_role;

-- إنشاء دالة لإنشاء سجل في جدول profiles عند إنشاء مستخدم جديد
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, name, avatar, language, country_code, created_at, updated_at)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'avatar', 'https://ui-avatars.com/api/?name=' || split_part(NEW.email, '@', 1) || '&background=random'),
    COALESCE(NEW.raw_user_meta_data->>'language', 'ar'),
    COALESCE(NEW.raw_user_meta_data->>'country_code', 'US'),
    NEW.created_at,
    NEW.created_at
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- إنشاء trigger لتشغيل الدالة عند إنشاء مستخدم جديد
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
