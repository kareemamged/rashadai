-- إنشاء سياسة أمان تسمح بالوصول الكامل للجميع (للاختبار فقط)

-- حذف جميع السياسات الموجودة
DO $$
DECLARE
    policy_name text;
BEGIN
    FOR policy_name IN (
        SELECT policyname FROM pg_policies WHERE tablename = 'profiles'
    ) LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON public.profiles', policy_name);
    END LOOP;
END $$;

-- إنشاء سياسة تسمح بالوصول الكامل للجميع
CREATE POLICY "Allow all access to profiles" ON public.profiles
    USING (true)
    WITH CHECK (true);
