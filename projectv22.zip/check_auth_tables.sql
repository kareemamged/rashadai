-- التحقق من جداول مخطط auth
SELECT 
    table_name
FROM 
    information_schema.tables
WHERE 
    table_schema = 'auth'
ORDER BY 
    table_name;

-- التحقق من إعدادات التسجيل في Supabase
SELECT 
    *
FROM 
    auth.config
LIMIT 1;

-- طريقة بديلة للتحقق من إعدادات التسجيل
SELECT 
    *
FROM 
    auth.settings
LIMIT 1;

-- التحقق من وجود جدول auth.identities
SELECT 
    *
FROM 
    auth.identities
LIMIT 1;

-- التحقق من وجود جدول auth.users
SELECT 
    *
FROM 
    auth.users
LIMIT 1;
