-- إصلاح إعدادات التسجيل في Supabase

-- تفعيل التسجيل بالبريد الإلكتروني
UPDATE auth.settings
SET enable_signup = true
WHERE id = 1;

-- تفعيل تسجيل الدخول بالبريد الإلكتروني
UPDATE auth.settings
SET enable_email_signup = true,
    enable_email_autoconfirm = true
WHERE id = 1;

-- تعطيل التحقق من البريد الإلكتروني (للاختبار فقط)
UPDATE auth.settings
SET mailer_autoconfirm = true
WHERE id = 1;

-- تعطيل التحقق من رقم الهاتف (للاختبار فقط)
UPDATE auth.settings
SET sms_autoconfirm = true
WHERE id = 1;

-- تفعيل تسجيل الدخول بدون كلمة مرور (للاختبار فقط)
UPDATE auth.settings
SET enable_passwordless = true
WHERE id = 1;

-- تعيين مدة صلاحية الجلسة إلى 30 يومًا
UPDATE auth.settings
SET jwt_exp = 2592000
WHERE id = 1;
