-- إنشاء دالة RPC لتحديث حالة تقرير مشكلة

-- إنشاء الدالة
CREATE OR REPLACE FUNCTION public.update_user_report_status(
    report_id UUID,
    status TEXT
) RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    result JSONB;
    current_user_id UUID;
    is_admin BOOLEAN;
BEGIN
    -- التحقق من أن المستخدم الحالي هو مشرف
    current_user_id := auth.uid();
    
    SELECT (raw_user_meta_data->>'is_admin')::BOOLEAN INTO is_admin
    FROM auth.users
    WHERE id = current_user_id;
    
    IF is_admin IS NOT TRUE THEN
        RAISE EXCEPTION 'Only admins can update report status';
    END IF;
    
    -- التحقق من صحة حالة التقرير
    IF status NOT IN ('pending', 'in_progress', 'resolved', 'rejected') THEN
        RAISE EXCEPTION 'Invalid status. Must be one of: pending, in_progress, resolved, rejected';
    END IF;
    
    -- تحديث حالة التقرير
    UPDATE public.user_reports
    SET
        status = update_user_report_status.status,
        updated_at = NOW()
    WHERE id = report_id
    RETURNING to_jsonb(user_reports.*) INTO result;
    
    IF result IS NULL THEN
        RAISE EXCEPTION 'Report not found';
    END IF;
    
    RETURN result;
END;
$$;

-- منح صلاحيات تنفيذ الدالة للمستخدمين المصادق عليهم
GRANT EXECUTE ON FUNCTION public.update_user_report_status TO authenticated;

-- منح صلاحيات تنفيذ الدالة للخدمة نفسها
GRANT EXECUTE ON FUNCTION public.update_user_report_status TO service_role;
