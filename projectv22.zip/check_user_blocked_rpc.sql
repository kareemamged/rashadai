-- إنشاء دالة RPC للتحقق من حالة حظر المستخدم

-- إنشاء الدالة
CREATE OR REPLACE FUNCTION public.check_user_blocked(
    user_id UUID DEFAULT NULL
) RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    is_blocked BOOLEAN;
    check_id UUID;
BEGIN
    -- إذا لم يتم تمرير معرف المستخدم، استخدم معرف المستخدم الحالي
    IF user_id IS NULL THEN
        check_id := auth.uid();
    ELSE
        check_id := user_id;
    END IF;
    
    -- التحقق من حالة حظر المستخدم
    SELECT (raw_user_meta_data->>'is_blocked')::BOOLEAN INTO is_blocked
    FROM auth.users
    WHERE id = check_id;
    
    -- إذا كانت حالة الحظر NULL، فهذا يعني أن المستخدم غير محظور
    IF is_blocked IS NULL THEN
        RETURN FALSE;
    END IF;
    
    RETURN is_blocked;
END;
$$;

-- منح صلاحيات تنفيذ الدالة للمستخدمين المصادق عليهم
GRANT EXECUTE ON FUNCTION public.check_user_blocked TO authenticated;

-- منح صلاحيات تنفيذ الدالة للمستخدمين غير المصادق عليهم
GRANT EXECUTE ON FUNCTION public.check_user_blocked TO anon;

-- منح صلاحيات تنفيذ الدالة للخدمة نفسها
GRANT EXECUTE ON FUNCTION public.check_user_blocked TO service_role;
