-- إنشاء سياسة أمان بسيطة لجدول profiles

-- إنشاء سياسة تسمح بالوصول الكامل للجميع (للاختبار فقط)
CREATE POLICY "Allow all access to profiles" ON public.profiles
    USING (true)
    WITH CHECK (true);
