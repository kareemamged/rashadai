-- إضافة عمود avatar_url إلى جدول profiles إذا لم يكن موجودًا

-- التحقق من وجود عمود avatar_url
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = 'profiles' 
        AND column_name = 'avatar_url'
    ) THEN
        -- إضافة عمود avatar_url
        ALTER TABLE public.profiles ADD COLUMN avatar_url TEXT;
        
        -- تحديث قيم عمود avatar_url من عمود avatar
        UPDATE public.profiles SET avatar_url = avatar;
    END IF;
END $$;
