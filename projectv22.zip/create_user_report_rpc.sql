-- إنشاء دالة RPC لإنشاء تقرير مشكلة

-- إنشاء الدالة
CREATE OR REPLACE FUNCTION public.create_user_report(
    report_type TEXT,
    report_content TEXT
) RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    result JSONB;
    current_user_id UUID;
BEGIN
    -- الحصول على معرف المستخدم الحالي
    current_user_id := auth.uid();
    
    -- إنشاء تقرير جديد
    INSERT INTO public.user_reports (
        user_id,
        report_type,
        report_content,
        status,
        created_at,
        updated_at
    ) VALUES (
        current_user_id,
        report_type,
        report_content,
        'pending',
        NOW(),
        NOW()
    )
    RETURNING to_jsonb(user_reports.*) INTO result;
    
    RETURN result;
END;
$$;

-- منح صلاحيات تنفيذ الدالة للمستخدمين المصادق عليهم
GRANT EXECUTE ON FUNCTION public.create_user_report TO authenticated;

-- منح صلاحيات تنفيذ الدالة للخدمة نفسها
GRANT EXECUTE ON FUNCTION public.create_user_report TO service_role;
