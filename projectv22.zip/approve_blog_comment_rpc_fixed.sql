-- إنشاء دالة RPC للموافقة على تعليق في المدونة

-- حذف الدالة الموجودة أولاً
DROP FUNCTION IF EXISTS public.approve_blog_comment;

-- إنشاء الدالة
CREATE OR REPLACE FUNCTION public.approve_blog_comment(
    comment_id UUID,
    approved BOOLEAN
) RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    result JSONB;
    current_user_id UUID;
    is_admin BOOLEAN;
BEGIN
    -- التحقق من أن المستخدم الحالي هو مشرف
    current_user_id := auth.uid();
    
    SELECT (raw_user_meta_data->>'is_admin')::BOOLEAN INTO is_admin
    FROM auth.users
    WHERE id = current_user_id;
    
    IF is_admin IS NOT TRUE THEN
        RAISE EXCEPTION 'Only admins can approve comments';
    END IF;
    
    -- تحديث حالة الموافقة على التعليق
    UPDATE public.blog_comments
    SET
        approved = approve_blog_comment.approved,
        updated_at = NOW()
    WHERE id = comment_id
    RETURNING to_jsonb(blog_comments.*) INTO result;
    
    IF result IS NULL THEN
        RAISE EXCEPTION 'Comment not found';
    END IF;
    
    RETURN result;
END;
$$;

-- منح صلاحيات تنفيذ الدالة للمستخدمين المصادق عليهم
GRANT EXECUTE ON FUNCTION public.approve_blog_comment TO authenticated;
