-- إصلاح سياسات الأمان لجدول profiles بطريقة أبسط

-- تفعيل RLS على جدول profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- حذف جميع السياسات الموجودة
DO $$
DECLARE
    policy_name text;
BEGIN
    FOR policy_name IN (
        SELECT policyname FROM pg_policies WHERE tablename = 'profiles'
    ) LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON public.profiles', policy_name);
    END LOOP;
END $$;

-- إنشاء سياسة بسيطة تسمح بالوصول الكامل للجميع (للاختبار فقط)
CREATE POLICY "Allow all access to profiles" ON public.profiles
    USING (true)
    WITH CHECK (true);

-- منح صلاحيات للمستخدمين المصادق عليهم
GRANT ALL ON public.profiles TO authenticated;

-- منح صلاحيات للمستخدمين غير المصادق عليهم (للتسجيل)
GRANT ALL ON public.profiles TO anon;

-- منح صلاحيات للخدمة نفسها
GRANT ALL ON public.profiles TO service_role;
