-- تفعيل التسجيل في Supabase بدون استخدام كتلة معاملات

-- تفعيل التسجيل بشكل عام
ALTER SYSTEM SET supabase.auth.enable_signup = 'true';

-- تفعيل التسجيل بالبريد الإلكتروني
ALTER SYSTEM SET supabase.auth.enable_email_signup = 'true';

-- تفعيل التأكيد التلقائي للبريد الإلكتروني
ALTER SYSTEM SET supabase.auth.enable_email_autoconfirm = 'true';

-- إعادة تحميل الإعدادات
SELECT pg_reload_conf();
