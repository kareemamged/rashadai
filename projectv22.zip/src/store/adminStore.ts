import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { supabase } from '../lib/supabase';

// Define types for admin users
export interface AdminUser {
  id: string;
  email: string;
  name?: string;
  role: 'super_admin' | 'content_admin' | 'moderator';
  created_at: string;
  last_login?: string;
  avatar?: string;
}

// Define types for admin roles and permissions
export interface Permission {
  resource: string;
  actions: {
    view: boolean;
    create: boolean;
    edit: boolean;
    delete: boolean;
    approve: boolean;
  };
}

export interface Role {
  id: string;
  name: string;
  description: string;
  permissions: Permission[];
  created_at: string;
  updated_at: string;
}

// Define types for system settings
export interface SystemSettings {
  siteName: string;
  siteDescription: string;
  contactEmail: string;
  supportPhone: string;
  timezone: string;
  dateFormat: string;
  timeFormat: string;
  security: {
    enableTwoFactor: boolean;
    sessionTimeout: number;
    passwordPolicy: {
      minLength: number;
      requireSpecialChars: boolean;
      requireNumbers: boolean;
      requireUppercase: boolean;
    };
    maxLoginAttempts: number;
  };
  maintenance: {
    enabled: boolean;
    message: string;
  };
}

// Define types for design settings
export interface DesignSettings {
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
    text: string;
  };
  fonts: {
    heading: string;
    body: string;
    size: 'small' | 'medium' | 'large';
  };
  logo: string;
  favicon: string;
}

// Define types for admin stats
export interface AdminStats {
  totalUsers: number;
  activeConsultations: number;
  pendingReviews: number;
  systemStatus: {
    server: 'healthy' | 'warning' | 'critical';
    database: 'healthy' | 'warning' | 'critical';
    storage: 'healthy' | 'warning' | 'critical';
  };
}

// Define the admin store state
interface AdminState {
  // Authentication
  adminUser: AdminUser | null;
  isLoading: boolean;
  error: string | null;
  
  // Users management
  adminUsers: AdminUser[];
  roles: Role[];
  
  // Settings
  systemSettings: SystemSettings;
  designSettings: DesignSettings;
  
  // Stats
  stats: AdminStats;
  
  // Actions
  signInAdmin: (email: string, password: string) => Promise<void>;
  signOutAdmin: () => Promise<void>;
  fetchAdminUsers: () => Promise<void>;
  fetchRoles: () => Promise<void>;
  fetchSystemSettings: () => Promise<void>;
  fetchDesignSettings: () => Promise<void>;
  fetchStats: () => Promise<void>;
  updateSystemSettings: (settings: Partial<SystemSettings>) => Promise<void>;
  updateDesignSettings: (settings: Partial<DesignSettings>) => Promise<void>;
  createRole: (role: Omit<Role, 'id' | 'created_at' | 'updated_at'>) => Promise<void>;
  updateRole: (id: string, role: Partial<Role>) => Promise<void>;
  deleteRole: (id: string) => Promise<void>;
  createAdminUser: (user: Omit<AdminUser, 'id' | 'created_at'>) => Promise<void>;
  updateAdminUser: (id: string, user: Partial<AdminUser>) => Promise<void>;
  deleteAdminUser: (id: string) => Promise<void>;
}

// Create the admin store
export const useAdminStore = create<AdminState>()(
  persist(
    (set, get) => ({
      // Initial state
      adminUser: null,
      isLoading: false,
      error: null,
      adminUsers: [],
      roles: [],
      systemSettings: {
        siteName: 'RashadAI',
        siteDescription: 'AI-Powered Medical Consultation',
        contactEmail: 'support@rashadai.com',
        supportPhone: '+1 (555) 123-4567',
        timezone: 'UTC',
        dateFormat: 'MM/DD/YYYY',
        timeFormat: '12h',
        security: {
          enableTwoFactor: false,
          sessionTimeout: 30,
          passwordPolicy: {
            minLength: 8,
            requireSpecialChars: true,
            requireNumbers: true,
            requireUppercase: true,
          },
          maxLoginAttempts: 5,
        },
        maintenance: {
          enabled: false,
          message: 'We are currently performing maintenance. Please check back later.',
        },
      },
      designSettings: {
        colors: {
          primary: '#3b82f6',
          secondary: '#1e40af',
          accent: '#10b981',
          background: '#f9fafb',
          text: '#1f2937',
        },
        fonts: {
          heading: 'Inter, sans-serif',
          body: 'Inter, sans-serif',
          size: 'medium',
        },
        logo: '',
        favicon: '',
      },
      stats: {
        totalUsers: 0,
        activeConsultations: 0,
        pendingReviews: 0,
        systemStatus: {
          server: 'healthy',
          database: 'healthy',
          storage: 'healthy',
        },
      },
      
      // Actions
      signInAdmin: async (email: string, password: string) => {
        set({ isLoading: true, error: null });
        try {
          const { data, error } = await supabase.auth.signInWithPassword({
            email,
            password,
          });
          
          if (error) throw error;
          
          if (data.user) {
            // Check if user has admin role
            const { data: adminData, error: adminError } = await supabase
              .from('admin_users')
              .select('*')
              .eq('id', data.user.id)
              .single();
            
            if (adminError) {
              // If no admin record found, this is not an admin user
              await supabase.auth.signOut();
              throw new Error('Not authorized as admin');
            }
            
            const adminUser: AdminUser = {
              id: data.user.id,
              email: data.user.email || email,
              name: adminData?.name || data.user.user_metadata?.name,
              role: adminData?.role || 'moderator',
              created_at: data.user.created_at,
              last_login: new Date().toISOString(),
              avatar: adminData?.avatar || data.user.user_metadata?.avatar,
            };
            
            set({ adminUser });
          }
        } catch (error: any) {
          set({ error: error.message });
        } finally {
          set({ isLoading: false });
        }
      },
      
      signOutAdmin: async () => {
        set({ isLoading: true });
        try {
          await supabase.auth.signOut();
          set({ adminUser: null });
        } catch (error: any) {
          set({ error: error.message });
        } finally {
          set({ isLoading: false });
        }
      },
      
      fetchAdminUsers: async () => {
        set({ isLoading: true });
        try {
          const { data, error } = await supabase
            .from('admin_users')
            .select('*');
          
          if (error) throw error;
          
          set({ adminUsers: data || [] });
        } catch (error: any) {
          set({ error: error.message });
        } finally {
          set({ isLoading: false });
        }
      },
      
      fetchRoles: async () => {
        set({ isLoading: true });
        try {
          const { data, error } = await supabase
            .from('admin_roles')
            .select('*');
          
          if (error) throw error;
          
          set({ roles: data || [] });
        } catch (error: any) {
          set({ error: error.message });
        } finally {
          set({ isLoading: false });
        }
      },
      
      fetchSystemSettings: async () => {
        // Implementation will be added when the table is created
        set({ isLoading: false });
      },
      
      fetchDesignSettings: async () => {
        // Implementation will be added when the table is created
        set({ isLoading: false });
      },
      
      fetchStats: async () => {
        set({ isLoading: true });
        try {
          // Fetch total users count
          const { count: usersCount, error: usersError } = await supabase
            .from('profiles')
            .select('*', { count: 'exact', head: true });
          
          if (usersError) throw usersError;
          
          // Update stats
          set({
            stats: {
              ...get().stats,
              totalUsers: usersCount || 0,
              // Other stats will be implemented when the tables are created
            }
          });
        } catch (error: any) {
          set({ error: error.message });
        } finally {
          set({ isLoading: false });
        }
      },
      
      updateSystemSettings: async (settings) => {
        // Implementation will be added when the table is created
        set({ 
          systemSettings: {
            ...get().systemSettings,
            ...settings
          }
        });
      },
      
      updateDesignSettings: async (settings) => {
        // Implementation will be added when the table is created
        set({ 
          designSettings: {
            ...get().designSettings,
            ...settings
          }
        });
      },
      
      createRole: async () => {
        // Implementation will be added when the table is created
        set({ isLoading: false });
      },
      
      updateRole: async () => {
        // Implementation will be added when the table is created
        set({ isLoading: false });
      },
      
      deleteRole: async () => {
        // Implementation will be added when the table is created
        set({ isLoading: false });
      },
      
      createAdminUser: async () => {
        // Implementation will be added when the table is created
        set({ isLoading: false });
      },
      
      updateAdminUser: async () => {
        // Implementation will be added when the table is created
        set({ isLoading: false });
      },
      
      deleteAdminUser: async () => {
        // Implementation will be added when the table is created
        set({ isLoading: false });
      },
    }),
    {
      name: 'admin-storage',
    }
  )
);
