import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useLanguageStore } from '../../store/languageStore';
import { 
  Users, 
  UserPlus, 
  Search, 
  Filter, 
  Edit, 
  Trash2, 
  Eye, 
  Lock, 
  Bell,
  UserCheck,
  UserX,
  Clock,
  Calendar,
  Mail
} from 'lucide-react';
import { supabase } from '../../lib/supabase';

// Define types for users
interface User {
  id: string;
  email: string;
  name?: string;
  avatar?: string;
  role?: string;
  status: 'active' | 'blocked' | 'inactive';
  created_at: string;
  last_login?: string;
  country_code?: string;
  phone?: string;
  bio?: string;
  language?: string;
}

const UserManagement: React.FC = () => {
  const { t } = useTranslation();
  const { language } = useLanguageStore();
  const [activeTab, setActiveTab] = useState<'patients' | 'doctors' | 'admins'>('patients');
  const [isRTL, setIsRTL] = useState(language === 'ar');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  
  // Users state
  const [users, setUsers] = useState<User[]>([]);
  const [isLoadingUsers, setIsLoadingUsers] = useState(false);
  
  useEffect(() => {
    setIsRTL(language === 'ar');
  }, [language]);
  
  // Fetch users
  useEffect(() => {
    const fetchUsers = async () => {
      setIsLoadingUsers(true);
      try {
        // Check if the profiles table exists
        const { error: checkError } = await supabase
          .from('profiles')
          .select('id')
          .limit(1);
        
        if (checkError && checkError.message.includes('does not exist')) {
          console.warn('profiles table does not exist');
          setIsLoadingUsers(false);
          return;
        }
        
        // Determine the role filter based on active tab
        let roleFilter = '';
        if (activeTab === 'doctors') {
          roleFilter = 'doctor';
        } else if (activeTab === 'admins') {
          roleFilter = 'admin';
        } else {
          roleFilter = 'patient';
        }
        
        // Fetch users with the specified role
        let query = supabase
          .from('profiles')
          .select('*');
        
        if (roleFilter) {
          query = query.eq('role', roleFilter);
        }
        
        const { data, error } = await query.order('created_at', { ascending: false });
        
        if (error) throw error;
        
        // Transform data to match our User interface
        const formattedUsers = data.map((user: any) => ({
          ...user,
          status: user.status || 'active',
        }));
        
        setUsers(formattedUsers || []);
      } catch (error) {
        console.error('Error fetching users:', error);
      } finally {
        setIsLoadingUsers(false);
      }
    };
    
    fetchUsers();
  }, [activeTab]);
  
  // Filter users based on search term and status filter
  const filteredUsers = users.filter(user => {
    const matchesSearch = 
      (user.name?.toLowerCase().includes(searchTerm.toLowerCase()) || false) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (statusFilter === 'all') return matchesSearch;
    return matchesSearch && user.status === statusFilter;
  });
  
  // Handle user actions
  const handleBlockUser = async (userId: string) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ status: 'blocked' })
        .eq('id', userId);
      
      if (error) throw error;
      
      // Update local state
      setUsers(users.map(user => 
        user.id === userId ? { ...user, status: 'blocked' } : user
      ));
    } catch (error) {
      console.error('Error blocking user:', error);
    }
  };
  
  const handleUnblockUser = async (userId: string) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ status: 'active' })
        .eq('id', userId);
      
      if (error) throw error;
      
      // Update local state
      setUsers(users.map(user => 
        user.id === userId ? { ...user, status: 'active' } : user
      ));
    } catch (error) {
      console.error('Error unblocking user:', error);
    }
  };
  
  const handleDeleteUser = async (userId: string) => {
    // This is a placeholder - in a real app, you would want to show a confirmation dialog
    // and handle the deletion more carefully, possibly archiving the user instead of deleting
    try {
      const { error } = await supabase
        .from('profiles')
        .delete()
        .eq('id', userId);
      
      if (error) throw error;
      
      // Update local state
      setUsers(users.filter(user => user.id !== userId));
    } catch (error) {
      console.error('Error deleting user:', error);
    }
  };
  
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">{t('admin.users.title')}</h1>
      
      {/* Tabs */}
      <div className="flex border-b mb-6">
        <button
          className={`${
            activeTab === 'patients'
              ? 'border-b-2 border-blue-500 text-blue-600'
              : 'text-gray-500 hover:text-gray-700'
          } flex items-center px-4 py-2 font-medium`}
          onClick={() => setActiveTab('patients')}
        >
          <Users className={`h-5 w-5 ${isRTL ? 'ml-2' : 'mr-2'}`} />
          {t('admin.users.patients')}
        </button>
        <button
          className={`${
            activeTab === 'doctors'
              ? 'border-b-2 border-blue-500 text-blue-600'
              : 'text-gray-500 hover:text-gray-700'
          } flex items-center px-4 py-2 font-medium`}
          onClick={() => setActiveTab('doctors')}
        >
          <UserCheck className={`h-5 w-5 ${isRTL ? 'ml-2' : 'mr-2'}`} />
          {t('admin.users.doctors')}
        </button>
        <button
          className={`${
            activeTab === 'admins'
              ? 'border-b-2 border-blue-500 text-blue-600'
              : 'text-gray-500 hover:text-gray-700'
          } flex items-center px-4 py-2 font-medium`}
          onClick={() => setActiveTab('admins')}
        >
          <UserPlus className={`h-5 w-5 ${isRTL ? 'ml-2' : 'mr-2'}`} />
          {t('admin.users.admins')}
        </button>
      </div>
      
      {/* Search and Filter */}
      <div className="flex flex-col md:flex-row justify-between mb-6">
        <div className="relative mb-4 md:mb-0 md:w-1/3">
          <input
            type="text"
            placeholder={t('common.search')}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
        </div>
        
        <div className="flex">
          <div className="relative mr-4">
            <select
              className="appearance-none pl-10 pr-8 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="all">{t('common.all')}</option>
              <option value="active">{t('admin.users.active')}</option>
              <option value="blocked">{t('admin.users.blocked')}</option>
              <option value="inactive">{t('admin.users.inactive')}</option>
            </select>
            <Filter className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
          
          <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <UserPlus className={`h-5 w-5 ${isRTL ? 'ml-2' : 'mr-2'}`} />
            {t('admin.users.addUser')}
          </button>
        </div>
      </div>
      
      {/* Users Table */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        {isLoadingUsers ? (
          <div className="p-6 text-center">
            <p>{t('common.loading')}</p>
          </div>
        ) : filteredUsers.length === 0 ? (
          <div className="p-6 text-center">
            <p>{t('common.noResults')}</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {t('admin.users.userName')}
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {t('admin.users.userEmail')}
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {t('admin.users.userStatus')}
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {t('admin.users.joinDate')}
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {t('admin.users.actions')}
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredUsers.map((user) => (
                  <tr key={user.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10">
                          {user.avatar ? (
                            <img
                              className="h-10 w-10 rounded-full object-cover"
                              src={user.avatar}
                              alt={user.name || user.email}
                            />
                          ) : (
                            <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                              <span className="text-blue-600 font-medium">
                                {(user.name || user.email || '').charAt(0).toUpperCase()}
                              </span>
                            </div>
                          )}
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">
                            {user.name || t('common.noName')}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">{user.email}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        user.status === 'active' ? 'bg-green-100 text-green-800' :
                        user.status === 'blocked' ? 'bg-red-100 text-red-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {t(`admin.users.${user.status}`)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1 text-gray-400" />
                        {new Date(user.created_at).toLocaleDateString(
                          language === 'ar' ? 'ar-SA' : 'en-US'
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button className="text-blue-600 hover:text-blue-900 mr-3" title={t('admin.users.viewProfile')}>
                        <Eye className="h-5 w-5" />
                      </button>
                      <button className="text-indigo-600 hover:text-indigo-900 mr-3" title={t('admin.users.editUser')}>
                        <Edit className="h-5 w-5" />
                      </button>
                      <button className="text-yellow-600 hover:text-yellow-900 mr-3" title={t('admin.users.resetPassword')}>
                        <Lock className="h-5 w-5" />
                      </button>
                      <button className="text-purple-600 hover:text-purple-900 mr-3" title={t('admin.users.sendNotification')}>
                        <Bell className="h-5 w-5" />
                      </button>
                      {user.status === 'active' ? (
                        <button 
                          className="text-orange-600 hover:text-orange-900 mr-3" 
                          title={t('admin.users.blockUser')}
                          onClick={() => handleBlockUser(user.id)}
                        >
                          <UserX className="h-5 w-5" />
                        </button>
                      ) : user.status === 'blocked' ? (
                        <button 
                          className="text-green-600 hover:text-green-900 mr-3" 
                          title={t('admin.users.unblockUser')}
                          onClick={() => handleUnblockUser(user.id)}
                        >
                          <UserCheck className="h-5 w-5" />
                        </button>
                      ) : null}
                      <button 
                        className="text-red-600 hover:text-red-900" 
                        title={t('admin.users.deleteUser')}
                        onClick={() => handleDeleteUser(user.id)}
                      >
                        <Trash2 className="h-5 w-5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default UserManagement;
