import React, { useEffect, useState } from 'react';
import { useAuthStore } from '../../store/authStore';
import { useAdminStore } from '../../store/adminStore';
import { useTranslation } from 'react-i18next';
import { useLanguageStore } from '../../store/languageStore';
import { Navigate, useLocation } from 'react-router-dom';
import AdminLayout from './AdminLayout';
import {
  Users,
  MessageSquare,
  Star,
  Activity,
  Server,
  Database,
  HardDrive,
  CheckCircle,
  AlertTriangle,
  AlertOctagon,
  Calendar,
  Clock,
  BarChart2
} from 'lucide-react';

const Dashboard = () => {
  const user = useAuthStore((state) => state.user);
  const { t } = useTranslation();
  const { language } = useLanguageStore();
  const {
    stats,
    fetchStats,
    isLoading
  } = useAdminStore();
  const [isRTL, setIsRTL] = useState(language === 'ar');

  useEffect(() => {
    setIsRTL(language === 'ar');
  }, [language]);

  useEffect(() => {
    fetchStats();
    // Fetch stats every 5 minutes
    const interval = setInterval(() => {
      fetchStats();
    }, 5 * 60 * 1000);

    return () => clearInterval(interval);
  }, [fetchStats]);

  const location = useLocation();

  if (!user) {
    return <Navigate to="/admin/login" state={{ from: location }} replace />;
  }

  // Helper function to render status icon
  const renderStatusIcon = (status: 'healthy' | 'warning' | 'critical') => {
    switch (status) {
      case 'healthy':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'critical':
        return <AlertOctagon className="h-5 w-5 text-red-500" />;
      default:
        return null;
    }
  };

  // Helper function to render status text
  const renderStatusText = (status: 'healthy' | 'warning' | 'critical') => {
    switch (status) {
      case 'healthy':
        return <span className="text-green-500">{t('admin.dashboard.healthy')}</span>;
      case 'warning':
        return <span className="text-yellow-500">{t('admin.dashboard.warning')}</span>;
      case 'critical':
        return <span className="text-red-500">{t('admin.dashboard.critical')}</span>;
      default:
        return null;
    }
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">{t('admin.dashboard.title')}</h1>
        <div className="flex items-center">
          <Calendar className="h-5 w-5 text-gray-500 mr-2" />
          <span className="text-sm text-gray-500 mr-4">
            {new Date().toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US')}
          </span>
          <Clock className="h-5 w-5 text-gray-500 mr-2" />
          <span className="text-sm text-gray-500">
            {new Date().toLocaleTimeString(language === 'ar' ? 'ar-SA' : 'en-US')}
          </span>
        </div>
      </div>

      <div className="mb-8">
        <h2 className="text-lg font-semibold mb-4">{t('admin.dashboard.quickStats')}</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Total Users */}
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-gray-500">{t('admin.dashboard.totalUsers')}</h3>
              <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                <Users className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <p className="text-3xl font-bold text-gray-800">
              {isLoading ? '...' : stats.totalUsers.toLocaleString()}
            </p>
          </div>

          {/* Active Consultations */}
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-gray-500">{t('admin.dashboard.activeConsultations')}</h3>
              <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center">
                <MessageSquare className="h-6 w-6 text-green-600" />
              </div>
            </div>
            <p className="text-3xl font-bold text-gray-800">
              {isLoading ? '...' : stats.activeConsultations.toLocaleString()}
            </p>
          </div>

          {/* Pending Reviews */}
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-gray-500">{t('admin.dashboard.pendingReviews')}</h3>
              <div className="h-10 w-10 rounded-full bg-yellow-100 flex items-center justify-center">
                <Star className="h-6 w-6 text-yellow-600" />
              </div>
            </div>
            <p className="text-3xl font-bold text-gray-800">
              {isLoading ? '...' : stats.pendingReviews.toLocaleString()}
            </p>
          </div>
        </div>
      </div>

      {/* System Status */}
      <div className="mb-8">
        <h2 className="text-lg font-semibold mb-4">{t('admin.dashboard.systemStatus')}</h2>
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Server Status */}
              <div className="flex items-center">
                <div className="h-10 w-10 rounded-full bg-gray-100 flex items-center justify-center mr-4">
                  <Server className="h-6 w-6 text-gray-600" />
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">{t('admin.dashboard.serverStatus')}</h3>
                  <div className="flex items-center mt-1">
                    {renderStatusIcon(stats.systemStatus.server)}
                    <span className="ml-2">{renderStatusText(stats.systemStatus.server)}</span>
                  </div>
                </div>
              </div>

              {/* Database Status */}
              <div className="flex items-center">
                <div className="h-10 w-10 rounded-full bg-gray-100 flex items-center justify-center mr-4">
                  <Database className="h-6 w-6 text-gray-600" />
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">{t('admin.dashboard.databaseStatus')}</h3>
                  <div className="flex items-center mt-1">
                    {renderStatusIcon(stats.systemStatus.database)}
                    <span className="ml-2">{renderStatusText(stats.systemStatus.database)}</span>
                  </div>
                </div>
              </div>

              {/* Storage Status */}
              <div className="flex items-center">
                <div className="h-10 w-10 rounded-full bg-gray-100 flex items-center justify-center mr-4">
                  <HardDrive className="h-6 w-6 text-gray-600" />
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">{t('admin.dashboard.storageStatus')}</h3>
                  <div className="flex items-center mt-1">
                    {renderStatusIcon(stats.systemStatus.storage)}
                    <span className="ml-2">{renderStatusText(stats.systemStatus.storage)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold">{t('admin.dashboard.recentActivity')}</h2>
          <button className="text-sm text-blue-600 hover:text-blue-800">
            {t('admin.dashboard.viewAll')}
          </button>
        </div>
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-6">
            <div className="flex items-center justify-center h-40">
              <div className="text-center">
                <BarChart2 className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">
                  {t('common.comingSoon')}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;