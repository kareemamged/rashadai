import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useLanguageStore } from '../../store/languageStore';
import { 
  FileText, 
  MessageSquare, 
  Star, 
  Plus, 
  Search, 
  Filter, 
  Edit, 
  Trash2, 
  Eye, 
  CheckCircle, 
  XCircle
} from 'lucide-react';
import { supabase } from '../../lib/supabase';

// Define types for blog posts
interface Post {
  id: string;
  title: {
    en: string;
    ar: string;
  };
  content: {
    en: string;
    ar: string;
  };
  summary: {
    en: string;
    ar: string;
  };
  category: string;
  status: 'draft' | 'published' | 'scheduled';
  publish_date: string;
  author_id: string;
  author_name?: string;
  created_at: string;
  updated_at: string;
  featured_image?: string;
}

// Define types for comments
interface Comment {
  id: string;
  post_id: string;
  author_name: string;
  author_email: string;
  content: string;
  status: 'approved' | 'pending' | 'spam';
  created_at: string;
}

// Define types for testimonials
interface Testimonial {
  id: string;
  author_name: string;
  author_role: string;
  content: string;
  rating: number;
  status: 'approved' | 'pending';
  created_at: string;
}

const ContentManagement: React.FC = () => {
  const { t } = useTranslation();
  const { language } = useLanguageStore();
  const [activeTab, setActiveTab] = useState<'blog' | 'comments' | 'testimonials'>('blog');
  const [isRTL, setIsRTL] = useState(language === 'ar');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  
  // Blog posts state
  const [posts, setPosts] = useState<Post[]>([]);
  const [isLoadingPosts, setIsLoadingPosts] = useState(false);
  
  // Comments state
  const [comments, setComments] = useState<Comment[]>([]);
  const [isLoadingComments, setIsLoadingComments] = useState(false);
  
  // Testimonials state
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [isLoadingTestimonials, setIsLoadingTestimonials] = useState(false);
  
  useEffect(() => {
    setIsRTL(language === 'ar');
  }, [language]);
  
  // Fetch blog posts
  useEffect(() => {
    const fetchPosts = async () => {
      setIsLoadingPosts(true);
      try {
        // Check if the blog_posts table exists
        const { error: checkError } = await supabase
          .from('blog_posts')
          .select('id')
          .limit(1);
        
        if (checkError && checkError.message.includes('does not exist')) {
          console.warn('blog_posts table does not exist');
          setIsLoadingPosts(false);
          return;
        }
        
        const { data, error } = await supabase
          .from('blog_posts')
          .select('*, profiles(name)')
          .order('created_at', { ascending: false });
        
        if (error) throw error;
        
        // Transform data to match our Post interface
        const formattedPosts = data.map((post: any) => ({
          ...post,
          author_name: post.profiles?.name || 'Unknown',
        }));
        
        setPosts(formattedPosts || []);
      } catch (error) {
        console.error('Error fetching posts:', error);
      } finally {
        setIsLoadingPosts(false);
      }
    };
    
    if (activeTab === 'blog') {
      fetchPosts();
    }
  }, [activeTab]);
  
  // Fetch comments
  useEffect(() => {
    const fetchComments = async () => {
      setIsLoadingComments(true);
      try {
        // Check if the blog_comments table exists
        const { error: checkError } = await supabase
          .from('blog_comments')
          .select('id')
          .limit(1);
        
        if (checkError && checkError.message.includes('does not exist')) {
          console.warn('blog_comments table does not exist');
          setIsLoadingComments(false);
          return;
        }
        
        const { data, error } = await supabase
          .from('blog_comments')
          .select('*')
          .order('created_at', { ascending: false });
        
        if (error) throw error;
        
        setComments(data || []);
      } catch (error) {
        console.error('Error fetching comments:', error);
      } finally {
        setIsLoadingComments(false);
      }
    };
    
    if (activeTab === 'comments') {
      fetchComments();
    }
  }, [activeTab]);
  
  // Fetch testimonials
  useEffect(() => {
    const fetchTestimonials = async () => {
      setIsLoadingTestimonials(true);
      try {
        // Check if the testimonials table exists
        const { error: checkError } = await supabase
          .from('testimonials')
          .select('id')
          .limit(1);
        
        if (checkError && checkError.message.includes('does not exist')) {
          console.warn('testimonials table does not exist');
          setIsLoadingTestimonials(false);
          return;
        }
        
        const { data, error } = await supabase
          .from('testimonials')
          .select('*')
          .order('created_at', { ascending: false });
        
        if (error) throw error;
        
        setTestimonials(data || []);
      } catch (error) {
        console.error('Error fetching testimonials:', error);
      } finally {
        setIsLoadingTestimonials(false);
      }
    };
    
    if (activeTab === 'testimonials') {
      fetchTestimonials();
    }
  }, [activeTab]);
  
  // Filter posts based on search term and status filter
  const filteredPosts = posts.filter(post => {
    const matchesSearch = 
      post.title.en.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.title.ar.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.summary.en.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.summary.ar.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (statusFilter === 'all') return matchesSearch;
    return matchesSearch && post.status === statusFilter;
  });
  
  // Filter comments based on search term and status filter
  const filteredComments = comments.filter(comment => {
    const matchesSearch = 
      comment.author_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      comment.content.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (statusFilter === 'all') return matchesSearch;
    return matchesSearch && comment.status === statusFilter;
  });
  
  // Filter testimonials based on search term and status filter
  const filteredTestimonials = testimonials.filter(testimonial => {
    const matchesSearch = 
      testimonial.author_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      testimonial.content.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (statusFilter === 'all') return matchesSearch;
    return matchesSearch && testimonial.status === statusFilter;
  });
  
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">{t('admin.content.title')}</h1>
      
      {/* Tabs */}
      <div className="flex border-b mb-6">
        <button
          className={`${
            activeTab === 'blog'
              ? 'border-b-2 border-blue-500 text-blue-600'
              : 'text-gray-500 hover:text-gray-700'
          } flex items-center px-4 py-2 font-medium`}
          onClick={() => setActiveTab('blog')}
        >
          <FileText className={`h-5 w-5 ${isRTL ? 'ml-2' : 'mr-2'}`} />
          {t('admin.content.blog')}
        </button>
        <button
          className={`${
            activeTab === 'comments'
              ? 'border-b-2 border-blue-500 text-blue-600'
              : 'text-gray-500 hover:text-gray-700'
          } flex items-center px-4 py-2 font-medium`}
          onClick={() => setActiveTab('comments')}
        >
          <MessageSquare className={`h-5 w-5 ${isRTL ? 'ml-2' : 'mr-2'}`} />
          {t('admin.content.comments')}
        </button>
        <button
          className={`${
            activeTab === 'testimonials'
              ? 'border-b-2 border-blue-500 text-blue-600'
              : 'text-gray-500 hover:text-gray-700'
          } flex items-center px-4 py-2 font-medium`}
          onClick={() => setActiveTab('testimonials')}
        >
          <Star className={`h-5 w-5 ${isRTL ? 'ml-2' : 'mr-2'}`} />
          {t('admin.content.testimonials')}
        </button>
      </div>
      
      {/* Search and Filter */}
      <div className="flex flex-col md:flex-row justify-between mb-6">
        <div className="relative mb-4 md:mb-0 md:w-1/3">
          <input
            type="text"
            placeholder={t('common.search')}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
        </div>
        
        <div className="flex">
          <div className="relative mr-4">
            <select
              className="appearance-none pl-10 pr-8 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="all">{t('common.all')}</option>
              {activeTab === 'blog' && (
                <>
                  <option value="draft">{t('admin.content.draft')}</option>
                  <option value="published">{t('admin.content.published')}</option>
                  <option value="scheduled">{t('admin.content.scheduled')}</option>
                </>
              )}
              {activeTab === 'comments' && (
                <>
                  <option value="approved">{t('admin.content.approved')}</option>
                  <option value="pending">{t('admin.content.pending')}</option>
                  <option value="spam">{t('admin.content.spam')}</option>
                </>
              )}
              {activeTab === 'testimonials' && (
                <>
                  <option value="approved">{t('admin.content.approved')}</option>
                  <option value="pending">{t('admin.content.pending')}</option>
                </>
              )}
            </select>
            <Filter className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
          
          {activeTab === 'blog' && (
            <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
              <Plus className={`h-5 w-5 ${isRTL ? 'ml-2' : 'mr-2'}`} />
              {t('admin.content.addPost')}
            </button>
          )}
        </div>
      </div>
      
      {/* Content based on active tab */}
      {activeTab === 'blog' && (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          {isLoadingPosts ? (
            <div className="p-6 text-center">
              <p>{t('common.loading')}</p>
            </div>
          ) : filteredPosts.length === 0 ? (
            <div className="p-6 text-center">
              <p>{t('common.noResults')}</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('admin.content.postTitle')}
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('admin.content.author')}
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('admin.content.postStatus')}
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('admin.content.publishDate')}
                    </th>
                    <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('common.actions')}
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredPosts.map((post) => (
                    <tr key={post.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">
                          {language === 'ar' ? post.title.ar : post.title.en}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-500">{post.author_name}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          post.status === 'published' ? 'bg-green-100 text-green-800' :
                          post.status === 'draft' ? 'bg-gray-100 text-gray-800' :
                          'bg-yellow-100 text-yellow-800'
                        }`}>
                          {t(`admin.content.${post.status}`)}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(post.publish_date || post.created_at).toLocaleDateString(
                          language === 'ar' ? 'ar-SA' : 'en-US'
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button className="text-blue-600 hover:text-blue-900 mr-3">
                          <Eye className="h-5 w-5" />
                        </button>
                        <button className="text-indigo-600 hover:text-indigo-900 mr-3">
                          <Edit className="h-5 w-5" />
                        </button>
                        <button className="text-red-600 hover:text-red-900">
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
      
      {/* Comments Tab Content */}
      {activeTab === 'comments' && (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          {isLoadingComments ? (
            <div className="p-6 text-center">
              <p>{t('common.loading')}</p>
            </div>
          ) : filteredComments.length === 0 ? (
            <div className="p-6 text-center">
              <p>{t('common.noResults')}</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('admin.content.commentAuthor')}
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('admin.content.commentContent')}
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('admin.content.commentStatus')}
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('admin.content.commentDate')}
                    </th>
                    <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('common.actions')}
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredComments.map((comment) => (
                    <tr key={comment.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">{comment.author_name}</div>
                        <div className="text-sm text-gray-500">{comment.author_email}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900 line-clamp-2">{comment.content}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          comment.status === 'approved' ? 'bg-green-100 text-green-800' :
                          comment.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-red-100 text-red-800'
                        }`}>
                          {t(`admin.content.${comment.status}`)}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(comment.created_at).toLocaleDateString(
                          language === 'ar' ? 'ar-SA' : 'en-US'
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        {comment.status === 'pending' && (
                          <button className="text-green-600 hover:text-green-900 mr-3">
                            <CheckCircle className="h-5 w-5" />
                          </button>
                        )}
                        {comment.status !== 'spam' && (
                          <button className="text-red-600 hover:text-red-900 mr-3">
                            <XCircle className="h-5 w-5" />
                          </button>
                        )}
                        <button className="text-red-600 hover:text-red-900">
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
      
      {/* Testimonials Tab Content */}
      {activeTab === 'testimonials' && (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          {isLoadingTestimonials ? (
            <div className="p-6 text-center">
              <p>{t('common.loading')}</p>
            </div>
          ) : filteredTestimonials.length === 0 ? (
            <div className="p-6 text-center">
              <p>{t('common.noResults')}</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('admin.content.testimonialAuthor')}
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('admin.content.testimonialContent')}
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('admin.content.testimonialRating')}
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('admin.content.commentStatus')}
                    </th>
                    <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('common.actions')}
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredTestimonials.map((testimonial) => (
                    <tr key={testimonial.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">{testimonial.author_name}</div>
                        <div className="text-sm text-gray-500">{testimonial.author_role}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900 line-clamp-2">{testimonial.content}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`h-4 w-4 ${i < testimonial.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
                            />
                          ))}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          testimonial.status === 'approved' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {t(`admin.content.${testimonial.status}`)}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        {testimonial.status === 'pending' && (
                          <button className="text-green-600 hover:text-green-900 mr-3">
                            <CheckCircle className="h-5 w-5" />
                          </button>
                        )}
                        <button className="text-red-600 hover:text-red-900">
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ContentManagement;
