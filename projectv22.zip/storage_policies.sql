-- إنشاء سياسات أمان لتخزين الملفات في Supabase

-- التحقق من وجود مجلد avatars
INSERT INTO storage.buckets (id, name, public)
VALUES ('avatars', 'avatars', true)
ON CONFLICT (id) DO NOTHING;

-- حذف جميع السياسات الموجودة لمجلد avatars
DO $$
DECLARE
    policy_name text;
BEGIN
    FOR policy_name IN (
        SELECT name FROM storage.policies WHERE bucket_id = 'avatars'
    ) LOOP
        DELETE FROM storage.policies WHERE name = policy_name AND bucket_id = 'avatars';
    END LOOP;
END $$;

-- إنشاء سياسة للقراءة: يمكن للجميع قراءة الملفات
INSERT INTO storage.policies (name, bucket_id, operation, definition)
VALUES ('Avatar Read Policy', 'avatars', 'SELECT', '{"statement":"TRUE"}');

-- إنشاء سياسة للإدخال: يمكن للمستخدمين المصادق عليهم إضافة ملفات
INSERT INTO storage.policies (name, bucket_id, operation, definition)
VALUES ('Avatar Insert Policy', 'avatars', 'INSERT', '{"statement":"auth.role() = ''authenticated''"}');

-- إنشاء سياسة للتحديث: يمكن للمستخدمين المصادق عليهم تحديث ملفاتهم فقط
INSERT INTO storage.policies (name, bucket_id, operation, definition)
VALUES ('Avatar Update Policy', 'avatars', 'UPDATE', '{"statement":"auth.role() = ''authenticated''"}');

-- إنشاء سياسة للحذف: يمكن للمستخدمين المصادق عليهم حذف ملفاتهم فقط
INSERT INTO storage.policies (name, bucket_id, operation, definition)
VALUES ('Avatar Delete Policy', 'avatars', 'DELETE', '{"statement":"auth.role() = ''authenticated''"}');
