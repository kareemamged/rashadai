-- إنشاء جدول notifications إذا لم يكن موجودًا

-- إنشاء الجدول
CREATE TABLE IF NOT EXISTS public.notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    type TEXT NOT NULL,
    is_read BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- إنشاء مؤشر على حقل user_id
CREATE INDEX IF NOT EXISTS notifications_user_id_idx ON public.notifications(user_id);

-- تفعيل RLS على جدول notifications
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- حذف جميع السياسات الموجودة
DO $$
DECLARE
    policy_name text;
BEGIN
    FOR policy_name IN (
        SELECT policyname FROM pg_policies WHERE tablename = 'notifications'
    ) LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON public.notifications', policy_name);
    END LOOP;
END $$;

-- سياسة للقراءة: يمكن للمستخدم قراءة إشعاراته فقط
CREATE POLICY "Users can view their own notifications"
  ON public.notifications FOR SELECT
  USING (auth.uid() = user_id);

-- سياسة للإدخال: يمكن للمستخدم إنشاء إشعاراته فقط
CREATE POLICY "Users can insert their own notifications"
  ON public.notifications FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- سياسة للتحديث: يمكن للمستخدم تحديث إشعاراته فقط
CREATE POLICY "Users can update their own notifications"
  ON public.notifications FOR UPDATE
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- سياسة للحذف: يمكن للمستخدم حذف إشعاراته فقط
CREATE POLICY "Users can delete their own notifications"
  ON public.notifications FOR DELETE
  USING (auth.uid() = user_id);

-- سياسة للمشرفين: يمكن للمشرفين الوصول إلى جميع الإشعارات
CREATE POLICY "Admins can do anything with notifications"
  ON public.notifications
  USING (auth.uid() IN (
    SELECT id FROM auth.users WHERE raw_user_meta_data->>'is_admin' = 'true'
  ));

-- منح صلاحيات للمستخدمين المصادق عليهم
GRANT ALL ON public.notifications TO authenticated;

-- منح صلاحيات للخدمة نفسها
GRANT ALL ON public.notifications TO service_role;
