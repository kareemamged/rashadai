-- إنشاء جدول blog_comments إذا لم يكن موجودًا

-- إنشاء الجدول
CREATE TABLE IF NOT EXISTS public.blog_comments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    post_id UUID REFERENCES public.blog_posts(id) ON DELETE CASCADE,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    likes_count INTEGER DEFAULT 0,
    dislikes_count INTEGER DEFAULT 0,
    approved BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- إنشاء مؤشر على حقل post_id
CREATE INDEX IF NOT EXISTS blog_comments_post_id_idx ON public.blog_comments(post_id);

-- إنشاء مؤشر على حقل user_id
CREATE INDEX IF NOT EXISTS blog_comments_user_id_idx ON public.blog_comments(user_id);

-- تفعيل RLS على جدول blog_comments
ALTER TABLE public.blog_comments ENABLE ROW LEVEL SECURITY;

-- حذف جميع السياسات الموجودة
DO $$
DECLARE
    policy_name text;
BEGIN
    FOR policy_name IN (
        SELECT policyname FROM pg_policies WHERE tablename = 'blog_comments'
    ) LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON public.blog_comments', policy_name);
    END LOOP;
END $$;

-- سياسة للقراءة: يمكن للجميع قراءة التعليقات المعتمدة
CREATE POLICY "Anyone can view approved blog comments"
  ON public.blog_comments FOR SELECT
  USING (approved = true);

-- سياسة للقراءة: يمكن للمستخدم قراءة تعليقاته غير المعتمدة
CREATE POLICY "Users can view their own unapproved blog comments"
  ON public.blog_comments FOR SELECT
  USING (auth.uid() = user_id AND approved = false);

-- سياسة للإدخال: يمكن للمستخدم إنشاء تعليقاته فقط
CREATE POLICY "Users can insert their own blog comments"
  ON public.blog_comments FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- سياسة للتحديث: يمكن للمستخدم تحديث تعليقاته فقط
CREATE POLICY "Users can update their own blog comments"
  ON public.blog_comments FOR UPDATE
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- سياسة للحذف: يمكن للمستخدم حذف تعليقاته فقط
CREATE POLICY "Users can delete their own blog comments"
  ON public.blog_comments FOR DELETE
  USING (auth.uid() = user_id);

-- سياسة للمشرفين: يمكن للمشرفين الوصول إلى جميع التعليقات
CREATE POLICY "Admins can do anything with blog comments"
  ON public.blog_comments
  USING (auth.uid() IN (
    SELECT id FROM auth.users WHERE raw_user_meta_data->>'is_admin' = 'true'
  ));

-- منح صلاحيات للمستخدمين المصادق عليهم
GRANT ALL ON public.blog_comments TO authenticated;

-- منح صلاحيات للمستخدمين غير المصادق عليهم (للقراءة فقط)
GRANT SELECT ON public.blog_comments TO anon;

-- منح صلاحيات للخدمة نفسها
GRANT ALL ON public.blog_comments TO service_role;
