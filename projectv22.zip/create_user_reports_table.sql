-- إنشاء جدول user_reports إذا لم يكن موجودًا

-- إنشاء الجدول
CREATE TABLE IF NOT EXISTS public.user_reports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    report_type TEXT NOT NULL,
    report_content TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- إنشاء مؤشر على حقل user_id
CREATE INDEX IF NOT EXISTS user_reports_user_id_idx ON public.user_reports(user_id);

-- تفعيل RLS على جدول user_reports
ALTER TABLE public.user_reports ENABLE ROW LEVEL SECURITY;

-- حذف جميع السياسات الموجودة
DO $$
DECLARE
    policy_name text;
BEGIN
    FOR policy_name IN (
        SELECT policyname FROM pg_policies WHERE tablename = 'user_reports'
    ) LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON public.user_reports', policy_name);
    END LOOP;
END $$;

-- سياسة للقراءة: يمكن للمستخدم قراءة تقاريره فقط
CREATE POLICY "Users can view their own reports"
  ON public.user_reports FOR SELECT
  USING (auth.uid() = user_id);

-- سياسة للإدخال: يمكن للمستخدم إنشاء تقاريره فقط
CREATE POLICY "Users can insert their own reports"
  ON public.user_reports FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- سياسة للتحديث: يمكن للمستخدم تحديث تقاريره فقط
CREATE POLICY "Users can update their own reports"
  ON public.user_reports FOR UPDATE
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- سياسة للحذف: يمكن للمستخدم حذف تقاريره فقط
CREATE POLICY "Users can delete their own reports"
  ON public.user_reports FOR DELETE
  USING (auth.uid() = user_id);

-- سياسة للمشرفين: يمكن للمشرفين الوصول إلى جميع التقارير
CREATE POLICY "Admins can do anything with reports"
  ON public.user_reports
  USING (auth.uid() IN (
    SELECT id FROM auth.users WHERE raw_user_meta_data->>'is_admin' = 'true'
  ));

-- منح صلاحيات للمستخدمين المصادق عليهم
GRANT ALL ON public.user_reports TO authenticated;

-- منح صلاحيات للخدمة نفسها
GRANT ALL ON public.user_reports TO service_role;
