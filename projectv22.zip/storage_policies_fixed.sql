-- إنشاء سياسات أمان لتخزين الملفات في Supabase

-- التحقق من وجود مجلد avatars
INSERT INTO storage.buckets (id, name, public)
VALUES ('avatars', 'avatars', true)
ON CONFLICT (id) DO NOTHING;

-- إنشاء سياسة للقراءة: يمكن للجميع قراءة الملفات
CREATE POLICY "Avatar Read Policy" ON storage.objects
    FOR SELECT
    USING (bucket_id = 'avatars');

-- إنشاء سياسة للإدخال: يمكن للمستخدمين المصادق عليهم إضافة ملفات
CREATE POLICY "Avatar Insert Policy" ON storage.objects
    FOR INSERT
    WITH CHECK (bucket_id = 'avatars' AND auth.role() = 'authenticated');

-- إنشاء سياسة للتحديث: يمكن للمستخدمين المصادق عليهم تحديث ملفاتهم فقط
CREATE POLICY "Avatar Update Policy" ON storage.objects
    FOR UPDATE
    USING (bucket_id = 'avatars' AND auth.role() = 'authenticated');

-- إنشاء سياسة للحذف: يمكن للمستخدمين المصادق عليهم حذف ملفاتهم فقط
CREATE POLICY "Avatar Delete Policy" ON storage.objects
    FOR DELETE
    USING (bucket_id = 'avatars' AND auth.role() = 'authenticated');
