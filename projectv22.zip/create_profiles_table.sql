-- إنشاء جدول profiles
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT,
  name TEXT,
  avatar TEXT,
  avatar_url TEXT,
  country_code TEXT,
  phone TEXT,
  bio TEXT,
  language TEXT DEFAULT 'ar',
  website TEXT,
  gender TEXT,
  birth_date TEXT,
  profession TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- إنشاء مؤشر على حقل id
CREATE INDEX IF NOT EXISTS profiles_id_idx ON public.profiles(id);

-- إنشاء دالة لإنشاء سجل في جدول profiles عند إنشاء مستخدم جديد
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  avatar_value TEXT;
BEGIN
  avatar_value := COALESCE(NEW.raw_user_meta_data->>'avatar', 'https://ui-avatars.com/api/?name=' || split_part(NEW.email, '@', 1) || '&background=random');

  INSERT INTO public.profiles (id, email, name, avatar, avatar_url, language, created_at, updated_at)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
    avatar_value,
    avatar_value,
    COALESCE(NEW.raw_user_meta_data->>'language', 'ar'),
    NEW.created_at,
    NEW.created_at
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- إنشاء trigger لتشغيل الدالة عند إنشاء مستخدم جديد
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- إعداد سياسات الأمان (RLS)
-- تفعيل RLS على جدول profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- حذف جميع السياسات الموجودة
DO $$
DECLARE
    policy_name text;
BEGIN
    FOR policy_name IN (
        SELECT policyname FROM pg_policies WHERE tablename = 'profiles'
    ) LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON public.profiles', policy_name);
    END LOOP;
END $$;

-- سياسة للقراءة: يمكن للجميع قراءة جميع الملفات الشخصية (للاختبار فقط)
CREATE POLICY "Anyone can view profiles"
  ON public.profiles FOR SELECT
  USING (true);

-- سياسة للإدخال: يمكن للمستخدم إنشاء ملفه الشخصي فقط
CREATE POLICY "Users can insert their own profile"
  ON public.profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

-- سياسة للتحديث: يمكن للمستخدم تحديث ملفه الشخصي فقط
CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- سياسة للحذف: يمكن للمستخدم حذف ملفه الشخصي فقط
CREATE POLICY "Users can delete their own profile"
  ON public.profiles FOR DELETE
  USING (auth.uid() = id);

-- سياسة للمشرفين: يمكن للمشرفين الوصول إلى جميع الملفات الشخصية
CREATE POLICY "Admins can do anything"
  ON public.profiles
  USING (auth.uid() IN (
    SELECT id FROM auth.users WHERE raw_user_meta_data->>'is_admin' = 'true'
  ));

-- منح صلاحيات للمستخدمين المصادق عليهم
GRANT ALL ON public.profiles TO authenticated;

-- منح صلاحيات للمستخدمين غير المصادق عليهم (للتسجيل)
GRANT ALL ON public.profiles TO anon;

-- منح صلاحيات للخدمة نفسها
GRANT ALL ON public.profiles TO service_role;
