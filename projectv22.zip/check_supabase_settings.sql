-- التحقق من إعدادات Supabase

-- التحقق من جداول مخطط auth
SELECT 
    table_name
FROM 
    information_schema.tables
WHERE 
    table_schema = 'auth'
ORDER BY 
    table_name;

-- التحقق من جداول مخطط public
SELECT 
    table_name
FROM 
    information_schema.tables
WHERE 
    table_schema = 'public'
ORDER BY 
    table_name;

-- التحقق من أعمدة جدول profiles
SELECT 
    column_name, 
    data_type, 
    is_nullable
FROM 
    information_schema.columns
WHERE 
    table_schema = 'public' 
    AND table_name = 'profiles'
ORDER BY 
    ordinal_position;

-- التحقق من سياسات الأمان لجدول profiles
SELECT 
    *
FROM 
    pg_policies
WHERE 
    tablename = 'profiles';

-- التحقق من المستخدمين المسجلين
SELECT 
    id, 
    email, 
    created_at
FROM 
    auth.users
LIMIT 10;

-- التحقق من الأدوار
SELECT 
    *
FROM 
    pg_roles
WHERE 
    rolname IN ('anon', 'authenticated', 'service_role');

-- التحقق من صلاحيات الجداول
SELECT 
    grantee, 
    table_schema, 
    table_name, 
    privilege_type
FROM 
    information_schema.table_privileges
WHERE 
    table_schema = 'public' 
    AND table_name = 'profiles'
ORDER BY 
    grantee, 
    table_schema, 
    table_name, 
    privilege_type;
