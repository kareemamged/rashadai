-- إصلاح سياسات الأمان لجدول auth.users
ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

-- إنشاء سياسة للقراءة
DROP POLICY IF EXISTS "Users can read their own user data" ON auth.users;
CREATE POLICY "Users can read their own user data"
ON auth.users
FOR SELECT
USING (auth.uid() = id);

-- إنشاء سياسة للتحديث
DROP POLICY IF EXISTS "Users can update their own user data" ON auth.users;
CREATE POLICY "Users can update their own user data"
ON auth.users
FOR UPDATE
USING (auth.uid() = id);

-- إنشاء سياسة للإدراج
DROP POLICY IF EXISTS "Users can insert their own user data" ON auth.users;
CREATE POLICY "Users can insert their own user data"
ON auth.users
FOR INSERT
WITH CHECK (auth.uid() = id);

-- منح صلاحيات للمستخدمين المصادق عليهم
GRANT SELECT, UPDATE ON auth.users TO authenticated;

-- منح صلاحيات للمستخدمين غير المصادق عليهم (للتسجيل)
GRANT INSERT ON auth.users TO anon;

-- إصلاح سياسات الأمان لجدول storage
-- إنشاء سياسة للقراءة
DROP POLICY IF EXISTS "Users can read their own avatars" ON storage.objects;
CREATE POLICY "Users can read their own avatars"
ON storage.objects
FOR SELECT
USING (auth.uid()::text = (storage.foldername(name))[1]);

-- إنشاء سياسة للتحديث
DROP POLICY IF EXISTS "Users can update their own avatars" ON storage.objects;
CREATE POLICY "Users can update their own avatars"
ON storage.objects
FOR UPDATE
USING (auth.uid()::text = (storage.foldername(name))[1]);

-- إنشاء سياسة للإدراج
DROP POLICY IF EXISTS "Users can insert their own avatars" ON storage.objects;
CREATE POLICY "Users can insert their own avatars"
ON storage.objects
FOR INSERT
WITH CHECK (auth.uid()::text = (storage.foldername(name))[1]);

-- إنشاء سياسة للحذف
DROP POLICY IF EXISTS "Users can delete their own avatars" ON storage.objects;
CREATE POLICY "Users can delete their own avatars"
ON storage.objects
FOR DELETE
USING (auth.uid()::text = (storage.foldername(name))[1]);

-- منح صلاحيات للمستخدمين المصادق عليهم
GRANT SELECT, UPDATE, INSERT, DELETE ON storage.objects TO authenticated;

-- منح صلاحيات للمستخدمين غير المصادق عليهم (للتسجيل)
GRANT INSERT ON storage.objects TO anon;
