-- تفعيل التسجيل في Supabase

-- تفعيل التسجيل
ALTER SYSTEM SET supabase.auth.enable_signup = 'true';
SELECT pg_reload_conf();

-- تفعيل التسجيل بالبريد الإلكتروني
ALTER SYSTEM SET supabase.auth.enable_email_signup = 'true';
SELECT pg_reload_conf();

-- تفعيل التأكيد التلقائي للبريد الإلكتروني
ALTER SYSTEM SET supabase.auth.enable_email_autoconfirm = 'true';
SELECT pg_reload_conf();
