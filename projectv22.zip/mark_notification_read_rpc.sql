-- إنشاء دالة RPC لتحديث حالة قراءة الإشعار

-- إنشاء الدالة
CREATE OR REPLACE FUNCTION public.mark_notification_read(
    notification_id UUID,
    is_read BOOLEAN DEFAULT true
) RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    result JSONB;
    current_user_id UUID;
    notification_user_id UUID;
BEGIN
    -- الحصول على معرف المستخدم الحالي
    current_user_id := auth.uid();
    
    -- التحقق من أن الإشعار ينتمي للمستخدم الحالي
    SELECT user_id INTO notification_user_id
    FROM public.notifications
    WHERE id = notification_id;
    
    IF notification_user_id IS NULL THEN
        RAISE EXCEPTION 'Notification not found';
    END IF;
    
    IF notification_user_id <> current_user_id THEN
        RAISE EXCEPTION 'You can only mark your own notifications as read';
    END IF;
    
    -- تحديث حالة قراءة الإشعار
    UPDATE public.notifications
    SET
        is_read = mark_notification_read.is_read,
        updated_at = NOW()
    WHERE id = notification_id
    RETURNING to_jsonb(notifications.*) INTO result;
    
    RETURN result;
END;
$$;

-- منح صلاحيات تنفيذ الدالة للمستخدمين المصادق عليهم
GRANT EXECUTE ON FUNCTION public.mark_notification_read TO authenticated;

-- منح صلاحيات تنفيذ الدالة للخدمة نفسها
GRANT EXECUTE ON FUNCTION public.mark_notification_read TO service_role;
