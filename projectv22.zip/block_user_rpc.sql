-- إنشاء دالة RPC لحظر المستخدمين

-- إنشاء الدالة
CREATE OR REPLACE FUNCTION public.block_user(
    user_id UUID,
    is_blocked BOOLEAN
) RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    result JSONB;
    current_user_id UUID;
    is_admin BOOLEAN;
BEGIN
    -- التحقق من أن المستخدم الحالي هو مشرف
    current_user_id := auth.uid();
    
    SELECT (raw_user_meta_data->>'is_admin')::BOOLEAN INTO is_admin
    FROM auth.users
    WHERE id = current_user_id;
    
    IF is_admin IS NOT TRUE THEN
        RAISE EXCEPTION 'Only admins can block users';
    END IF;
    
    -- تحديث حالة الحظر للمستخدم
    UPDATE auth.users
    SET raw_user_meta_data = 
        CASE 
            WHEN raw_user_meta_data IS NULL THEN 
                jsonb_build_object('is_blocked', is_blocked)
            ELSE 
                raw_user_meta_data || jsonb_build_object('is_blocked', is_blocked)
        END
    WHERE id = user_id
    RETURNING to_jsonb(users.*) INTO result;
    
    RETURN result;
END;
$$;

-- منح صلاحيات تنفيذ الدالة للمستخدمين المصادق عليهم
GRANT EXECUTE ON FUNCTION public.block_user TO authenticated;

-- منح صلاحيات تنفيذ الدالة للخدمة نفسها
GRANT EXECUTE ON FUNCTION public.block_user TO service_role;
