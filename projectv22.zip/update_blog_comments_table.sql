-- تحديث جدول blog_comments

-- التحقق من وجود العمود is_approved
DO $$
DECLARE
    column_exists BOOLEAN;
BEGIN
    SELECT EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_name = 'blog_comments'
        AND column_name = 'is_approved'
    ) INTO column_exists;

    IF column_exists THEN
        -- إذا كان العمود موجودًا، قم بتغيير اسمه إلى approved
        EXECUTE 'ALTER TABLE public.blog_comments RENAME COLUMN is_approved TO approved';
    END IF;
END $$;

-- التحقق من وجود العمود author_id
DO $$
DECLARE
    column_exists BOOLEAN;
BEGIN
    SELECT EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_name = 'blog_comments'
        AND column_name = 'author_id'
    ) INTO column_exists;

    IF column_exists THEN
        -- إذا كان العمود موجودًا، قم بتغيير اسمه إلى user_id
        EXECUTE 'ALTER TABLE public.blog_comments RENAME COLUMN author_id TO user_id';
    END IF;
END $$;

-- تحديث المؤشر على حقل user_id
DO $$
DECLARE
    index_exists BOOLEAN;
BEGIN
    SELECT EXISTS (
        SELECT 1
        FROM pg_indexes
        WHERE indexname = 'blog_comments_author_id_idx'
    ) INTO index_exists;

    IF index_exists THEN
        -- إذا كان المؤشر موجودًا، قم بحذفه وإنشاء مؤشر جديد
        EXECUTE 'DROP INDEX IF EXISTS blog_comments_author_id_idx';
        EXECUTE 'CREATE INDEX IF NOT EXISTS blog_comments_user_id_idx ON public.blog_comments(user_id)';
    END IF;
END $$;

-- تحديث سياسات الأمان
-- حذف جميع السياسات الموجودة
DO $$
DECLARE
    policy_name text;
BEGIN
    FOR policy_name IN (
        SELECT policyname FROM pg_policies WHERE tablename = 'blog_comments'
    ) LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON public.blog_comments', policy_name);
    END LOOP;
END $$;

-- سياسة للقراءة: يمكن للجميع قراءة التعليقات المعتمدة
CREATE POLICY "Anyone can view approved blog comments"
  ON public.blog_comments FOR SELECT
  USING (approved = true);

-- سياسة للقراءة: يمكن للمستخدم قراءة تعليقاته غير المعتمدة
CREATE POLICY "Users can view their own unapproved blog comments"
  ON public.blog_comments FOR SELECT
  USING (auth.uid() = user_id AND approved = false);

-- سياسة للإدخال: يمكن للمستخدم إنشاء تعليقاته فقط
CREATE POLICY "Users can insert their own blog comments"
  ON public.blog_comments FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- سياسة للتحديث: يمكن للمستخدم تحديث تعليقاته فقط
CREATE POLICY "Users can update their own blog comments"
  ON public.blog_comments FOR UPDATE
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- سياسة للحذف: يمكن للمستخدم حذف تعليقاته فقط
CREATE POLICY "Users can delete their own blog comments"
  ON public.blog_comments FOR DELETE
  USING (auth.uid() = user_id);

-- سياسة للمشرفين: يمكن للمشرفين الوصول إلى جميع التعليقات
CREATE POLICY "Admins can do anything with blog comments"
  ON public.blog_comments
  USING (auth.uid() IN (
    SELECT id FROM auth.users WHERE raw_user_meta_data->>'is_admin' = 'true'
  ));

-- منح صلاحيات للمستخدمين المصادق عليهم
GRANT ALL ON public.blog_comments TO authenticated;

-- منح صلاحيات للمستخدمين غير المصادق عليهم (للقراءة فقط)
GRANT SELECT ON public.blog_comments TO anon;

-- منح صلاحيات للخدمة نفسها
GRANT ALL ON public.blog_comments TO service_role;
