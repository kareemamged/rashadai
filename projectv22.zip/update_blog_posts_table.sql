-- تحديث جدول blog_posts

-- التحقق من وجود العمود is_published
DO $$
DECLARE
    column_exists BOOLEAN;
BEGIN
    SELECT EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_name = 'blog_posts'
        AND column_name = 'is_published'
    ) INTO column_exists;

    IF column_exists THEN
        -- إذا كان العمود موجودًا، قم بتغيير اسمه إلى published
        EXECUTE 'ALTER TABLE public.blog_posts RENAME COLUMN is_published TO published';
    END IF;
END $$;

-- تحديث سياسات الأمان
-- حذف جميع السياسات الموجودة
DO $$
DECLARE
    policy_name text;
BEGIN
    FOR policy_name IN (
        SELECT policyname FROM pg_policies WHERE tablename = 'blog_posts'
    ) LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON public.blog_posts', policy_name);
    END LOOP;
END $$;

-- سياسة للقراءة: يمكن للجميع قراءة المنشورات المنشورة
CREATE POLICY "Anyone can view published blog posts"
  ON public.blog_posts FOR SELECT
  USING (published = true);

-- سياسة للقراءة: يمكن للمستخدم قراءة منشوراته غير المنشورة
CREATE POLICY "Users can view their own unpublished blog posts"
  ON public.blog_posts FOR SELECT
  USING (auth.uid() = author_id AND published = false);

-- سياسة للإدخال: يمكن للمستخدم إنشاء منشوراته فقط
CREATE POLICY "Users can insert their own blog posts"
  ON public.blog_posts FOR INSERT
  WITH CHECK (auth.uid() = author_id);

-- سياسة للتحديث: يمكن للمستخدم تحديث منشوراته فقط
CREATE POLICY "Users can update their own blog posts"
  ON public.blog_posts FOR UPDATE
  USING (auth.uid() = author_id)
  WITH CHECK (auth.uid() = author_id);

-- سياسة للحذف: يمكن للمستخدم حذف منشوراته فقط
CREATE POLICY "Users can delete their own blog posts"
  ON public.blog_posts FOR DELETE
  USING (auth.uid() = author_id);

-- سياسة للمشرفين: يمكن للمشرفين الوصول إلى جميع المنشورات
CREATE POLICY "Admins can do anything with blog posts"
  ON public.blog_posts
  USING (auth.uid() IN (
    SELECT id FROM auth.users WHERE raw_user_meta_data->>'is_admin' = 'true'
  ));

-- منح صلاحيات للمستخدمين المصادق عليهم
GRANT ALL ON public.blog_posts TO authenticated;

-- منح صلاحيات للمستخدمين غير المصادق عليهم (للقراءة فقط)
GRANT SELECT ON public.blog_posts TO anon;

-- منح صلاحيات للخدمة نفسها
GRANT ALL ON public.blog_posts TO service_role;
