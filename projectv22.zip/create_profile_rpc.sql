-- إنشاء دالة RPC لإنشاء سجل في جدول profiles

-- إنشاء الدالة
CREATE OR REPLACE FUNCTION public.create_profile(
    user_id UUID,
    user_email TEXT,
    user_name TEXT,
    user_avatar TEXT,
    user_language TEXT,
    user_country_code TEXT
) RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    result JSONB;
BEGIN
    -- إدخال أو تحديث سجل في جدول profiles
    INSERT INTO public.profiles (
        id,
        email,
        name,
        avatar,
        avatar_url,
        language,
        country_code,
        created_at,
        updated_at
    ) VALUES (
        user_id,
        user_email,
        user_name,
        user_avatar,
        user_avatar,
        user_language,
        user_country_code,
        NOW(),
        NOW()
    )
    ON CONFLICT (id) DO UPDATE SET
        email = EXCLUDED.email,
        name = EXCLUDED.name,
        avatar = EXCLUDED.avatar,
        avatar_url = EXCLUDED.avatar_url,
        language = EXCLUDED.language,
        country_code = EXCLUDED.country_code,
        updated_at = NOW()
    RETURNING to_jsonb(profiles.*) INTO result;

    RETURN result;
END;
$$;

-- منح صلاحيات تنفيذ الدالة للمستخدمين المصادق عليهم
GRANT EXECUTE ON FUNCTION public.create_profile TO authenticated;

-- منح صلاحيات تنفيذ الدالة للمستخدمين غير المصادق عليهم (للتسجيل)
GRANT EXECUTE ON FUNCTION public.create_profile TO anon;
