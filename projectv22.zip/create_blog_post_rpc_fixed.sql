-- إنشاء دالة RPC لإنشاء منشور في المدونة

-- حذف الدالة الموجودة أولاً
DROP FUNCTION IF EXISTS public.create_blog_post;

-- إنشاء الدالة
CREATE OR REPLACE FUNCTION public.create_blog_post(
    title_en TEXT,
    title_ar TEXT,
    content_en TEXT,
    content_ar TEXT,
    category TEXT,
    image_url TEXT DEFAULT NULL,
    published BOOLEAN DEFAULT false
) RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    result JSONB;
    current_user_id UUID;
    is_admin BOOLEAN;
BEGIN
    -- التحقق من أن المستخدم الحالي هو مشرف
    current_user_id := auth.uid();
    
    SELECT (raw_user_meta_data->>'is_admin')::BOOLEAN INTO is_admin
    FROM auth.users
    WHERE id = current_user_id;
    
    IF is_admin IS NOT TRUE THEN
        RAISE EXCEPTION 'Only admins can create blog posts';
    END IF;
    
    -- التحقق من توفر النص باللغتين
    IF title_en IS NULL OR title_en = '' OR title_ar IS NULL OR title_ar = '' THEN
        RAISE EXCEPTION 'Title must be provided in both English and Arabic';
    END IF;
    
    IF content_en IS NULL OR content_en = '' OR content_ar IS NULL OR content_ar = '' THEN
        RAISE EXCEPTION 'Content must be provided in both English and Arabic';
    END IF;
    
    -- إنشاء منشور جديد
    INSERT INTO public.blog_posts (
        author_id,
        title_en,
        title_ar,
        content_en,
        content_ar,
        category,
        image_url,
        published,
        created_at,
        updated_at
    ) VALUES (
        current_user_id,
        title_en,
        title_ar,
        content_en,
        content_ar,
        category,
        image_url,
        published,
        NOW(),
        NOW()
    )
    RETURNING to_jsonb(blog_posts.*) INTO result;
    
    RETURN result;
END;
$$;

-- منح صلاحيات تنفيذ الدالة للمستخدمين المصادق عليهم
GRANT EXECUTE ON FUNCTION public.create_blog_post TO authenticated;
