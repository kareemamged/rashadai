-- إنشاء دالة RPC لتحديث منشور في المدونة

-- إنشاء الدالة
CREATE OR REPLACE FUNCTION public.update_blog_post(
    post_id UUID,
    title_en TEXT DEFAULT NULL,
    title_ar TEXT DEFAULT NULL,
    content_en TEXT DEFAULT NULL,
    content_ar TEXT DEFAULT NULL,
    category TEXT DEFAULT NULL,
    image_url TEXT DEFAULT NULL,
    published BOOLEAN DEFAULT NULL
) RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    result JSONB;
    current_user_id UUID;
    is_admin BOOLEAN;
    post_author_id UUID;
BEGIN
    -- التحقق من أن المستخدم الحالي هو مشرف أو صاحب المنشور
    current_user_id := auth.uid();

    SELECT (raw_user_meta_data->>'is_admin')::BOOLEAN INTO is_admin
    FROM auth.users
    WHERE id = current_user_id;

    SELECT author_id INTO post_author_id
    FROM public.blog_posts
    WHERE id = post_id;

    IF post_author_id IS NULL THEN
        RAISE EXCEPTION 'Blog post not found';
    END IF;

    IF is_admin IS NOT TRUE AND current_user_id <> post_author_id THEN
        RAISE EXCEPTION 'Only admins or the author can update blog posts';
    END IF;

    -- تحديث المنشور
    UPDATE public.blog_posts
    SET
        title_en = COALESCE(update_blog_post.title_en, blog_posts.title_en),
        title_ar = COALESCE(update_blog_post.title_ar, blog_posts.title_ar),
        content_en = COALESCE(update_blog_post.content_en, blog_posts.content_en),
        content_ar = COALESCE(update_blog_post.content_ar, blog_posts.content_ar),
        category = COALESCE(update_blog_post.category, blog_posts.category),
        image_url = COALESCE(update_blog_post.image_url, blog_posts.image_url),
        published = COALESCE(update_blog_post.published, blog_posts.published),
        updated_at = NOW()
    WHERE id = post_id
    RETURNING to_jsonb(blog_posts.*) INTO result;

    RETURN result;
END;
$$;

-- منح صلاحيات تنفيذ الدالة للمستخدمين المصادق عليهم
GRANT EXECUTE ON FUNCTION public.update_blog_post TO authenticated;

-- منح صلاحيات تنفيذ الدالة للخدمة نفسها
GRANT EXECUTE ON FUNCTION public.update_blog_post TO service_role;
