-- إنشاء جدول blog_posts إذا لم يكن موجودًا

-- التحقق من وجود الجدول
DO $$
DECLARE
    table_exists BOOLEAN;
BEGIN
    SELECT EXISTS (
        SELECT 1
        FROM information_schema.tables
        WHERE table_name = 'blog_posts'
    ) INTO table_exists;

    IF NOT table_exists THEN
        -- إنشاء الجدول
        CREATE TABLE public.blog_posts (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            author_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
            title_en TEXT NOT NULL,
            title_ar TEXT NOT NULL,
            content_en TEXT NOT NULL,
            content_ar TEXT NOT NULL,
            category TEXT NOT NULL,
            image_url TEXT,
            likes_count INTEGER DEFAULT 0,
            dislikes_count INTEGER DEFAULT 0,
            published BOOLEAN DEFAULT false,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );

        -- إنشاء مؤشر على حقل author_id
        CREATE INDEX IF NOT EXISTS blog_posts_author_id_idx ON public.blog_posts(author_id);
    END IF;
END $$;

-- تفعيل RLS على جدول blog_posts
ALTER TABLE public.blog_posts ENABLE ROW LEVEL SECURITY;

-- حذف جميع السياسات الموجودة
DO $$
DECLARE
    policy_name text;
BEGIN
    FOR policy_name IN (
        SELECT policyname FROM pg_policies WHERE tablename = 'blog_posts'
    ) LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON public.blog_posts', policy_name);
    END LOOP;
END $$;

-- سياسة للقراءة: يمكن للجميع قراءة المنشورات المنشورة
CREATE POLICY "Anyone can view published blog posts"
  ON public.blog_posts FOR SELECT
  USING (published = true);

-- سياسة للقراءة: يمكن للمستخدم قراءة منشوراته غير المنشورة
CREATE POLICY "Users can view their own unpublished blog posts"
  ON public.blog_posts FOR SELECT
  USING (auth.uid() = author_id AND published = false);

-- سياسة للإدخال: يمكن للمستخدم إنشاء منشوراته فقط
CREATE POLICY "Users can insert their own blog posts"
  ON public.blog_posts FOR INSERT
  WITH CHECK (auth.uid() = author_id);

-- سياسة للتحديث: يمكن للمستخدم تحديث منشوراته فقط
CREATE POLICY "Users can update their own blog posts"
  ON public.blog_posts FOR UPDATE
  USING (auth.uid() = author_id)
  WITH CHECK (auth.uid() = author_id);

-- سياسة للحذف: يمكن للمستخدم حذف منشوراته فقط
CREATE POLICY "Users can delete their own blog posts"
  ON public.blog_posts FOR DELETE
  USING (auth.uid() = author_id);

-- سياسة للمشرفين: يمكن للمشرفين الوصول إلى جميع المنشورات
CREATE POLICY "Admins can do anything with blog posts"
  ON public.blog_posts
  USING (auth.uid() IN (
    SELECT id FROM auth.users WHERE raw_user_meta_data->>'is_admin' = 'true'
  ));

-- منح صلاحيات للمستخدمين المصادق عليهم
GRANT ALL ON public.blog_posts TO authenticated;

-- منح صلاحيات للمستخدمين غير المصادق عليهم (للقراءة فقط)
GRANT SELECT ON public.blog_posts TO anon;

-- منح صلاحيات للخدمة نفسها
GRANT ALL ON public.blog_posts TO service_role;
