-- إنشاء دالة RPC لإنشاء تعليق على منشور في المدونة

-- إنشاء الدالة
CREATE OR REPLACE FUNCTION public.create_blog_comment(
    post_id UUID,
    content TEXT,
    approved BOOLEAN DEFAULT false
) RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    result JSONB;
    current_user_id UUID;
    is_admin BOOLEAN;
    post_exists BOOLEAN;
BEGIN
    -- التحقق من وجود المنشور
    SELECT EXISTS(SELECT 1 FROM public.blog_posts WHERE id = post_id) INTO post_exists;

    IF NOT post_exists THEN
        RAISE EXCEPTION 'Blog post not found';
    END IF;

    -- الحصول على معرف المستخدم الحالي
    current_user_id := auth.uid();

    -- التحقق من أن المستخدم الحالي هو مشرف (للموافقة التلقائية على التعليق)
    SELECT (raw_user_meta_data->>'is_admin')::BOOLEAN INTO is_admin
    FROM auth.users
    WHERE id = current_user_id;

    -- إذا كان المستخدم مشرفًا، فسيتم الموافقة على التعليق تلقائيًا
    IF is_admin THEN
        approved := true;
    END IF;

    -- إنشاء تعليق جديد
    INSERT INTO public.blog_comments (
        post_id,
        user_id,
        content,
        approved,
        created_at,
        updated_at
    ) VALUES (
        post_id,
        current_user_id,
        content,
        approved,
        NOW(),
        NOW()
    )
    RETURNING to_jsonb(blog_comments.*) INTO result;

    RETURN result;
END;
$$;

-- منح صلاحيات تنفيذ الدالة للمستخدمين المصادق عليهم
GRANT EXECUTE ON FUNCTION public.create_blog_comment TO authenticated;

-- منح صلاحيات تنفيذ الدالة للخدمة نفسها
GRANT EXECUTE ON FUNCTION public.create_blog_comment TO service_role;
