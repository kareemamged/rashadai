import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Hero from './components/Hero';
import Features from './components/Features';
import HowItWorks from './components/HowItWorks';
import TestimonialsSlider from './components/TestimonialsSlider';
import FAQ from './components/FAQ';
import CTA from './components/CTA';
import TestimonialsPage from './pages/Testimonials';
import BlogPage from './pages/BlogPage';
import PostDetailPage from './pages/PostDetailPage';
import ConsultationForm from './pages/Consultation';
import AboutUs from './pages/AboutUs';
import ContactUs from './pages/ContactUs';
import TermsAndConditions from './pages/TermsAndConditions';
import HIPAACompliance from './pages/legal/HIPAACompliance';
import PrivacyPolicy from './pages/legal/PrivacyPolicy';
import Cookies from './pages/legal/Cookies';
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import Chat from './pages/Chat';
import Profile from './pages/profile/Profile';
import ChangePassword from './pages/profile/ChangePassword';
import Settings from './pages/profile/Settings';
import ChatHistory from './pages/profile/ChatHistory';
import ProtectedRoute from './components/ProtectedRoute';
import AdminProtectedRoute from './components/AdminProtectedRoute';
import AdminLogin from './components/admin/Login';
import AdminDashboard from './pages/admin/AdminDashboard';
import UsersManagement from './pages/admin/UsersManagement';
import BlogManagement from './pages/admin/BlogManagement';
import { useAuthStore } from './store/authStore';
import { useAdminStore } from './store/adminStore';
import { ToastProvider } from './components/ToastContainer';

function App() {
  const { checkAuth } = useAuthStore();
  const { checkAdminAuth } = useAdminStore();

  useEffect(() => {
    // Check authentication status when the app loads
    checkAuth();
    checkAdminAuth();
  }, [checkAuth, checkAdminAuth]);

  return (
    <ToastProvider>
      <Router>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={
            <Layout>
              <Hero />
              <Features />
              <HowItWorks />
              <TestimonialsSlider />
              <FAQ />
              <CTA />
            </Layout>
          } />
          <Route path="/testimonials" element={<TestimonialsPage />} />
          <Route path="/consultation" element={<ConsultationForm />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/blog/category/:category" element={<BlogPage />} />
          <Route path="/post/:id" element={<PostDetailPage />} />
          <Route path="/about" element={<AboutUs />} />
          <Route path="/contact" element={<ContactUs />} />
          <Route path="/terms" element={<TermsAndConditions />} />
          <Route path="/hipaa-compliance" element={<HIPAACompliance />} />
          <Route path="/privacy-policy" element={<PrivacyPolicy />} />
          <Route path="/cookies" element={<Cookies />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/auth/callback" element={<Navigate to="/chat" replace />} />

          {/* Protected User Routes */}
          <Route path="/chat" element={<ProtectedRoute><Chat /></ProtectedRoute>} />
          <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
          <Route path="/change-password" element={<ProtectedRoute><ChangePassword /></ProtectedRoute>} />
          <Route path="/settings" element={<ProtectedRoute><Settings /></ProtectedRoute>} />
          <Route path="/chat-history" element={<ProtectedRoute><ChatHistory /></ProtectedRoute>} />

          {/* Admin Routes */}
          <Route path="/admin/login" element={<AdminLogin />} />
          <Route path="/admin" element={<Navigate to="/admin/dashboard" replace />} />
          <Route path="/admin/dashboard" element={<AdminProtectedRoute><AdminDashboard /></AdminProtectedRoute>} />
          <Route path="/admin/users" element={<AdminProtectedRoute><UsersManagement /></AdminProtectedRoute>} />
          <Route path="/admin/blog" element={<AdminProtectedRoute><BlogManagement /></AdminProtectedRoute>} />

          {/* Fallback Route */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Router>
    </ToastProvider>
  );
}

export default App;
