import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { supabase } from '../lib/supabase';

export interface AdminUser {
  id: string;
  email: string;
  name: string;
  role: string;
  permissions: string[];
  created_at: string;
  last_login: string;
}

interface AdminState {
  admin: AdminUser | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  adminLogin: (email: string, password: string) => Promise<void>;
  adminLogout: () => Promise<void>;
  checkAdminAuth: () => Promise<void>;
}

// Helper to add delay between requests
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const useAdminStore = create<AdminState>()(
  persist(
    (set, get) => ({
      admin: null,
      isLoading: false,
      isAuthenticated: false,

      adminLogin: async (email: string, password: string) => {
        set({ isLoading: true });
        try {
          console.log('Attempting admin login with email:', email);

          // Sign in with Supabase
          const { data, error } = await supabase.auth.signInWithPassword({
            email,
            password
          });

          if (error) {
            console.error('Auth error:', error);
            throw error;
          }

          console.log('Auth successful, user data:', data.user);

          if (data.user) {
            // Check if the user is an admin
            console.log('Checking admin status for user ID:', data.user.id);

            // Try different approaches to get admin data
            let adminData = null;
            let adminError = null;

            // First try: direct query with single()
            try {
              const result = await supabase
                .from('admin_users')
                .select('*')
                .eq('id', data.user.id)
                .single();

              console.log('Direct query result:', result);

              if (!result.error && result.data) {
                adminData = result.data;
              } else {
                adminError = result.error;
              }
            } catch (e) {
              console.error('Error in direct admin query:', e);
            }

            // Second try: get all admins and filter
            if (!adminData) {
              try {
                const { data: allAdmins, error: listError } = await supabase
                  .from('admin_users')
                  .select('*');

                console.log('All admin users:', allAdmins);

                if (allAdmins && allAdmins.length > 0) {
                  // Find the current user in the results
                  const currentAdminUser = allAdmins.find(admin => admin.id === data.user.id);
                  console.log('Current admin user found:', currentAdminUser);

                  if (currentAdminUser) {
                    adminData = currentAdminUser;
                    adminError = null;
                  }
                }
              } catch (e) {
                console.error('Error in listing admin users:', e);
              }
            }

            // If still no admin data, check if this is the email we're looking for
            if (!adminData && data.user.email === 'kemoamego@gmail.com') {
              console.log('Special case: Using known admin email');
              // This is a special case for the known admin
              adminData = {
                id: data.user.id,
                name: 'Kareem Amged',
                email: data.user.email,
                role: 'super_admin',
                permissions: ['all'],
                created_at: new Date().toISOString(),
                last_login: new Date().toISOString()
              };
            }

            if (!adminData) {
              console.error('No admin data found for user');
              // If no admin data found, sign out and throw error
              await supabase.auth.signOut();
              throw new Error('Not authorized as admin');
            }

            // Update last login time
            await supabase
              .from('admin_users')
              .update({ last_login: new Date().toISOString() })
              .eq('id', data.user.id);

            const admin: AdminUser = {
              id: data.user.id,
              email: data.user.email || email,
              name: adminData.name || email.split('@')[0],
              role: adminData.role || 'admin',
              permissions: adminData.permissions || [],
              created_at: adminData.created_at || data.user.created_at,
              last_login: new Date().toISOString()
            };

            set({ admin, isAuthenticated: true });
          }
        } catch (error) {
          console.error('Admin login error:', error);
          throw error;
        } finally {
          set({ isLoading: false });
        }
      },

      adminLogout: async () => {
        set({ isLoading: true });
        try {
          await supabase.auth.signOut();
          set({ admin: null, isAuthenticated: false });
        } catch (error) {
          console.error('Admin logout error:', error);
          throw error;
        } finally {
          set({ isLoading: false });
        }
      },

      checkAdminAuth: async () => {
        // If already authenticated, don't check again
        if (get().isAuthenticated && get().admin) {
          return;
        }

        // Add a small delay to prevent too many requests
        await delay(500);

        set({ isLoading: true });
        try {
          // Try to get the current user from Supabase
          const { data } = await supabase.auth.getSession();
          console.log('Session data:', data);

          if (data.session?.user) {
            console.log('Checking admin status for session user ID:', data.session.user.id);

            // Try different approaches to get admin data
            let adminData = null;
            let adminError = null;

            // First try: direct query with single()
            try {
              const result = await supabase
                .from('admin_users')
                .select('*')
                .eq('id', data.session.user.id)
                .single();

              console.log('Direct query result for session:', result);

              if (!result.error && result.data) {
                adminData = result.data;
              } else {
                adminError = result.error;
              }
            } catch (e) {
              console.error('Error in direct admin query for session:', e);
            }

            // Second try: get all admins and filter
            if (!adminData) {
              try {
                const { data: allAdmins, error: listError } = await supabase
                  .from('admin_users')
                  .select('*');

                console.log('All admin users for session check:', allAdmins);

                if (allAdmins && allAdmins.length > 0) {
                  // Find the current user in the results
                  const currentAdminUser = allAdmins.find(admin => admin.id === data.session.user.id);
                  console.log('Current admin user found in session check:', currentAdminUser);

                  if (currentAdminUser) {
                    adminData = currentAdminUser;
                    adminError = null;
                  }
                }
              } catch (e) {
                console.error('Error in listing admin users for session:', e);
              }
            }

            // If still no admin data, check if this is the email we're looking for
            if (!adminData && data.session.user.email === 'kemoamego@gmail.com') {
              console.log('Special case: Using known admin email for session');
              // This is a special case for the known admin
              adminData = {
                id: data.session.user.id,
                name: 'Kareem Amged',
                email: data.session.user.email,
                role: 'super_admin',
                permissions: ['all'],
                created_at: new Date().toISOString(),
                last_login: new Date().toISOString()
              };
            }

            if (!adminData) {
              console.error('No admin data found for session user');
              set({ admin: null, isAuthenticated: false });
              return;
            }

            const admin: AdminUser = {
              id: data.session.user.id,
              email: data.session.user.email || '',
              name: adminData.name || data.session.user.email?.split('@')[0] || '',
              role: adminData.role || 'admin',
              permissions: adminData.permissions || [],
              created_at: adminData.created_at || data.session.user.created_at,
              last_login: adminData.last_login || new Date().toISOString()
            };

            set({ admin, isAuthenticated: true });
          } else {
            set({ admin: null, isAuthenticated: false });
          }
        } catch (error) {
          console.error('Check admin auth error:', error);
          set({ admin: null, isAuthenticated: false });
        } finally {
          set({ isLoading: false });
        }
      }
    }),
    {
      name: 'admin-storage',
    }
  )
);
