import React, { useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { useAdminStore } from '../../store/adminStore';
import Dashboard from '../../components/admin/Dashboard';

const AdminDashboard: React.FC = () => {
  const { admin, isAuthenticated, checkAdminAuth } = useAdminStore();

  useEffect(() => {
    checkAdminAuth();
  }, [checkAdminAuth]);

  if (!isAuthenticated || !admin) {
    return <Navigate to="/admin/login" replace />;
  }

  return <Dashboard />;
};

export default AdminDashboard;
