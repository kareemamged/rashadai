import React, { useEffect } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAdminStore } from '../store/adminStore';

interface AdminProtectedRouteProps {
  children: React.ReactNode;
  requiredPermissions?: string[];
}

const AdminProtectedRoute: React.FC<AdminProtectedRouteProps> = ({ 
  children, 
  requiredPermissions = [] 
}) => {
  const { admin, isAuthenticated, isLoading, checkAdminAuth } = useAdminStore();
  const location = useLocation();

  useEffect(() => {
    checkAdminAuth();
  }, [checkAdminAuth]);

  // If still loading, show loading spinner
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  // If not authenticated, redirect to admin login
  if (!isAuthenticated || !admin) {
    return <Navigate to="/admin/login" state={{ from: location }} replace />;
  }

  // Check permissions if required
  if (requiredPermissions.length > 0) {
    const hasRequiredPermissions = requiredPermissions.every(permission => 
      admin.permissions.includes(permission)
    );

    if (!hasRequiredPermissions) {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center">
          <h1 className="text-2xl font-bold text-red-600 mb-4">Access Denied</h1>
          <p className="text-gray-600">You don't have permission to access this page.</p>
        </div>
      );
    }
  }

  // If authenticated and has permissions, render children
  return <>{children}</>;
};

export default AdminProtectedRoute;
