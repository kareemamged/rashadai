import React from 'react';
import { Navigate } from 'react-router-dom';
import {
  Users,
  MessageSquare,
  Star,
  FileText,
  Flag,
  BarChart2,
  TrendingUp,
  Calendar
} from 'lucide-react';
import { useAdminStore } from '../../store/adminStore';
import AdminLayout from './AdminLayout';

const Dashboard = () => {
  const { admin, isAuthenticated } = useAdminStore();
  
  if (!isAuthenticated || !admin) {
    return <Navigate to="/admin/login" replace />;
  }

  // Sample data for the dashboard
  const stats = [
    { title: 'Total Users', value: '1,234', icon: <Users className="h-8 w-8 text-blue-500" />, change: '+12%' },
    { title: 'Active Consultations', value: '56', icon: <MessageSquare className="h-8 w-8 text-green-500" />, change: '+5%' },
    { title: 'Pending Reports', value: '8', icon: <Flag className="h-8 w-8 text-yellow-500" />, change: '-3%' },
    { title: 'Blog Posts', value: '42', icon: <FileText className="h-8 w-8 text-purple-500" />, change: '+7%' }
  ];

  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-2">Welcome, {admin.name}</h1>
        <p className="text-gray-600">Here's what's happening with your medical consultation platform today.</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 dark:text-gray-400 text-sm font-medium">{stat.title}</p>
                <h3 className="text-3xl font-bold mt-1">{stat.value}</h3>
                <div className="flex items-center mt-2">
                  <span className={`text-sm font-medium ${stat.change.startsWith('+') ? 'text-green-500' : 'text-red-500'}`}>
                    {stat.change}
                  </span>
                  <span className="text-gray-500 dark:text-gray-400 text-sm ml-1">from last month</span>
                </div>
              </div>
              <div className="p-3 rounded-full bg-gray-100 dark:bg-gray-700">
                {stat.icon}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts and Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Chart */}
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">User Activity</h2>
            <div className="flex items-center">
              <span className="h-3 w-3 bg-blue-500 rounded-full mr-1"></span>
              <span className="text-sm text-gray-500 dark:text-gray-400 mr-4">New Users</span>
              <span className="h-3 w-3 bg-green-500 rounded-full mr-1"></span>
              <span className="text-sm text-gray-500 dark:text-gray-400">Active Users</span>
            </div>
          </div>
          <div className="h-64 flex items-center justify-center">
            <BarChart2 className="h-48 w-48 text-gray-300 dark:text-gray-600" />
            <p className="text-gray-500 dark:text-gray-400 absolute">Chart visualization will appear here</p>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
          <h2 className="text-lg font-semibold mb-4">Recent Activity</h2>
          <div className="space-y-4">
            {[1, 2, 3, 4].map((item) => (
              <div key={item} className="flex items-start">
                <div className="h-10 w-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center mr-3">
                  <Users className="h-5 w-5 text-gray-500 dark:text-gray-400" />
                </div>
                <div>
                  <p className="font-medium">New user registered</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">2 hours ago</p>
                </div>
              </div>
            ))}
          </div>
          <button className="mt-4 text-blue-600 dark:text-blue-400 text-sm font-medium hover:underline">
            View all activity
          </button>
        </div>
      </div>

      {/* Upcoming Consultations */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Upcoming Consultations</h2>
          <button className="text-blue-600 dark:text-blue-400 text-sm font-medium hover:underline flex items-center">
            <Calendar className="h-4 w-4 mr-1" />
            View Calendar
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead>
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Patient</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Doctor</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Date & Time</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
              {[1, 2, 3, 4].map((item) => (
                <tr key={item}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="h-8 w-8 rounded-full bg-gray-200 dark:bg-gray-700 mr-3"></div>
                      <div>
                        <p className="font-medium">John Doe</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">john.doe@example.com</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <p className="font-medium">Dr. Sarah Smith</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Cardiology</p>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <p className="font-medium">May 15, 2025</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">10:30 AM</p>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">
                      Confirmed
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AdminLayout>
  );
};

export default Dashboard;
