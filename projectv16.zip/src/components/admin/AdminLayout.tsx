import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAdminStore } from '../../store/adminStore';
import {
  Activity,
  LayoutDashboard,
  Users,
  MessageSquare,
  Star,
  Settings,
  FileText,
  Bell,
  Flag,
  LogOut,
  Moon,
  Sun,
  User,
  BarChart2,
  Menu,
  X
} from 'lucide-react';

interface AdminLayoutProps {
  children: React.ReactNode;
}

const AdminLayout: React.FC<AdminLayoutProps> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  const { admin, adminLogout } = useAdminStore();
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = async () => {
    try {
      await adminLogout();
      navigate('/admin/login');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle('dark');
  };

  const menuItems = [
    { path: '/admin/dashboard', name: 'Dashboard', icon: <LayoutDashboard className="h-5 w-5" /> },
    { path: '/admin/users', name: 'Users', icon: <Users className="h-5 w-5" /> },
    { path: '/admin/consultations', name: 'Consultations', icon: <MessageSquare className="h-5 w-5" /> },
    { path: '/admin/doctors', name: 'Doctors', icon: <User className="h-5 w-5" /> },
    { path: '/admin/statistics', name: 'Statistics', icon: <BarChart2 className="h-5 w-5" /> },
    { path: '/admin/blog', name: 'Blog', icon: <FileText className="h-5 w-5" /> },
    { path: '/admin/messages', name: 'Messages', icon: <MessageSquare className="h-5 w-5" /> },
    { path: '/admin/reports', name: 'Reports', icon: <Flag className="h-5 w-5" /> },
    { path: '/admin/notifications', name: 'Notifications', icon: <Bell className="h-5 w-5" /> },
    { path: '/admin/testimonials', name: 'Testimonials', icon: <Star className="h-5 w-5" /> },
    { path: '/admin/settings', name: 'Settings', icon: <Settings className="h-5 w-5" /> },
  ];

  return (
    <div className={`min-h-screen ${darkMode ? 'dark bg-gray-900 text-white' : 'bg-gray-100'}`}>
      {/* Mobile sidebar toggle */}
      <div className="lg:hidden fixed top-4 left-4 z-50">
        <button
          onClick={toggleSidebar}
          className={`p-2 rounded-md ${darkMode ? 'bg-gray-800 text-white' : 'bg-white text-gray-800'} shadow-md`}
        >
          {sidebarOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-40 w-64 transition-transform duration-300 transform ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        } lg:translate-x-0 ${darkMode ? 'bg-gray-800' : 'bg-white'} shadow-lg`}
      >
        <div className={`p-4 flex items-center ${darkMode ? 'border-gray-700' : 'border-gray-200'} border-b`}>
          <Activity className={`h-8 w-8 ${darkMode ? 'text-blue-400' : 'text-blue-600'} mr-2`} />
          <span className="text-xl font-bold">Admin Dashboard</span>
        </div>

        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold mr-3">
              {admin?.name?.charAt(0).toUpperCase() || 'A'}
            </div>
            <div>
              <p className="font-medium">{admin?.name || 'Admin'}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">{admin?.role || 'Administrator'}</p>
            </div>
          </div>
        </div>

        <nav className="mt-4 px-2">
          {menuItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center px-4 py-3 my-1 rounded-lg ${
                location.pathname === item.path
                  ? (darkMode ? 'bg-blue-900 text-white' : 'bg-blue-50 text-blue-600')
                  : (darkMode ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-100')
              } transition-colors duration-200`}
            >
              {item.icon}
              <span className="ml-3">{item.name}</span>
            </Link>
          ))}

          <button
            onClick={handleLogout}
            className={`flex items-center w-full px-4 py-3 my-1 rounded-lg ${
              darkMode ? 'text-gray-300 hover:bg-red-700' : 'text-gray-700 hover:bg-red-50 hover:text-red-600'
            } transition-colors duration-200`}
          >
            <LogOut className="h-5 w-5" />
            <span className="ml-3">Logout</span>
          </button>
        </nav>
      </div>

      {/* Main Content */}
      <div className={`${sidebarOpen ? 'lg:ml-64' : ''} transition-all duration-300`}>
        {/* Top Navigation */}
        <header className={`${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} border-b shadow-sm`}>
          <div className="flex items-center justify-between px-4 py-3">
            <h1 className="text-xl font-semibold">
              {menuItems.find(item => item.path === location.pathname)?.name || 'Dashboard'}
            </h1>
            <div className="flex items-center space-x-4">
              <button
                onClick={toggleDarkMode}
                className={`p-2 rounded-full ${darkMode ? 'bg-gray-700 text-yellow-300' : 'bg-gray-100 text-gray-700'}`}
              >
                {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </button>
              <button className="relative p-2">
                <Bell className={`h-5 w-5 ${darkMode ? 'text-gray-300' : 'text-gray-600'}`} />
                <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-red-500"></span>
              </button>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="p-6">
          {children}
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
