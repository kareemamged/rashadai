# Medical Consultation Platform - Admin Dashboard

This project is a comprehensive medical consultation platform with an AI-powered chat system and a professional admin dashboard.

## Features

- User authentication with Supabase
- Separate admin authentication system
- Responsive admin dashboard with dark mode
- User management
- Blog management
- Consultation management
- Doctor management
- Reports system
- Statistics and analytics
- Content management
- Testimonials management
- System settings

## Technologies Used

- React
- TypeScript
- Tailwind CSS
- Zustand for state management
- Supabase for authentication and database
- React Router for navigation
- Lucide React for icons

## Setup Instructions

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn
- Supabase account

### Installation

1. Clone the repository
2. Install dependencies:
   ```
   npm install
   ```
3. Create a `.env` file with your Supabase credentials:
   ```
   VITE_SUPABASE_URL=your_supabase_url
   VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
   ```

### Database Setup

1. Run the SQL script in `supabase/migrations/create_admin_tables.sql` in your Supabase SQL editor to create the necessary tables and policies.

2. Create an admin user:
   - Register a regular user through the application
   - In the Supabase SQL editor, run:
     ```sql
     INSERT INTO admin_users (id, name, email, role, permissions)
     VALUES ('user_id_from_auth_users', 'Admin Name', 'admin_email', 'super_admin', ARRAY['all']);
     ```
   - Replace `user_id_from_auth_users` with the actual user ID from the auth.users table
   - Replace `Admin Name` and `admin_email` with the appropriate values

### Running the Application

```
npm run dev
```

The application will be available at http://localhost:5173

## Admin Dashboard Access

- Navigate to `/admin/login`
- Log in with the admin credentials you created
- You will be redirected to the admin dashboard

## Admin Dashboard Sections

1. **Dashboard** - Overview of key metrics and recent activity
2. **Users** - Manage user accounts, permissions, and notifications
3. **Consultations** - View and manage medical consultations
4. **Doctors** - Manage doctor profiles and availability
5. **Blog** - Create, edit, and publish blog posts and manage comments
6. **Reports** - Handle user reports and issues
7. **Settings** - Configure system settings and preferences

## Development Guidelines

- Use the existing component structure and styling patterns
- Follow the established naming conventions
- Add proper TypeScript types for all components and functions
- Use Zustand stores for state management
- Implement proper error handling and loading states
- Test all features thoroughly before deployment

## Deployment

1. Build the application:
   ```
   npm run build
   ```

2. Deploy the `dist` folder to your hosting provider of choice (Vercel, Netlify, etc.)

## License

This project is proprietary and confidential. Unauthorized copying, distribution, or use is strictly prohibited.
