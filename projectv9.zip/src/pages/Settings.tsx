import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Loader2, Shield, Bell, Moon, LogOut } from 'lucide-react';
import { useAuthStore } from '../store/authStore';

const Settings = () => {
  const navigate = useNavigate();
  const { user, isLoading, signOut } = useAuthStore();
  
  const [settings, setSettings] = useState({
    darkMode: false,
    notifications: true,
    language: 'ar',
    privacy: {
      shareData: false
    }
  });
  
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState({ text: '', type: '' });
  
  useEffect(() => {
    if (!isLoading && !user) {
      navigate('/login');
    }
    
    // هنا يمكن استرجاع الإعدادات من التخزين المحلي أو من قاعدة البيانات
    const savedSettings = localStorage.getItem('userSettings');
    if (savedSettings) {
      try {
        setSettings(JSON.parse(savedSettings));
      } catch (error) {
        console.error('Error parsing saved settings:', error);
      }
    }
  }, [user, isLoading, navigate]);
  
  const handleToggle = (key: string, nestedKey?: string) => {
    setSettings(prev => {
      if (nestedKey) {
        return {
          ...prev,
          [key]: {
            ...prev[key as keyof typeof prev],
            [nestedKey]: !prev[key as keyof typeof prev][nestedKey]
          }
        };
      }
      return {
        ...prev,
        [key]: !prev[key as keyof typeof prev]
      };
    });
  };
  
  const handleLanguageChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSettings(prev => ({
      ...prev,
      language: e.target.value
    }));
  };
  
  const saveSettings = async () => {
    setIsSaving(true);
    setMessage({ text: '', type: '' });
    
    try {
      // حفظ الإعدادات في التخزين المحلي
      localStorage.setItem('userSettings', JSON.stringify(settings));
      
      // هنا يمكن إضافة كود لحفظ الإعدادات في قاعدة البيانات
      
      setMessage({
        text: 'تم حفظ الإعدادات بنجاح',
        type: 'success'
      });
      
      // تطبيق الإعدادات (مثل الوضع الداكن)
      if (settings.darkMode) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    } catch (error) {
      setMessage({
        text: 'حدث خطأ أثناء حفظ الإعدادات',
        type: 'error'
      });
    } finally {
      setIsSaving(false);
    }
  };
  
  const handleSignOut = async () => {
    try {
      await signOut();
      navigate('/login');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 text-blue-600 animate-spin" />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm py-4 px-6">
        <div className="container mx-auto flex items-center">
          <button 
            onClick={() => navigate('/chat')}
            className="mr-4 text-gray-500 hover:text-gray-700"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <h1 className="text-xl font-semibold text-gray-800">الإعدادات</h1>
        </div>
      </header>
      
      <main className="container mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto">
          {message.text && (
            <div 
              className={`mb-6 p-4 rounded-md ${
                message.type === 'error' 
                  ? 'bg-red-50 text-red-700 border border-red-200' 
                  : 'bg-green-50 text-green-700 border border-green-200'
              }`}
            >
              {message.text}
            </div>
          )}
          
          <div className="bg-white rounded-lg shadow overflow-hidden mb-6">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-lg font-medium text-gray-900 mb-4">المظهر</h2>
              
              <div className="flex items-center justify-between py-3">
                <div className="flex items-center">
                  <Moon className="h-5 w-5 text-gray-500 mr-3" />
                  <span className="text-gray-700">الوضع الداكن</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    className="sr-only peer" 
                    checked={settings.darkMode}
                    onChange={() => handleToggle('darkMode')}
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>
            </div>
            
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-lg font-medium text-gray-900 mb-4">اللغة والإشعارات</h2>
              
              <div className="mb-4">
                <label htmlFor="language" className="block text-sm font-medium text-gray-700 mb-1">
                  اللغة
                </label>
                <select
                  id="language"
                  value={settings.language}
                  onChange={handleLanguageChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="ar">العربية</option>
                  <option value="en">English</option>
                </select>
              </div>
              
              <div className="flex items-center justify-between py-3">
                <div className="flex items-center">
                  <Bell className="h-5 w-5 text-gray-500 mr-3" />
                  <span className="text-gray-700">الإشعارات</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    className="sr-only peer" 
                    checked={settings.notifications}
                    onChange={() => handleToggle('notifications')}
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>
            </div>
            
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-lg font-medium text-gray-900 mb-4">الخصوصية والأمان</h2>
              
              <div className="flex items-center justify-between py-3">
                <div className="flex items-center">
                  <Shield className="h-5 w-5 text-gray-500 mr-3" />
                  <div>
                    <span className="text-gray-700 block">مشاركة البيانات للتحسين</span>
                    <span className="text-xs text-gray-500">مشاركة بيانات الاستخدام المجهولة لتحسين الخدمة</span>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    className="sr-only peer" 
                    checked={settings.privacy.shareData}
                    onChange={() => handleToggle('privacy', 'shareData')}
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>
            </div>
            
            <div className="p-6">
              <button
                onClick={handleSignOut}
                className="flex items-center text-red-600 hover:text-red-800"
              >
                <LogOut className="h-5 w-5 mr-2" />
                تسجيل الخروج
              </button>
            </div>
          </div>
          
          <div className="flex justify-end">
            <button
              onClick={saveSettings}
              disabled={isSaving}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 flex items-center"
            >
              {isSaving ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  جاري الحفظ...
                </>
              ) : (
                'حفظ الإعدادات'
              )}
            </button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Settings;
