import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Camera, Loader2, ArrowLeft } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { supabase } from '../lib/supabase';

const Profile = () => {
  const navigate = useNavigate();
  const { user, isLoading, updateProfile } = useAuthStore();
  
  const [fullName, setFullName] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState({ text: '', type: '' });
  
  useEffect(() => {
    if (!isLoading && !user) {
      navigate('/login');
      return;
    }
    
    if (user) {
      setFullName(user.full_name || '');
      setAvatarUrl(user.avatar_url || '');
    }
  }, [user, isLoading, navigate]);
  
  const uploadAvatar = async (event: React.ChangeEvent<HTMLInputElement>) => {
    try {
      setUploading(true);
      setMessage({ text: '', type: '' });
      
      // التحقق من وجود المستخدم وأنه مسجل الدخول
      if (!user || !user.id) {
        throw new Error('يجب تسجيل الدخول لرفع صورة الملف الشخصي');
      }
      
      if (!event.target.files || event.target.files.length === 0) {
        return;
      }
      
      const file = event.target.files[0];
      const fileExt = file.name.split('.').pop();
      const fileName = `${user.id}-${Date.now()}.${fileExt}`;
      
      // التأكد من تحديث جلسة المستخدم قبل الرفع
      const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
      
      if (sessionError || !sessionData.session) {
        throw new Error('جلسة المستخدم غير صالحة. يرجى تسجيل الدخول مرة أخرى.');
      }
      
      // رفع الملف مع تحديد المستخدم الحالي
      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(fileName, file, {
          contentType: file.type,
          upsert: false
        });
        
      if (uploadError) {
        console.error('Upload error details:', uploadError);
        
        // إذا كانت المشكلة متعلقة بسياسات RLS، حاول استخدام طريقة بديلة
        if (uploadError.message.includes('row-level security policy')) {
          throw new Error('ليس لديك صلاحية لرفع الملفات. يرجى التواصل مع مسؤول النظام.');
        }
        
        throw uploadError;
      }
      
      // الحصول على URL العام
      const { data: urlData } = supabase.storage
        .from('avatars')
        .getPublicUrl(fileName);
      
      if (!urlData || !urlData.publicUrl) {
        throw new Error('فشل في الحصول على رابط الصورة');
      }
      
      // تعيين URL الصورة
      setAvatarUrl(urlData.publicUrl);
      
      // تحديث الملف الشخصي
      await updateProfile({
        avatar_url: urlData.publicUrl
      });
      
      setMessage({
        text: 'تم تحديث صورة الملف الشخصي بنجاح',
        type: 'success'
      });
      
    } catch (error: any) {
      console.error('Error uploading avatar:', error);
      setMessage({ 
        text: error.message || 'حدث خطأ أثناء رفع الصورة', 
        type: 'error' 
      });
    } finally {
      setUploading(false);
    }
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      setSaving(true);
      setMessage({ text: '', type: '' });
      
      await updateProfile({
        full_name: fullName,
        avatar_url: avatarUrl
      });
      
      setMessage({ 
        text: 'تم تحديث الملف الشخصي بنجاح', 
        type: 'success' 
      });
    } catch (error: any) {
      setMessage({ 
        text: error.message || 'حدث خطأ أثناء حفظ التغييرات', 
        type: 'error' 
      });
    } finally {
      setSaving(false);
    }
  };
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 text-blue-600 animate-spin" />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm py-4 px-6">
        <div className="container mx-auto flex items-center">
          <button 
            onClick={() => navigate('/chat')}
            className="mr-4 text-gray-500 hover:text-gray-700"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <h1 className="text-xl font-semibold text-gray-800">الملف الشخصي</h1>
        </div>
      </header>
      
      <main className="container mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto bg-white rounded-lg shadow p-6 sm:p-8">
          {message.text && (
            <div 
              className={`mb-6 p-4 rounded-md ${
                message.type === 'error' 
                  ? 'bg-red-50 text-red-700 border border-red-200' 
                  : 'bg-green-50 text-green-700 border border-green-200'
              }`}
            >
              {message.text}
            </div>
          )}
          
          <div className="flex flex-col items-center mb-8">
            <div className="relative mb-4">
              {avatarUrl ? (
                <img 
                  src={avatarUrl} 
                  alt="Avatar" 
                  className="h-24 w-24 rounded-full object-cover border-2 border-gray-200"
                />
              ) : (
                <div className="h-24 w-24 rounded-full bg-gray-200 flex items-center justify-center">
                  <User className="h-12 w-12 text-gray-400" />
                </div>
              )}
              
              <label 
                htmlFor="avatar-upload" 
                className="absolute bottom-0 right-0 bg-blue-600 text-white p-2 rounded-full cursor-pointer hover:bg-blue-700"
              >
                <Camera className="h-4 w-4" />
                <input
                  id="avatar-upload"
                  type="file"
                  accept="image/*"
                  onChange={uploadAvatar}
                  className="hidden"
                  disabled={uploading}
                />
              </label>
            </div>
            
            {uploading && (
              <div className="text-sm text-gray-500 flex items-center">
                <Loader2 className="h-3 w-3 animate-spin mr-2" />
                جاري رفع الصورة...
              </div>
            )}
          </div>
          
          <form onSubmit={handleSubmit}>
            <div className="mb-6">
              <label htmlFor="fullName" className="block text-sm font-medium text-gray-700 mb-1">
                الاسم الكامل
              </label>
              <input
                id="fullName"
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            
            <div className="mb-6">
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                البريد الإلكتروني
              </label>
              <input
                id="email"
                type="email"
                value={user?.email || ''}
                disabled
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm bg-gray-50 text-gray-500"
              />
              <p className="mt-1 text-xs text-gray-500">
                لا يمكن تغيير البريد الإلكتروني
              </p>
            </div>
            
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={saving}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 flex items-center"
              >
                {saving ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    جاري الحفظ...
                  </>
                ) : (
                  'حفظ التغييرات'
                )}
              </button>
            </div>
          </form>
        </div>
      </main>
    </div>
  );
};

export default Profile;



