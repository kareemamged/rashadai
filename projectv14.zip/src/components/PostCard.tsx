import React from 'react';
import { Link } from 'react-router-dom';
import { Post } from '../types';
import { formatDate } from '../utils/dateFormatter';
import { FileText, MessageSquare, Calendar } from 'lucide-react';

interface PostCardProps {
  post: Post;
}

const PostCard: React.FC<PostCardProps> = ({ post }) => {
  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300">
      {post.imageUrl && (
        <div className="h-48 overflow-hidden">
          <img
            src={post.imageUrl}
            alt={post.title}
            className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
          />
        </div>
      )}
      <div className="p-6">
        <div className="flex items-center mb-3">
          <span className={`text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full ${
            post.category === 'news' ? 'bg-blue-100 text-blue-800' : 'bg-teal-100 text-teal-800'
          }`}>
            {post.category === 'news' ? 'NEWS' : 'TIP'}
          </span>
          <div className="flex items-center text-gray-500 text-sm">
            <Calendar className="h-4 w-4 mr-1" />
            <span>{formatDate(post.publishedDate)}</span>
          </div>
        </div>
        <h3 className="text-xl font-bold mb-2 text-gray-800">{post.title}</h3>
        <p className="text-gray-600 mb-4 line-clamp-3">{post.summary}</p>
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            {post.author.avatarUrl ? (
              <img
                src={post.author.avatarUrl}
                alt={post.author.name}
                className="w-8 h-8 rounded-full mr-2 object-cover"
              />
            ) : (
              <div className="w-8 h-8 rounded-full bg-gray-200 mr-2 flex items-center justify-center">
                {post.author.name.charAt(0)}
              </div>
            )}
            <span className="text-sm text-gray-600">{post.author.name}</span>
          </div>
          <Link
            to={`/post/${post.id}`}
            className="flex items-center text-blue-600 hover:text-blue-800 text-sm font-medium"
          >
            Read more <FileText className="ml-1 h-4 w-4" />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default PostCard;