import React from 'react';
import { Comment } from '../types';
import { timeAgo } from '../utils/dateFormatter';

interface CommentItemProps {
  comment: Comment;
}

const CommentItem: React.FC<CommentItemProps> = ({ comment }) => {
  const initials = comment.author
    .split(' ')
    .map(name => name[0])
    .join('')
    .toUpperCase();

  return (
    <div className="flex space-x-4 mb-6 animate-fadeIn">
      <div className="flex-shrink-0 w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-semibold">
        {initials}
      </div>
      <div className="flex-1">
        <div className="bg-gray-50 p-4 rounded-lg">
          <div className="flex justify-between items-center mb-2">
            <h4 className="font-medium text-gray-800">{comment.author}</h4>
            <span className="text-xs text-gray-500">{timeAgo(comment.createdAt)}</span>
          </div>
          <p className="text-gray-700">{comment.content}</p>
        </div>
      </div>
    </div>
  );
};

export default CommentItem;