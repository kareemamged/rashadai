import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { FileText, Brain, Activity } from 'lucide-react';

const BlogHeader: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  return (
    <header className={`py-4 transition-all duration-300 sticky top-0 z-10 ${
      scrolled ? 'bg-white shadow-md' : 'bg-white/80 backdrop-blur-md'
    }`}>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
        <Link to="/" className="flex items-center">
            <Activity className="h-8 w-8 text-blue-600 mr-2" />
            <span className="text-xl font-bold text-blue-700">RashadAI</span>
          </Link>
          
          <nav className="hidden md:flex items-center space-x-8">
            <Link 
              to="/blog" 
              className={`transition-colors ${
                location.pathname === '/blog' ? 'text-blue-600 font-medium' : 'text-gray-600 hover:text-blue-600'
              }`}
            >
              All Posts
            </Link>
            <Link 
              to="/blog/category/news" 
              className={`transition-colors ${
                location.pathname === '/blog/category/news' ? 'text-blue-600 font-medium' : 'text-gray-600 hover:text-blue-600'
              }`}
            >
              News
            </Link>
            <Link 
              to="/blog/category/tips" 
              className={`transition-colors ${
                location.pathname === '/blog/category/tips' ? 'text-blue-600 font-medium' : 'text-gray-600 hover:text-blue-600'
              }`}
            >
              Tips
            </Link>
          </nav>
          
          <Link to="/" className="flex items-center text-gray-600 hover:text-blue-600">
            <span className="mr-1">Back to Main</span>
            <FileText className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </header>
  );
};

export default BlogHeader;