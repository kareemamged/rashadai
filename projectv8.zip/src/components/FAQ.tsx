import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const FAQ = () => {
  const faqs = [
    {
      question: "How accurate is the AI medical consultation?",
      answer: "Our AI system has demonstrated 85-90% accuracy in preliminary diagnoses, comparable to junior physicians. However, it's designed to complement rather than replace professional medical care. For serious conditions, we always recommend following up with a healthcare provider."
    },
    {
      question: "Is my medical data secure?",
      answer: "Absolutely. We employ HIPAA-compliant security measures, including end-to-end encryption and secure data storage. Your information is never sold to third parties, and you control who has access to your medical records."
    },
    {
      question: "How much does the service cost?",
      answer: "We offer several pricing tiers, starting with a free basic consultation. Premium plans start at $9.99/month for unlimited consultations and additional features like specialist referrals and prescription assistance."
    },
    {
      question: "Can the AI service prescribe medication?",
      answer: "The AI cannot directly prescribe medication. However, for premium members, we can connect you with licensed physicians who can review the AI's assessment and issue prescriptions when appropriate."
    },
    {
      question: "What medical conditions can the AI help with?",
      answer: "Our AI is trained to recognize thousands of conditions, from common ailments like cold, flu, and allergies to more complex issues such as diabetes management and mental health conditions. It's particularly effective for initial screenings and chronic condition management."
    },
    {
      question: "How is the service different from just searching symptoms online?",
      answer: "Unlike generic search results, our AI creates a personalized assessment based on your specific medical history, symptoms, and risk factors. It uses validated medical protocols and is continually updated with the latest research."
    }
  ];

  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggleFaq = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Find answers to common questions about our AI medical consultation service.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          {faqs.map((faq, index) => (
            <div 
              key={index} 
              className="mb-4 border border-gray-200 rounded-lg overflow-hidden"
            >
              <button
                className="w-full flex justify-between items-center p-5 bg-white hover:bg-gray-50 focus:outline-none"
                onClick={() => toggleFaq(index)}
              >
                <span className="font-medium text-left text-gray-800">{faq.question}</span>
                {openIndex === index ? (
                  <ChevronUp className="h-5 w-5 text-blue-600" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-blue-600" />
                )}
              </button>
              <div 
                className={`px-5 transition-all duration-300 ease-in-out ${
                  openIndex === index ? 'max-h-96 pb-5 opacity-100' : 'max-h-0 overflow-hidden opacity-0'
                }`}
              >
                <p className="text-gray-600">{faq.answer}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;