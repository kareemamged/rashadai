import { create } from 'zustand';

interface User {
  id: string;
  email: string;
  created_at: string;
}

interface AuthState {
  user: User | null;
  isLoading: boolean;
  signUp: (email: string, password: string) => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  checkAuth: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  isLoading: false,

  signUp: async (email: string, password: string) => {
    // Mock signup functionality
    const mockUser = {
      id: '123',
      email,
      created_at: new Date().toISOString()
    };
    set({ user: mockUser });
  },

  signIn: async (email: string, password: string) => {
    // Mock signin functionality
    const mockUser = {
      id: '123',
      email,
      created_at: new Date().toISOString()
    };
    set({ user: mockUser });
  },

  signOut: async () => {
    set({ user: null });
  },

  checkAuth: async () => {
    set({ isLoading: false });
  }
}));