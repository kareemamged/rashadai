import React from 'react';
import Layout from '../../components/Layout';

const HIPAACompliance = () => {
  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-4xl font-bold text-gray-900 mb-8">HIPAA Compliance</h1>
            
            <div className="bg-white rounded-xl shadow-lg p-8 space-y-8">
              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Our Commitment to HIPAA Compliance</h2>
                <p className="text-gray-700 leading-relaxed">
                  MedAI is committed to protecting your health information and maintaining compliance with the Health Insurance Portability and Accountability Act (HIPAA) of 1996. We implement strict privacy and security measures to safeguard your Protected Health Information (PHI).
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Security Measures</h2>
                <ul className="list-disc pl-6 space-y-2 text-gray-700">
                  <li>End-to-end encryption for all data transmission</li>
                  <li>Secure data storage in HIPAA-compliant facilities</li>
                  <li>Regular security audits and assessments</li>
                  <li>Access controls and authentication protocols</li>
                  <li>Employee training on HIPAA compliance</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Your Rights Under HIPAA</h2>
                <ul className="list-disc pl-6 space-y-2 text-gray-700">
                  <li>Right to access your health information</li>
                  <li>Right to request corrections to your health information</li>
                  <li>Right to receive a notice of privacy practices</li>
                  <li>Right to file complaints about privacy violations</li>
                  <li>Right to request restrictions on information sharing</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Data Protection</h2>
                <p className="text-gray-700 leading-relaxed">
                  We employ industry-standard security measures to protect your health information:
                </p>
                <ul className="list-disc pl-6 mt-4 space-y-2 text-gray-700">
                  <li>Physical safeguards for our servers and facilities</li>
                  <li>Technical safeguards including encryption and firewalls</li>
                  <li>Administrative safeguards such as access policies</li>
                  <li>Regular staff training on privacy and security</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Contact Information</h2>
                <p className="text-gray-700 leading-relaxed">
                  For questions about our HIPAA compliance or to report a concern:
                </p>
                <div className="mt-4 text-gray-700">
                  <p>Privacy Officer: John Smith</p>
                  <p>Email: privacy@medai.com</p>
                  <p>Phone: (555) 123-4567</p>
                </div>
              </section>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default HIPAACompliance;