import React, { useState, useEffect } from 'react';
import { Activity } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';
import { supabase } from '../../lib/supabase';
import { useTranslation } from 'react-i18next';

const AdminPanel = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const location = useLocation();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { user } = useAuthStore();

  // If user is already authenticated, check if they are an admin
  useEffect(() => {
    if (user) {
      // Check if user is an admin
      const checkAdminStatus = async () => {
        try {
          const { data, error } = await supabase
            .from('admin_users')
            .select('*')
            .eq('id', user.id)
            .single();

          if (error) {
            console.error('Error checking admin status:', error);
            // If there's an error or no admin record found, this is not an admin user
            // We don't sign them out here to avoid loops, just show the admin login form
            return;
          }

          if (data) {
            setIsAuthenticated(true);
            // Redirect to the intended page or dashboard
            const from = location.state?.from?.pathname || '/admin/dashboard';
            navigate(from);
          }
        } catch (error) {
          console.error('Error checking admin status:', error);
        }
      };

      checkAdminStatus();
    }
  }, [user, navigate, location]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      // Sign in with Supabase
      const { data, error } = await supabase.auth.signInWithPassword({
        email: username,
        password: password,
      });

      if (error) {
        setError(error.message);
        setIsLoading(false);
        return;
      }

      if (data.user) {
        // Check if user is an admin
        const { data: adminData, error: adminError } = await supabase
          .from('admin_users')
          .select('*')
          .eq('id', data.user.id)
          .single();

        if (adminError) {
          // If no admin record found, this is not an admin user
          await supabase.auth.signOut();
          setError(t('admin.notAuthorized', 'Not authorized as admin'));
          setIsLoading(false);
          return;
        }

        setIsAuthenticated(true);
        navigate('/admin/dashboard');
      }
    } catch (error: any) {
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  if (isAuthenticated) {
    return <div>Redirecting to dashboard...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8">
        <div className="flex items-center justify-center mb-8">
          <Activity className="h-10 w-10 text-blue-600 mr-2" />
          <span className="text-2xl font-bold text-gray-900">RashadAI Admin</span>
        </div>

        {error && (
          <div className="bg-red-50 text-red-600 p-3 rounded-lg mb-4">
            {error}
          </div>
        )}

        <form onSubmit={handleLogin}>
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2">
              {t('login.email', 'Email')}
            </label>
            <input
              type="email"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <div className="mb-6">
            <label className="block text-gray-700 text-sm font-bold mb-2">
              {t('login.password', 'Password')}
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition duration-200 disabled:bg-blue-400"
          >
            {isLoading ? t('common.loading', 'Loading...') : t('login.signIn', 'Sign In')}
          </button>
        </form>
      </div>
    </div>
  );
};

export default AdminPanel;