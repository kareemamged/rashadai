import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useLanguageStore } from '../../store/languageStore';
import { useAuthStore } from '../../store/authStore';
import {
  FileText,
  MessageSquare,
  Star,
  Plus,
  Search,
  Filter,
  Edit,
  Trash2,
  Eye,
  CheckCircle,
  XCircle,
  AlertCircle,
  Tag
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import BlogPostForm from './BlogPostForm';

// Define types for blog posts
interface Post {
  id: string;
  title_en: string;
  title_ar: string;
  content_en: string;
  content_ar: string;
  category: string;
  published: boolean;
  author_id: string;
  author_name?: string;
  created_at: string;
  updated_at: string;
  image_url?: string;
  likes_count?: number;
  dislikes_count?: number;
}

// Define types for comments
interface Comment {
  id: string;
  post_id: string;
  user_id?: string;
  content: string;
  approved: boolean;
  created_at: string;
  updated_at?: string;
  likes_count?: number;
  dislikes_count?: number;
  user_name?: string;
}

// Define types for testimonials
interface Testimonial {
  id: string;
  user_name: string;
  content: string;
  rating: number;
  approved: boolean;
  created_at: string;
  updated_at?: string;
  user_id?: string;
}

const ContentManagement: React.FC = () => {
  const { t } = useTranslation();
  const { language } = useLanguageStore();
  const user = useAuthStore((state) => state.user);
  const [activeTab, setActiveTab] = useState<'blog' | 'comments' | 'testimonials'>('blog');
  const [isRTL, setIsRTL] = useState(language === 'ar');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [showPostForm, setShowPostForm] = useState(false);
  const [editingPostId, setEditingPostId] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Blog posts state
  const [posts, setPosts] = useState<Post[]>([]);
  const [isLoadingPosts, setIsLoadingPosts] = useState(false);

  // Comments state
  const [comments, setComments] = useState<Comment[]>([]);
  const [isLoadingComments, setIsLoadingComments] = useState(false);

  // Testimonials state
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [isLoadingTestimonials, setIsLoadingTestimonials] = useState(false);

  useEffect(() => {
    setIsRTL(language === 'ar');
  }, [language]);

  // Fetch blog posts
  useEffect(() => {
    const fetchPosts = async () => {
      setIsLoadingPosts(true);
      try {
        // Check if the blog_posts table exists
        const { error: checkError } = await supabase
          .from('blog_posts')
          .select('id')
          .limit(1);

        if (checkError) {
          console.warn('Error checking blog_posts table:', checkError.message);

          if (checkError.message.includes('does not exist')) {
            console.warn('blog_posts table does not exist');

            // Create the blog_posts table
            try {
              // Read the SQL file content
              const response = await fetch('/supabase/blog_posts_table.sql');
              const sqlContent = await response.text();

              // Execute the SQL (this would require admin privileges)
              // In a real app, this would be done through a server endpoint
              console.log('Would execute SQL to create blog_posts table');

              // For now, we'll just create sample posts directly
              await createSamplePosts();
            } catch (createError) {
              console.error('Error creating blog_posts table:', createError);
            }
          } else if (checkError.code === '42501' || checkError.message.includes('permission denied')) {
            console.error('Permission denied error. RLS policy might be blocking access.');
            setErrorMessage(t('admin.content.permissionDenied', 'Permission denied. Please check RLS policies.'));
          } else if (checkError.code === 'PGRST301' || checkError.message.includes('JWT')) {
            console.error('Authentication error. JWT might be invalid or expired.');
            setErrorMessage(t('admin.content.authError', 'Authentication error. Please log in again.'));
          } else {
            console.error('Unknown error checking blog_posts table:', checkError);
            setErrorMessage(t('admin.content.unknownError', 'Unknown error: ') + checkError.message);
          }

          setIsLoadingPosts(false);
          return;
        }

        // Fetch real posts from Supabase
        const { data, error } = await supabase
          .from('blog_posts')
          .select('*')
          .order('created_at', { ascending: false });

        // If we need author information, we'll fetch it separately
        if (!error && data && data.length > 0) {
          // Get unique author IDs
          const authorIds = [...new Set(data.map(post => post.author_id))].filter(Boolean);

          if (authorIds.length > 0) {
            // Fetch author profiles
            const { data: authorData } = await supabase
              .from('profiles')
              .select('id, name, email')
              .in('id', authorIds);

            // Create a map of author data
            const authorMap = {};
            if (authorData) {
              authorData.forEach(author => {
                authorMap[author.id] = author;
              });
            }

            // Add author information to posts
            data.forEach(post => {
              if (post.author_id && authorMap[post.author_id]) {
                // Instead of modifying the post object directly, we'll use this map later
                // when formatting the posts
                post.author_name = authorMap[post.author_id].name ||
                                  authorMap[post.author_id].email?.split('@')[0] ||
                                  'Unknown';
              }
            });
          }
        }

        if (error) throw error;

        if (data && data.length > 0) {
          // Transform data to match our Post interface
          const formattedPosts: Post[] = data.map(post => ({
            id: post.id,
            title_en: post.title_en || 'Untitled',
            title_ar: post.title_ar || 'بدون عنوان',
            content_en: post.content_en || '',
            content_ar: post.content_ar || '',
            category: post.category || 'tips',
            published: post.published || false,
            author_id: post.author_id || '',
            author_name: post.author_name || 'Unknown',
            created_at: post.created_at || new Date().toISOString(),
            updated_at: post.updated_at || new Date().toISOString(),
            image_url: post.image_url || '',
            likes_count: post.likes_count || 0,
            dislikes_count: post.dislikes_count || 0
          }));

          setPosts(formattedPosts);
        } else {
          // If no posts found, create sample data
          await createSamplePosts();
        }
      } catch (error) {
        console.error('Error fetching posts:', error);

        // More detailed error handling
        if (error.code === '42501' || (error.message && error.message.includes('permission denied'))) {
          console.error('Permission denied error. RLS policy might be blocking access.');
          setErrorMessage(t('admin.content.permissionDenied', 'Permission denied. Please check RLS policies.'));
        } else if (error.code === 'PGRST301' || (error.message && error.message.includes('JWT'))) {
          console.error('Authentication error. JWT might be invalid or expired.');
          setErrorMessage(t('admin.content.authError', 'Authentication error. Please log in again.'));
        } else {
          // Generic error message
          setErrorMessage(t('admin.content.errorFetchingPosts', 'Error fetching posts: ') +
                         (error.message || 'Unknown error'));
        }

        // Use empty array on error
        setPosts([]);
      } finally {
        setIsLoadingPosts(false);
      }
    };

    // Function to create sample posts
    const createSamplePosts = async () => {
      try {
        // Create sample blog posts with a fixed admin author ID instead of using user?.id
        // This avoids the need to access auth.users table which might be restricted
        const adminAuthorId = '00000000-0000-0000-0000-000000000000'; // Use a fixed ID for sample posts

        const samplePosts = [
          {
            title_en: 'Getting Started with AI Medical Consultations',
            title_ar: 'بدء الاستشارات الطبية بالذكاء الاصطناعي',
            content_en: 'AI medical consultations are revolutionizing healthcare by providing accessible medical advice. This guide will help you understand how to get the most out of your AI consultation experience.',
            content_ar: 'تُحدث الاستشارات الطبية بالذكاء الاصطناعي ثورة في الرعاية الصحية من خلال تقديم المشورة الطبية بشكل سهل الوصول. سيساعدك هذا الدليل على فهم كيفية الاستفادة القصوى من تجربة الاستشارة بالذكاء الاصطناعي.',
            category: 'tips',
            published: true,
            author_id: adminAuthorId, // Use fixed ID
            image_url: '/images/blog/ai-consultation.jpg'
          },
          {
            title_en: 'Understanding AI Diagnosis Limitations',
            title_ar: 'فهم قيود التشخيص بالذكاء الاصطناعي',
            content_en: 'While AI can provide valuable medical insights, it is important to understand its limitations. This article explains what AI can and cannot diagnose, and when you should seek traditional medical care.',
            content_ar: 'بينما يمكن للذكاء الاصطناعي تقديم رؤى طبية قيمة، من المهم فهم قيوده. يشرح هذا المقال ما يمكن للذكاء الاصطناعي تشخيصه وما لا يمكنه، ومتى يجب عليك طلب الرعاية الطبية التقليدية.',
            category: 'tips',
            published: false,
            author_id: adminAuthorId, // Use fixed ID
            image_url: '/images/blog/ai-limitations.jpg'
          },
          {
            title_en: 'New Features Coming to Our Platform',
            title_ar: 'ميزات جديدة قادمة إلى منصتنا',
            content_en: 'We are excited to announce several new features coming to our platform in the next update. These improvements will enhance your experience and provide more comprehensive healthcare options.',
            content_ar: 'يسعدنا أن نعلن عن العديد من الميزات الجديدة القادمة إلى منصتنا في التحديث القادم. ستعمل هذه التحسينات على تعزيز تجربتك وتوفير خيارات رعاية صحية أكثر شمولاً.',
            category: 'news',
            published: true,
            author_id: adminAuthorId, // Use fixed ID
            image_url: '/images/blog/new-features.jpg'
          }
        ];

        // Insert sample posts
        for (const post of samplePosts) {
          const { error: insertError } = await supabase.from('blog_posts').insert(post);
          if (insertError) {
            console.error('Error inserting sample post:', insertError);
            if (insertError.code === '42501' || insertError.message.includes('permission denied')) {
              setErrorMessage(t('admin.content.permissionDenied', 'Permission denied when creating sample posts. Please check RLS policies.'));
              break;
            }
          }
        }

        // Fetch the newly created posts
        const { data: newData } = await supabase
          .from('blog_posts')
          .select('*')
          .order('created_at', { ascending: false });

        // If we need author information, we'll fetch it separately
        if (newData && newData.length > 0) {
          // Get unique author IDs
          const authorIds = [...new Set(newData.map(post => post.author_id))].filter(Boolean);

          if (authorIds.length > 0) {
            // Fetch author profiles
            const { data: authorData } = await supabase
              .from('profiles')
              .select('id, name, email')
              .in('id', authorIds);

            // Create a map of author data
            const authorMap = {};
            if (authorData) {
              authorData.forEach(author => {
                authorMap[author.id] = author;
              });
            }

            // Add author information to posts
            newData.forEach(post => {
              if (post.author_id && authorMap[post.author_id]) {
                post.author_name = authorMap[post.author_id].name ||
                                  authorMap[post.author_id].email?.split('@')[0] ||
                                  'Unknown';
              }
            });
          }
        }

        if (newData && newData.length > 0) {
          const formattedPosts: Post[] = newData.map(post => ({
            id: post.id,
            title_en: post.title_en || 'Untitled',
            title_ar: post.title_ar || 'بدون عنوان',
            content_en: post.content_en || '',
            content_ar: post.content_ar || '',
            category: post.category || 'tips',
            published: post.published || false,
            author_id: post.author_id || '',
            author_name: post.author_name || 'Unknown',
            created_at: post.created_at || new Date().toISOString(),
            updated_at: post.updated_at || new Date().toISOString(),
            image_url: post.image_url || '',
            likes_count: post.likes_count || 0,
            dislikes_count: post.dislikes_count || 0
          }));

          setPosts(formattedPosts);
        } else {
          // Use hardcoded sample data as last resort
          // Use a fixed admin ID instead of user?.id to avoid auth.users table access
          const adminAuthorId = '00000000-0000-0000-0000-000000000000';

          const samplePosts: Post[] = [
            {
              id: '1',
              title_en: 'Getting Started with AI Medical Consultations',
              title_ar: 'بدء الاستشارات الطبية بالذكاء الاصطناعي',
              content_en: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit...',
              content_ar: 'هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء...',
              category: 'tips',
              published: true,
              author_id: adminAuthorId,
              author_name: 'Admin',
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
              image_url: '/images/blog/ai-consultation.jpg'
            },
            {
              id: '2',
              title_en: 'Understanding AI Diagnosis Limitations',
              title_ar: 'فهم قيود التشخيص بالذكاء الاصطناعي',
              content_en: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit...',
              content_ar: 'هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء...',
              category: 'tips',
              published: false,
              author_id: adminAuthorId,
              author_name: 'Admin',
              created_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
              updated_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
              image_url: '/images/blog/ai-limitations.jpg'
            }
          ];

          setPosts(samplePosts);
        }
      } catch (error) {
        console.error('Error creating sample posts:', error);
        // Use empty array on error
        setPosts([]);
      }
    };

    if (activeTab === 'blog') {
      fetchPosts();
    }
  }, [activeTab]);

  // Fetch comments
  useEffect(() => {
    const fetchComments = async () => {
      setIsLoadingComments(true);
      try {
        // Check if the blog_comments table exists
        const { error: checkError } = await supabase
          .from('blog_comments')
          .select('id')
          .limit(1);

        if (checkError && checkError.message.includes('does not exist')) {
          console.warn('blog_comments table does not exist');
          setIsLoadingComments(false);
          return;
        }

        const { data, error } = await supabase
          .from('blog_comments')
          .select('*')
          .order('created_at', { ascending: false });

        if (error) throw error;

        setComments(data || []);
      } catch (error) {
        console.error('Error fetching comments:', error);
      } finally {
        setIsLoadingComments(false);
      }
    };

    if (activeTab === 'comments') {
      fetchComments();
    }
  }, [activeTab]);

  // Fetch testimonials
  useEffect(() => {
    const fetchTestimonials = async () => {
      setIsLoadingTestimonials(true);
      try {
        // Check if the testimonials table exists
        const { error: checkError } = await supabase
          .from('testimonials')
          .select('id')
          .limit(1);

        if (checkError && checkError.message.includes('does not exist')) {
          console.warn('testimonials table does not exist');
          setIsLoadingTestimonials(false);
          return;
        }

        const { data, error } = await supabase
          .from('testimonials')
          .select('*')
          .order('created_at', { ascending: false });

        if (error) throw error;

        setTestimonials(data || []);
      } catch (error) {
        console.error('Error fetching testimonials:', error);
      } finally {
        setIsLoadingTestimonials(false);
      }
    };

    if (activeTab === 'testimonials') {
      fetchTestimonials();
    }
  }, [activeTab]);

  // Handle post actions
  const handleAddPost = () => {
    setEditingPostId(null);
    setShowPostForm(true);
  };

  const handleEditPost = (postId: string) => {
    setEditingPostId(postId);
    setShowPostForm(true);
  };

  const handleViewPost = (postId: string) => {
    // Open post in a new tab
    const post = posts.find(p => p.id === postId);
    if (post) {
      window.open(`/blog/${postId}`, '_blank');
    }
  };

  const handleDeletePost = async (postId: string) => {
    if (confirmDelete !== postId) {
      setConfirmDelete(postId);
      return;
    }

    try {
      const { error } = await supabase
        .from('blog_posts')
        .delete()
        .eq('id', postId);

      if (error) throw error;

      setPosts(posts.filter(post => post.id !== postId));
      setSuccessMessage(t('admin.content.postDeleted', 'Post deleted successfully'));

      // Clear success message after 3 seconds
      setTimeout(() => {
        setSuccessMessage(null);
      }, 3000);
    } catch (error) {
      console.error('Error deleting post:', error);
      setErrorMessage(t('admin.content.errorDeletingPost', 'Error deleting post'));

      // Clear error message after 3 seconds
      setTimeout(() => {
        setErrorMessage(null);
      }, 3000);
    } finally {
      setConfirmDelete(null);
    }
  };

  const handleTogglePublishStatus = async (postId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('blog_posts')
        .update({ published: !currentStatus })
        .eq('id', postId);

      if (error) throw error;

      // Update local state
      setPosts(posts.map(post =>
        post.id === postId ? { ...post, published: !currentStatus } : post
      ));

      setSuccessMessage(
        !currentStatus
          ? t('admin.content.postPublished', 'Post published successfully')
          : t('admin.content.postUnpublished', 'Post unpublished successfully')
      );

      // Clear success message after 3 seconds
      setTimeout(() => {
        setSuccessMessage(null);
      }, 3000);
    } catch (error) {
      console.error('Error updating post status:', error);
      setErrorMessage(t('admin.content.errorUpdatingPost', 'Error updating post status'));

      // Clear error message after 3 seconds
      setTimeout(() => {
        setErrorMessage(null);
      }, 3000);
    }
  };

  // Filter posts based on search term, status filter, and category filter
  const filteredPosts = posts.filter(post => {
    const matchesSearch =
      post.title_en.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.title_ar.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.content_en.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.content_ar.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus =
      statusFilter === 'all' ||
      (statusFilter === 'published' && post.published) ||
      (statusFilter === 'draft' && !post.published);

    const matchesCategory =
      categoryFilter === 'all' ||
      post.category === categoryFilter;

    return matchesSearch && matchesStatus && matchesCategory;
  });

  // Filter comments based on search term and status filter
  const filteredComments = comments.filter(comment => {
    const matchesSearch =
      (comment.user_name ? comment.user_name.toLowerCase().includes(searchTerm.toLowerCase()) : false) ||
      comment.content.toLowerCase().includes(searchTerm.toLowerCase());

    if (statusFilter === 'all') return matchesSearch;
    if (statusFilter === 'approved') return matchesSearch && comment.approved;
    if (statusFilter === 'pending') return matchesSearch && !comment.approved;
    return matchesSearch;
  });

  // Filter testimonials based on search term and status filter
  const filteredTestimonials = testimonials.filter(testimonial => {
    const matchesSearch =
      testimonial.user_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      testimonial.content.toLowerCase().includes(searchTerm.toLowerCase());

    if (statusFilter === 'all') return matchesSearch;
    if (statusFilter === 'approved') return matchesSearch && testimonial.approved;
    if (statusFilter === 'pending') return matchesSearch && !testimonial.approved;
    return matchesSearch;
  });

  return (
    <>
      {showPostForm && (
        <BlogPostForm
          postId={editingPostId || undefined}
          onClose={() => {
            setShowPostForm(false);
            setEditingPostId(null);
          }}
          onSuccess={() => {
            setShowPostForm(false);
            setEditingPostId(null);
            // Refetch posts
            if (activeTab === 'blog') {
              const fetchPosts = async () => {
                setIsLoadingPosts(true);
                try {
                  // Fetch posts first
                  const { data, error } = await supabase
                    .from('blog_posts')
                    .select('*')
                    .order('created_at', { ascending: false });

                  if (error) throw error;

                  if (data && data.length > 0) {
                    // Get unique author IDs
                    const authorIds = [...new Set(data.map(post => post.author_id))].filter(Boolean);

                    // Create a map to store author information
                    const authorMap = {};

                    // If there are author IDs, fetch their profiles
                    if (authorIds.length > 0) {
                      const { data: authorData } = await supabase
                        .from('profiles')
                        .select('id, name, email')
                        .in('id', authorIds);

                      // Create a map of author data
                      if (authorData) {
                        authorData.forEach(author => {
                          authorMap[author.id] = author;
                        });
                      }
                    }

                    const formattedPosts: Post[] = data.map(post => ({
                      id: post.id,
                      title_en: post.title_en || 'Untitled',
                      title_ar: post.title_ar || 'بدون عنوان',
                      content_en: post.content_en || '',
                      content_ar: post.content_ar || '',
                      category: post.category || 'tips',
                      published: post.published || false,
                      author_id: post.author_id || '',
                      author_name: authorMap[post.author_id]?.name ||
                                  authorMap[post.author_id]?.email?.split('@')[0] ||
                                  'Unknown',
                      created_at: post.created_at || new Date().toISOString(),
                      updated_at: post.updated_at || new Date().toISOString(),
                      image_url: post.image_url || '',
                      likes_count: post.likes_count || 0,
                      dislikes_count: post.dislikes_count || 0
                    }));

                    setPosts(formattedPosts);
                  }
                } catch (error) {
                  console.error('Error fetching posts:', error);
                } finally {
                  setIsLoadingPosts(false);
                }
              };

              fetchPosts();
            }
          }}
        />
      )}

      <div className="p-6">
        <h1 className="text-2xl font-bold mb-6">{t('admin.content.title')}</h1>

        {/* Tabs */}
        <div className="flex border-b mb-6">
          <button
            className={`${
              activeTab === 'blog'
                ? 'border-b-2 border-blue-500 text-blue-600'
                : 'text-gray-500 hover:text-gray-700'
            } flex items-center px-4 py-2 font-medium`}
            onClick={() => setActiveTab('blog')}
          >
            <FileText className={`h-5 w-5 ${isRTL ? 'ml-2' : 'mr-2'}`} />
            {t('admin.content.blog')}
          </button>
          <button
            className={`${
              activeTab === 'comments'
                ? 'border-b-2 border-blue-500 text-blue-600'
                : 'text-gray-500 hover:text-gray-700'
            } flex items-center px-4 py-2 font-medium`}
            onClick={() => setActiveTab('comments')}
          >
            <MessageSquare className={`h-5 w-5 ${isRTL ? 'ml-2' : 'mr-2'}`} />
            {t('admin.content.comments')}
          </button>
          <button
            className={`${
              activeTab === 'testimonials'
                ? 'border-b-2 border-blue-500 text-blue-600'
                : 'text-gray-500 hover:text-gray-700'
            } flex items-center px-4 py-2 font-medium`}
            onClick={() => setActiveTab('testimonials')}
          >
            <Star className={`h-5 w-5 ${isRTL ? 'ml-2' : 'mr-2'}`} />
            {t('admin.content.testimonials')}
          </button>
        </div>

        {/* Success and Error Messages */}
        {successMessage && (
          <div className="mb-4 p-3 bg-green-100 text-green-700 rounded-md flex items-center">
            <CheckCircle className="h-5 w-5 mr-2" />
            {successMessage}
          </div>
        )}

        {errorMessage && (
          <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-md flex items-center">
            <AlertCircle className="h-5 w-5 mr-2" />
            {errorMessage}
          </div>
        )}

        {/* Search and Filter */}
        <div className="flex flex-col md:flex-row justify-between mb-6">
          <div className="relative mb-4 md:mb-0 md:w-1/3">
            <input
              type="text"
              placeholder={t('common.search')}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>

          <div className="flex flex-wrap gap-2">
            {/* Status Filter */}
            <div className="relative">
              <select
                className="appearance-none pl-10 pr-8 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
              >
                <option value="all">{t('common.all')}</option>
                {activeTab === 'blog' && (
                  <>
                    <option value="draft">{t('admin.content.draft')}</option>
                    <option value="published">{t('admin.content.published')}</option>
                  </>
                )}
                {activeTab === 'comments' && (
                  <>
                    <option value="approved">{t('admin.content.approved')}</option>
                    <option value="pending">{t('admin.content.pending')}</option>
                  </>
                )}
                {activeTab === 'testimonials' && (
                  <>
                    <option value="approved">{t('admin.content.approved')}</option>
                    <option value="pending">{t('admin.content.pending')}</option>
                  </>
                )}
              </select>
              <Filter className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>

            {/* Category Filter (only for blog) */}
            {activeTab === 'blog' && (
              <div className="relative">
                <select
                  className="appearance-none pl-10 pr-8 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                >
                  <option value="all">{t('common.allCategories', 'All Categories')}</option>
                  <option value="tips">{t('admin.content.categoryTips', 'Tips')}</option>
                  <option value="news">{t('admin.content.categoryNews', 'News')}</option>
                </select>
                <Tag className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              </div>
            )}

            {/* Add Button (only for blog) */}
            {activeTab === 'blog' && (
              <button
                onClick={handleAddPost}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <Plus className={`h-5 w-5 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                {t('admin.content.addPost')}
              </button>
            )}
          </div>
        </div>

      {/* Content based on active tab */}
      {activeTab === 'blog' && (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          {isLoadingPosts ? (
            <div className="p-6 text-center">
              <p>{t('common.loading')}</p>
            </div>
          ) : filteredPosts.length === 0 ? (
            <div className="p-6 text-center">
              <p>{t('common.noResults')}</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('admin.content.postTitle')}
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('admin.content.author')}
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('admin.content.postStatus')}
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('admin.content.publishDate')}
                    </th>
                    <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('common.actions')}
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredPosts.map((post) => (
                    <tr key={post.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">
                          {language === 'ar' ? post.title_ar : post.title_en}
                        </div>
                        <div className="text-xs text-gray-500 mt-1">
                          <Tag className="h-3 w-3 inline mr-1" />
                          {post.category === 'tips'
                            ? t('admin.content.categoryTips', 'Tips')
                            : t('admin.content.categoryNews', 'News')}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-500">{post.author_name || 'Unknown'}</div>
                        <div className="text-xs text-gray-400 mt-1">
                          {post.author_id === user?.id
                            ? t('admin.content.you', 'You')
                            : t('admin.content.admin', 'Admin')}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          post.published ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                        }`}>
                          {post.published ? t('admin.content.published') : t('admin.content.draft')}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(post.created_at).toLocaleDateString(
                          language === 'ar' ? 'ar-SA' : 'en-US'
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        {/* View Post */}
                        <button
                          onClick={() => handleViewPost(post.id)}
                          className="text-blue-600 hover:text-blue-900 mr-3"
                          title={t('admin.content.viewPost')}
                        >
                          <Eye className="h-5 w-5" />
                        </button>

                        {/* Toggle Publish Status */}
                        <button
                          onClick={() => handleTogglePublishStatus(post.id, post.published)}
                          className={`mr-3 ${post.published ? 'text-orange-500 hover:text-orange-700' : 'text-green-600 hover:text-green-800'}`}
                          title={post.published ? t('admin.content.unpublish') : t('admin.content.publish')}
                        >
                          {post.published ? (
                            <XCircle className="h-5 w-5" />
                          ) : (
                            <CheckCircle className="h-5 w-5" />
                          )}
                        </button>

                        {/* Edit Post */}
                        <button
                          onClick={() => handleEditPost(post.id)}
                          className="text-indigo-600 hover:text-indigo-900 mr-3"
                          title={t('admin.content.editPost')}
                        >
                          <Edit className="h-5 w-5" />
                        </button>

                        {/* Delete Post */}
                        <button
                          onClick={() => handleDeletePost(post.id)}
                          className={`${confirmDelete === post.id ? 'text-red-800 bg-red-100 p-1 rounded' : 'text-red-600 hover:text-red-900'}`}
                          title={confirmDelete === post.id ? t('admin.content.confirmDelete') : t('admin.content.deletePost')}
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Comments Tab Content */}
      {activeTab === 'comments' && (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          {isLoadingComments ? (
            <div className="p-6 text-center">
              <p>{t('common.loading')}</p>
            </div>
          ) : filteredComments.length === 0 ? (
            <div className="p-6 text-center">
              <p>{t('common.noResults')}</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('admin.content.commentAuthor')}
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('admin.content.commentContent')}
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('admin.content.commentStatus')}
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('admin.content.commentDate')}
                    </th>
                    <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('common.actions')}
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredComments.map((comment) => (
                    <tr key={comment.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">{comment.user_name || 'Anonymous'}</div>
                        <div className="text-sm text-gray-500">{comment.user_id || 'Guest'}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900 line-clamp-2">{comment.content}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          comment.approved ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {comment.approved ? t('admin.content.approved') : t('admin.content.pending')}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(comment.created_at).toLocaleDateString(
                          language === 'ar' ? 'ar-SA' : 'en-US'
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        {comment.status === 'pending' && (
                          <button className="text-green-600 hover:text-green-900 mr-3">
                            <CheckCircle className="h-5 w-5" />
                          </button>
                        )}
                        {comment.status !== 'spam' && (
                          <button className="text-red-600 hover:text-red-900 mr-3">
                            <XCircle className="h-5 w-5" />
                          </button>
                        )}
                        <button className="text-red-600 hover:text-red-900">
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Testimonials Tab Content */}
      {activeTab === 'testimonials' && (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          {isLoadingTestimonials ? (
            <div className="p-6 text-center">
              <p>{t('common.loading')}</p>
            </div>
          ) : filteredTestimonials.length === 0 ? (
            <div className="p-6 text-center">
              <p>{t('common.noResults')}</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('admin.content.testimonialAuthor')}
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('admin.content.testimonialContent')}
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('admin.content.testimonialRating')}
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('admin.content.commentStatus')}
                    </th>
                    <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('common.actions')}
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredTestimonials.map((testimonial) => (
                    <tr key={testimonial.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">{testimonial.user_name}</div>
                        <div className="text-sm text-gray-500">{testimonial.user_id || 'Guest'}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900 line-clamp-2">{testimonial.content}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`h-4 w-4 ${i < testimonial.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
                            />
                          ))}
                          <span className="ml-2 text-sm text-gray-600">{testimonial.rating}/5</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          testimonial.approved ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {testimonial.approved ? t('admin.content.approved') : t('admin.content.pending')}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        {!testimonial.approved && (
                          <button className="text-green-600 hover:text-green-900 mr-3">
                            <CheckCircle className="h-5 w-5" />
                          </button>
                        )}
                        <button className="text-red-600 hover:text-red-900">
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
    </>
  );
};



export default ContentManagement;
