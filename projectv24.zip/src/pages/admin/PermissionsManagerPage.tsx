import React from 'react';
import { useAuthStore } from '../../store/authStore';
import { Navigate, useLocation } from 'react-router-dom';
import AdminLayout from '../../components/admin/AdminLayout';
import PermissionsManager from '../../components/admin/PermissionsManager';

const PermissionsManagerPage = () => {
  const user = useAuthStore((state) => state.user);
  const location = useLocation();

  if (!user) {
    return <Navigate to="/admin/login" state={{ from: location }} replace />;
  }

  return (
    <AdminLayout>
      <PermissionsManager />
    </AdminLayout>
  );
};

export default PermissionsManagerPage;
