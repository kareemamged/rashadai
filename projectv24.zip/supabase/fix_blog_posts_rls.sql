-- Fix RLS policies for blog_posts table
-- This script should be executed in the Supabase SQL Editor with admin privileges

-- First, enable RLS on the blog_posts table if it's not already enabled
ALTER TABLE blog_posts ENABLE ROW LEVEL SECURITY;

-- Drop existing policies to recreate them
DROP POLICY IF EXISTS blog_posts_select_policy ON blog_posts;
DROP POLICY IF EXISTS blog_posts_insert_policy ON blog_posts;
DROP POLICY IF EXISTS blog_posts_update_policy ON blog_posts;
DROP POLICY IF EXISTS blog_posts_delete_policy ON blog_posts;

-- Create a more permissive select policy for testing
CREATE POLICY blog_posts_select_policy ON blog_posts
  FOR SELECT USING (true);  -- Allow anyone to select from blog_posts

-- Create insert policy - allow anyone to insert for testing
CREATE POLICY blog_posts_insert_policy ON blog_posts
  FOR INSERT WITH CHECK (true);  -- Allow anyone to insert for testing

-- Create update policy - allow anyone to update for testing
CREATE POLICY blog_posts_update_policy ON blog_posts
  FOR UPDATE USING (true);  -- Allow anyone to update for testing

-- Create delete policy - allow anyone to delete for testing
CREATE POLICY blog_posts_delete_policy ON blog_posts
  FOR DELETE USING (true);  -- Allow anyone to delete for testing

-- Make sure the blog_comments table has RLS enabled too
ALTER TABLE blog_comments ENABLE ROW LEVEL SECURITY;

-- Drop existing policies for blog_comments
DROP POLICY IF EXISTS blog_comments_select_policy ON blog_comments;
DROP POLICY IF EXISTS blog_comments_insert_policy ON blog_comments;
DROP POLICY IF EXISTS blog_comments_update_policy ON blog_comments;
DROP POLICY IF EXISTS blog_comments_delete_policy ON blog_comments;

-- Create a more permissive select policy for blog_comments
CREATE POLICY blog_comments_select_policy ON blog_comments
  FOR SELECT USING (true);  -- Allow anyone to select from blog_comments

-- Create insert policy for blog_comments - allow anyone to insert for testing
CREATE POLICY blog_comments_insert_policy ON blog_comments
  FOR INSERT WITH CHECK (true);  -- Allow anyone to insert for testing

-- Create update policy for blog_comments - allow anyone to update for testing
CREATE POLICY blog_comments_update_policy ON blog_comments
  FOR UPDATE USING (true);  -- Allow anyone to update for testing

-- Create delete policy for blog_comments - allow anyone to delete for testing
CREATE POLICY blog_comments_delete_policy ON blog_comments
  FOR DELETE USING (true);  -- Allow anyone to delete for testing
