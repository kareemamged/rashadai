-- تحديث جدول site_settings لإضافة سجل افتراضي إذا لم يكن موجودًا

-- التحقق من وجود سجل في جدول site_settings
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM site_settings WHERE id = 1) THEN
        -- إنشاء سجل افتراضي
        INSERT INTO site_settings (
            id, 
            site_name, 
            site_description, 
            contact_email, 
            contact_phone, 
            social_links, 
            theme_settings, 
            updated_at
        ) VALUES (
            1, 
            'RashadAI', 
            'AI-Powered Medical Consultation', 
            'support@rashadai.com', 
            '+1 (555) 123-4567', 
            '{"facebook": "https://facebook.com/rashadai", "twitter": "https://twitter.com/rashadai", "instagram": "https://instagram.com/rashadai"}', 
            '{"colors": {"primary": "#3b82f6", "secondary": "#1e40af", "accent": "#10b981", "background": "#f9fafb", "text": "#1f2937"}, "fonts": {"heading": "Inter, sans-serif", "body": "Inter, sans-serif", "size": "medium"}}', 
            NOW()
        );
        
        RAISE NOTICE 'Created default site_settings record';
    ELSE
        RAISE NOTICE 'site_settings record already exists';
    END IF;
END $$;

-- التحقق من وجود جدول design_settings
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'design_settings') THEN
        -- إنشاء جدول design_settings
        CREATE TABLE design_settings (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            colors JSONB NOT NULL DEFAULT '{"primary": "#3b82f6", "secondary": "#1e40af", "accent": "#10b981", "background": "#f9fafb", "text": "#1f2937"}',
            fonts JSONB NOT NULL DEFAULT '{"heading": "Inter, sans-serif", "body": "Inter, sans-serif", "size": "medium"}',
            logo TEXT,
            favicon TEXT,
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMPTZ DEFAULT NOW()
        );
        
        -- إنشاء سجل افتراضي
        INSERT INTO design_settings (
            colors, 
            fonts, 
            is_active, 
            created_at
        ) VALUES (
            '{"primary": "#3b82f6", "secondary": "#1e40af", "accent": "#10b981", "background": "#f9fafb", "text": "#1f2937"}', 
            '{"heading": "Inter, sans-serif", "body": "Inter, sans-serif", "size": "medium"}', 
            TRUE, 
            NOW()
        );
        
        RAISE NOTICE 'Created design_settings table and default record';
    ELSE
        RAISE NOTICE 'design_settings table already exists';
    END IF;
END $$;

-- إنشاء وظيفة RPC لتحديث إعدادات التصميم
CREATE OR REPLACE FUNCTION update_design_settings(
    p_colors JSONB,
    p_fonts JSONB,
    p_logo TEXT DEFAULT NULL,
    p_favicon TEXT DEFAULT NULL
) RETURNS JSONB AS $$
DECLARE
    v_result JSONB;
BEGIN
    -- تعطيل جميع الإعدادات النشطة
    UPDATE design_settings
    SET is_active = FALSE
    WHERE is_active = TRUE;
    
    -- إنشاء إعدادات جديدة
    INSERT INTO design_settings (
        colors,
        fonts,
        logo,
        favicon,
        is_active,
        created_at
    ) VALUES (
        p_colors,
        p_fonts,
        p_logo,
        p_favicon,
        TRUE,
        NOW()
    )
    RETURNING jsonb_build_object(
        'id', id,
        'colors', colors,
        'fonts', fonts,
        'logo', logo,
        'favicon', favicon,
        'is_active', is_active,
        'created_at', created_at
    ) INTO v_result;
    
    RETURN v_result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- إنشاء وظيفة RPC للحصول على إعدادات التصميم النشطة
CREATE OR REPLACE FUNCTION get_active_design_settings()
RETURNS JSONB AS $$
DECLARE
    v_result JSONB;
BEGIN
    SELECT jsonb_build_object(
        'id', id,
        'colors', colors,
        'fonts', fonts,
        'logo', logo,
        'favicon', favicon,
        'created_at', created_at
    )
    INTO v_result
    FROM design_settings
    WHERE is_active = TRUE
    LIMIT 1;
    
    IF v_result IS NULL THEN
        -- إذا لم يتم العثور على إعدادات نشطة، إرجاع الإعدادات الافتراضية
        v_result := jsonb_build_object(
            'colors', '{"primary": "#3b82f6", "secondary": "#1e40af", "accent": "#10b981", "background": "#f9fafb", "text": "#1f2937"}'::jsonb,
            'fonts', '{"heading": "Inter, sans-serif", "body": "Inter, sans-serif", "size": "medium"}'::jsonb,
            'logo', NULL,
            'favicon', NULL
        );
    END IF;
    
    RETURN v_result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
