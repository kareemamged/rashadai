-- تحديث وظيفة create_new_user لإضافة معلمة تجاوز التحقق من الصلاحيات
CREATE OR REPLACE FUNCTION public.create_new_user(
  p_email text,
  p_password text,
  p_name text,
  p_role text DEFAULT 'user'::text,
  p_bypass_auth_check boolean DEFAULT false
)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
  v_user_id UUID;
  v_error TEXT;
  v_success BOOLEAN := FALSE;
  v_current_user_id UUID;
  v_is_admin BOOLEAN;
BEGIN
  -- Get the current user ID
  v_current_user_id := auth.uid();
  
  -- Check if the current user has admin privileges by checking admin_users table
  SELECT EXISTS (
    SELECT 1 FROM admin_users 
    WHERE id = v_current_user_id
  ) INTO v_is_admin;
  
  -- Debug output
  RAISE NOTICE 'Current user ID: %, Is admin: %, Bypass auth: %', v_current_user_id, v_is_admin, p_bypass_auth_check;
  
  -- If no current user or not an admin, check if we're creating the first admin or if bypass is enabled
  IF (v_current_user_id IS NULL OR NOT v_is_admin) AND NOT p_bypass_auth_check THEN
    -- Check if there are any admin users in the system
    IF NOT EXISTS (SELECT 1 FROM admin_users LIMIT 1) AND p_role = 'admin' THEN
      -- Allow creating the first admin without authentication
      v_is_admin := TRUE;
      RAISE NOTICE 'Creating first admin user, bypassing auth check';
    ELSE
      -- Otherwise, require admin privileges
      RETURN jsonb_build_object(
        'success', FALSE,
        'message', 'Only administrators can create new users',
        'current_user_id', v_current_user_id
      );
    END IF;
  END IF;

  -- Create the user in auth.users
  BEGIN
    v_user_id := extensions.uuid_generate_v4();
    
    INSERT INTO auth.users (
      id,
      email,
      encrypted_password,
      email_confirmed_at,
      created_at,
      updated_at,
      raw_app_meta_data,
      raw_user_meta_data,
      is_super_admin
    ) VALUES (
      v_user_id,
      p_email,
      crypt(p_password, gen_salt('bf')),
      NOW(),
      NOW(),
      NOW(),
      jsonb_build_object('provider', 'email'),
      jsonb_build_object('name', p_name),
      FALSE
    );
    
    -- Create or update the profile
    INSERT INTO public.profiles (id, name, role, created_at, updated_at)
    VALUES (v_user_id, p_name, p_role, NOW(), NOW())
    ON CONFLICT (id) DO UPDATE
    SET 
      name = p_name,
      role = p_role,
      updated_at = NOW();
      
    -- If the user is an admin, also add them to the admin_users table
    IF p_role = 'admin' THEN
      INSERT INTO public.admin_users (id, name, email, role, created_at, updated_at)
      VALUES (v_user_id, p_name, p_email, 'admin', NOW(), NOW())
      ON CONFLICT (id) DO UPDATE
      SET 
        name = p_name,
        email = p_email,
        updated_at = NOW();
    END IF;
      
    v_success := TRUE;
  EXCEPTION WHEN OTHERS THEN
    v_error := SQLERRM;
    v_success := FALSE;
  END;
  
  IF v_success THEN
    RETURN jsonb_build_object(
      'success', TRUE,
      'user_id', v_user_id
    );
  ELSE
    RETURN jsonb_build_object(
      'success', FALSE,
      'message', v_error
    );
  END IF;
END;
$function$;
