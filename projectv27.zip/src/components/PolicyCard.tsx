import React, { ReactNode } from 'react';
import { useLanguageStore } from '../store/languageStore';
import IconCircle from './IconCircle';

interface PolicyCardProps {
  title: string;
  description: string;
  icon: ReactNode;
  linkUrl: string;
  linkText: string;
}

const PolicyCard: React.FC<PolicyCardProps> = ({
  title,
  description,
  icon,
  linkUrl,
  linkText
}) => {
  const { language } = useLanguageStore();
  const isRtl = language === 'ar';
  
  return (
    <div className="bg-blue-50 p-6 rounded-xl">
      <div className="flex items-start mb-2">
        <IconCircle 
          icon={icon}
          size="sm"
          className="flex-shrink-0"
        />
        <h3 className={`text-lg font-semibold text-gray-800 ${isRtl ? 'mr-3' : 'ml-3'}`}>
          {title}
        </h3>
      </div>
      <p className="text-gray-600 mb-4">
        {description}
      </p>
      <a 
        href={linkUrl} 
        className={`text-blue-600 hover:text-blue-800 font-medium ${isRtl ? 'flex items-center' : ''}`}
      >
        {isRtl ? (
          <>
            <span className="ml-1">{linkText}</span> ←
          </>
        ) : (
          `${linkText} →`
        )}
      </a>
    </div>
  );
};

export default PolicyCard;
