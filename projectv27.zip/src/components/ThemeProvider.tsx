import React, { useEffect } from 'react';
import { useDesignStore } from '../store/designStore';
import { useAdminStore } from '../store/adminStore';

interface ThemeProviderProps {
  children: React.ReactNode;
}

const ThemeProvider: React.FC<ThemeProviderProps> = ({ children }) => {
  const { settings, fetchSettings } = useDesignStore();
  const { systemSettings } = useAdminStore();

  useEffect(() => {
    // Fetch design settings on component mount
    fetchSettings();
  }, [fetchSettings]);

  useEffect(() => {
    // Apply design settings to the document
    if (settings) {
      // Apply colors as CSS variables
      const root = document.documentElement;
      root.style.setProperty('--color-primary', settings.colors.primary);
      root.style.setProperty('--color-secondary', settings.colors.secondary);
      root.style.setProperty('--color-accent', settings.colors.accent);
      root.style.setProperty('--color-background', settings.colors.background);
      root.style.setProperty('--color-text', settings.colors.text);

      // Apply fonts
      const fontStyle = document.createElement('style');
      fontStyle.innerHTML = `
        :root {
          --font-heading: ${settings.fonts.heading};
          --font-body: ${settings.fonts.body};
          --font-size: ${settings.fonts.size};

          /* Additional color variables for specific components */
          --btn-primary-bg: ${settings.colors.primary};
          --btn-primary-text: white;
          --btn-secondary-bg: ${settings.colors.secondary};
          --btn-secondary-text: white;
          --btn-accent-bg: ${settings.colors.accent};
          --btn-accent-text: white;
          --header-bg: white;
          --header-text: ${settings.colors.text};
          --hero-bg: ${settings.colors.primary};
          --hero-text: white;
          --card-bg: white;
          --card-text: ${settings.colors.text};
          --footer-bg: ${settings.colors.secondary};
          --footer-text: white;
          --link-color: ${settings.colors.primary};
          --link-hover-color: ${settings.colors.secondary};
        }

        /* Global element styling */
        h1, h2, h3, h4, h5, h6 {
          font-family: var(--font-heading);
          color: var(--color-text);
        }

        body {
          font-family: var(--font-body);
          font-size: ${
            settings.fonts.size === 'small' ? '0.875rem' :
            settings.fonts.size === 'large' ? '1.125rem' : '1rem'
          };
          color: var(--color-text);
          background-color: var(--color-background);
        }

        /* Button styling */
        .btn-primary,
        .bg-blue-600,
        .hover\\:bg-blue-700:hover {
          background-color: var(--btn-primary-bg) !important;
          color: var(--btn-primary-text) !important;
          border-color: var(--btn-primary-bg) !important;
        }

        .btn-secondary,
        .bg-blue-700,
        .hover\\:bg-blue-800:hover {
          background-color: var(--btn-secondary-bg) !important;
          color: var(--btn-secondary-text) !important;
          border-color: var(--btn-secondary-bg) !important;
        }

        .btn-accent,
        .bg-green-500,
        .hover\\:bg-green-600:hover {
          background-color: var(--btn-accent-bg) !important;
          color: var(--btn-accent-text) !important;
          border-color: var(--btn-accent-bg) !important;
        }

        /* Text colors */
        .text-blue-600,
        .hover\\:text-blue-600:hover {
          color: var(--color-primary) !important;
        }

        .text-blue-700,
        .hover\\:text-blue-700:hover {
          color: var(--color-secondary) !important;
        }

        /* Link styling */
        a {
          color: var(--link-color);
        }

        a:hover {
          color: var(--link-hover-color);
        }
      `;

      // Remove any existing font style element
      const existingFontStyle = document.getElementById('theme-font-style');
      if (existingFontStyle) {
        existingFontStyle.remove();
      }

      // Add the new font style element
      fontStyle.id = 'theme-font-style';
      document.head.appendChild(fontStyle);

      // Apply favicon if available
      if (settings.favicon) {
        const existingFavicon = document.querySelector('link[rel="icon"]');
        if (existingFavicon) {
          existingFavicon.setAttribute('href', settings.favicon);
        } else {
          const favicon = document.createElement('link');
          favicon.rel = 'icon';
          favicon.href = settings.favicon;
          document.head.appendChild(favicon);
        }
      }

      // Update page title with site name
      if (systemSettings.siteName) {
        const siteTitle = document.getElementById('site-title');
        if (siteTitle) {
          siteTitle.textContent = `${systemSettings.siteName} - AI-Powered Medical Consultation`;
        }
        document.title = `${systemSettings.siteName} - AI-Powered Medical Consultation`;
      }
    }
  }, [settings, systemSettings]);

  return <>{children}</>;
};

export default ThemeProvider;
