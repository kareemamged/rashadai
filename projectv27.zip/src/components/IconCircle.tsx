import React, { ReactNode } from 'react';
import { useDesignStore } from '../store/designStore';

interface IconCircleProps {
  icon: ReactNode;
  color?: string;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

const IconCircle: React.FC<IconCircleProps> = ({ 
  icon, 
  color, 
  size = 'md',
  className = '' 
}) => {
  const { settings } = useDesignStore();
  
  // Default color is primary if not specified
  const circleColor = color || settings?.colors?.primary || '#3b82f6';
  
  // Size classes
  const sizeClasses = {
    sm: 'p-2',
    md: 'p-3',
    lg: 'p-4'
  };
  
  return (
    <div 
      className={`rounded-full inline-flex items-center justify-center ${sizeClasses[size]} ${className}`}
      style={{ 
        backgroundColor: `${circleColor}20` // 20% opacity version of the color
      }}
    >
      {icon}
    </div>
  );
};

export default IconCircle;
