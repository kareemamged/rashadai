import React, { useState, useRef, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Activity, Bot, User, LogOut, Settings, ChevronDown, Bell, MessageSquare, ArrowLeft, Globe } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { getCountryByCode } from '../data/countries';
import { useTranslation } from 'react-i18next';
import { useLanguageStore } from '../store/languageStore';

const ChatHeader: React.FC = () => {
  const navigate = useNavigate();
  const { user, signOut } = useAuthStore();
  useTranslation(); // استخدام الهوك بدون تخزين القيم
  const { language, setLanguage } = useLanguageStore();
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const profileMenuRef = useRef<HTMLDivElement>(null);
  const notificationsRef = useRef<HTMLDivElement>(null);

  const country = user?.country_code ? getCountryByCode(user.country_code) : undefined;

  const toggleLanguage = () => {
    const newLanguage = language === 'ar' ? 'en' : 'ar';
    setLanguage(newLanguage);
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  // إغلاق القوائم عند النقر خارجها
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (profileMenuRef.current && !profileMenuRef.current.contains(event.target as Node)) {
        setIsProfileMenuOpen(false);
      }
      if (notificationsRef.current && !notificationsRef.current.contains(event.target as Node)) {
        setIsNotificationsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const goBack = () => {
    // العودة للصفحة السابقة بدلاً من الصفحة الرئيسية
    navigate(-1);
  };

  return (
    <header className="bg-white border-b border-gray-200 shadow-sm py-3 px-4 md:px-6" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      <div className="container mx-auto flex justify-between items-center">
        {/* Left side with logo and assistant info */}
        <div className="flex items-center">
          {/* Back button */}
          <button
            onClick={goBack}
            className={`${language === 'ar' ? 'ml-4' : 'mr-4'} p-2 rounded-full hover:bg-gray-100 transition-colors`}
          >
            <ArrowLeft className="w-5 h-5 text-gray-600" />
          </button>

          {/* Logo */}
          <Link to="/chat" className="flex items-center">
            <Bot className={`h-8 w-8 text-blue-600 ${language === 'ar' ? 'ml-2' : 'mr-2'}`} />
            <span className="text-xl font-bold text-blue-700">RashadAI</span>
          </Link>
        </div>

        {/* Right side navigation */}
        <div className={`flex items-center ${language === 'ar' ? 'space-x-reverse' : ''} space-x-4`}>
          {/* Language Selector */}
          <button
            onClick={toggleLanguage}
            className="p-2 rounded-full hover:bg-gray-100 transition-colors"
            aria-label="Toggle language"
            title={language === 'ar' ? 'Switch to English' : 'التبديل إلى العربية'}
          >
            <Globe className="h-5 w-5 text-blue-600" />
          </button>

          {/* Notifications */}
          <div className="relative" ref={notificationsRef}>
            <button
              onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
              className="p-2 rounded-full hover:bg-gray-100 relative"
            >
              <Bell className="h-5 w-5 text-gray-600" />
              <span className="absolute top-0 right-0 h-2 w-2 bg-red-500 rounded-full"></span>
            </button>

            {isNotificationsOpen && (
              <div className={`absolute ${language === 'ar' ? 'left-0' : 'right-0'} mt-2 w-80 bg-white rounded-lg shadow-lg py-2 z-50 border border-gray-200`}>
                <div className="px-4 py-2 border-b border-gray-100">
                  <h3 className={`font-semibold text-gray-800 ${language === 'ar' ? 'text-right' : ''}`}>
                    {language === 'ar' ? 'الإشعارات' : 'Notifications'}
                  </h3>
                </div>
                <div className="max-h-80 overflow-y-auto">
                  <div className="px-4 py-3 hover:bg-gray-50 border-b border-gray-100">
                    <p className={`text-sm text-gray-800 ${language === 'ar' ? 'text-right' : ''}`}>
                      {language === 'ar' ? 'تم تحديث سياسة الخصوصية الخاصة بنا' : 'Our privacy policy has been updated'}
                    </p>
                    <p className={`text-xs text-gray-500 mt-1 ${language === 'ar' ? 'text-right' : ''}`}>
                      {language === 'ar' ? 'منذ ساعتين' : '2 hours ago'}
                    </p>
                  </div>
                  <div className="px-4 py-3 hover:bg-gray-50 border-b border-gray-100">
                    <p className={`text-sm text-gray-800 ${language === 'ar' ? 'text-right' : ''}`}>
                      {language === 'ar' ? 'تمت إضافة ميزات جديدة إلى الدردشة الطبية' : 'New features added to medical chat'}
                    </p>
                    <p className={`text-xs text-gray-500 mt-1 ${language === 'ar' ? 'text-right' : ''}`}>
                      {language === 'ar' ? 'منذ يوم واحد' : '1 day ago'}
                    </p>
                  </div>
                </div>
                <div className="px-4 py-2 border-t border-gray-100">
                  <button className={`text-sm text-blue-600 hover:text-blue-800 ${language === 'ar' ? 'w-full text-right' : ''}`}>
                    {language === 'ar' ? 'عرض جميع الإشعارات' : 'View all notifications'}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Help button removed as requested */}

          {/* User profile */}
          {user ? (
            <div className="relative" ref={profileMenuRef}>
              <button
                onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
                className="flex items-center space-x-2 rounded-full hover:bg-gray-100 p-1 transition-colors"
              >
                <div className={`flex items-center ${language === 'ar' ? 'space-x-reverse mr-2' : 'space-x-2 ml-2'}`}>
                  <span className="text-sm font-medium text-gray-700 hidden md:block">
                    {user.name || user.email.split('@')[0]}
                  </span>
                  {country && (
                    <span className="text-sm hidden md:block">{country.flag}</span>
                  )}
                  <ChevronDown className="h-4 w-4 text-gray-500" />
                </div>
                <div className="h-8 w-8 rounded-full overflow-hidden border-2 border-gray-200">
                  {user.avatar ? (
                    <img
                      src={user.avatar}
                      alt={user.name || 'User profile'}
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <div className="h-full w-full bg-blue-100 flex items-center justify-center">
                      <User className="h-4 w-4 text-blue-600" />
                    </div>
                  )}
                </div>
              </button>

              {isProfileMenuOpen && (
                <div className={`absolute ${language === 'ar' ? 'left-0' : 'right-0'} mt-2 w-56 bg-white rounded-lg shadow-lg py-2 z-50 border border-gray-200`}>
                  <div className="px-4 py-3 border-b border-gray-100">
                    <p className={`text-sm font-medium text-gray-900 ${language === 'ar' ? 'text-right' : ''}`}>{user.name || user.email.split('@')[0]}</p>
                    <p className={`text-sm text-gray-500 truncate ${language === 'ar' ? 'text-right' : ''}`}>{user.email}</p>
                  </div>
                  <Link
                    to="/profile"
                    className={`flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 ${language === 'ar' ? 'text-right' : 'text-left'}`}
                    onClick={() => setIsProfileMenuOpen(false)}
                  >
                    <User className={`h-4 w-4 ${language === 'ar' ? 'ml-2' : 'mr-2'}`} />
                    {language === 'ar' ? 'الملف الشخصي' : 'Profile'}
                  </Link>
                  <Link
                    to="/settings"
                    className={`flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 ${language === 'ar' ? 'text-right' : 'text-left'}`}
                    onClick={() => setIsProfileMenuOpen(false)}
                  >
                    <Settings className={`h-4 w-4 ${language === 'ar' ? 'ml-2' : 'mr-2'}`} />
                    {language === 'ar' ? 'الإعدادات' : 'Settings'}
                  </Link>
                  <Link
                    to="/chat-history"
                    className={`flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 ${language === 'ar' ? 'text-right' : 'text-left'}`}
                    onClick={() => setIsProfileMenuOpen(false)}
                  >
                    <MessageSquare className={`h-4 w-4 ${language === 'ar' ? 'ml-2' : 'mr-2'}`} />
                    {language === 'ar' ? 'سجل المحادثات' : 'Chat History'}
                  </Link>
                  <div className="border-t border-gray-100 my-1"></div>
                  <button
                    onClick={handleSignOut}
                    className={`flex w-full items-center px-4 py-2 text-sm text-red-600 hover:bg-gray-100 ${language === 'ar' ? 'text-right' : 'text-left'}`}
                  >
                    <LogOut className={`h-4 w-4 ${language === 'ar' ? 'ml-2' : 'mr-2'}`} />
                    {language === 'ar' ? 'تسجيل الخروج' : 'Logout'}
                  </button>
                </div>
              )}
            </div>
          ) : (
            <Link
              to="/login"
              className="flex items-center text-sm font-medium text-blue-600 hover:text-blue-800"
            >
              Login
            </Link>
          )}
        </div>
      </div>
    </header>
  );
};

export default ChatHeader;
