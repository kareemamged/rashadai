import React, { useState, useEffect, useRef } from 'react';
import { Menu, X, Activity, User, ChevronDown, LogOut, Settings, MessageSquare, Moon, Sun } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { useTranslation } from 'react-i18next';
import LanguageSelector from './LanguageSelector';

const Header = () => {
  const navigate = useNavigate();
  const { user, signOut } = useAuthStore();
  const { t } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const profileMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close profile menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (profileMenuRef.current && !profileMenuRef.current.contains(event.target as Node)) {
        setIsProfileMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const handleConsultation = () => {
    navigate('/consultation');
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  // Check for dark mode on component mount
  useEffect(() => {
    // Check localStorage for theme setting
    const savedSettings = localStorage.getItem('userSettings');
    if (savedSettings) {
      try {
        const parsedSettings = JSON.parse(savedSettings);
        const theme = parsedSettings.appearance?.theme;

        if (theme === 'dark') {
          setIsDarkMode(true);
        } else if (theme === 'system') {
          const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
          setIsDarkMode(prefersDark);
        }
      } catch (error) {
        console.error('Error parsing saved settings:', error);
      }
    } else {
      // Check if user prefers dark mode
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      setIsDarkMode(prefersDark);
    }
  }, []);

  // Toggle dark mode
  const toggleDarkMode = () => {
    const newDarkMode = !isDarkMode;
    setIsDarkMode(newDarkMode);

    // Apply theme
    const root = document.documentElement;
    if (newDarkMode) {
      root.classList.add('dark');
      document.body.style.backgroundColor = '#1a1a1a';
      document.body.style.color = '#f3f4f6';
    } else {
      root.classList.remove('dark');
      document.body.style.backgroundColor = '';
      document.body.style.color = '';
    }

    // Save to localStorage if settings exist
    const savedSettings = localStorage.getItem('userSettings');
    if (savedSettings) {
      try {
        const parsedSettings = JSON.parse(savedSettings);
        parsedSettings.appearance = {
          ...parsedSettings.appearance,
          theme: newDarkMode ? 'dark' : 'light'
        };
        localStorage.setItem('userSettings', JSON.stringify(parsedSettings));
      } catch (error) {
        console.error('Error updating settings:', error);
      }
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-white shadow-md py-3'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center">
            <Activity className="h-8 w-8 text-blue-600 mr-2" />
            <span className="text-xl font-bold text-blue-700">RashadAI</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex space-x-8 rtl:space-x-reverse">
            <Link to="/services" className="text-gray-700 hover:text-blue-600 font-medium">
              {t('header.services')}
            </Link>
            <Link to="/vision" className="text-gray-700 hover:text-blue-600 font-medium">
              {t('header.ourVision')}
            </Link>
            <Link to="/testimonials" className="text-gray-700 hover:text-blue-600 font-medium">
              {t('header.testimonials')}
            </Link>
            <Link to="/blog" className="text-gray-700 hover:text-blue-600 font-medium">
              {t('header.blog')}
            </Link>
          </nav>

          <div className="hidden lg:flex items-center space-x-4 rtl:space-x-reverse">
            <LanguageSelector />

            <button
              onClick={toggleDarkMode}
              className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
              aria-label="Toggle dark mode"
              title={isDarkMode ? t('header.lightMode') : t('header.darkMode')}
            >
              {isDarkMode ? (
                <Sun className="h-5 w-5 text-yellow-500" />
              ) : (
                <Moon className="h-5 w-5 text-gray-700" />
              )}
            </button>

            {/* <button
              onClick={handleConsultation}
              className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-6 rounded-full transition duration-300 ease-in-out transform hover:scale-105"
            >
              {t('header.startConsultation')}
            </button> */}

            {user ? (
              <div className="relative" ref={profileMenuRef}>
                <button
                  onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
                  className="flex items-center space-x-2 rounded-full hover:bg-gray-100 p-1 transition-colors"
                >
                  <div className="h-8 w-8 rounded-full overflow-hidden border-2 border-gray-200">
                    {user.avatar ? (
                      <img
                        src={user.avatar}
                        alt={user.name || 'User profile'}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="h-full w-full bg-blue-100 flex items-center justify-center">
                        <User className="h-4 w-4 text-blue-600" />
                      </div>
                    )}
                  </div>
                </button>

                {isProfileMenuOpen && (
                  <div className="absolute right-0 mt-2 w-56 bg-white rounded-lg shadow-lg py-2 z-50 border border-gray-200">
                    <div className="px-4 py-3 border-b border-gray-100">
                      <p className="text-sm font-medium text-gray-900">{user.name || user.email.split('@')[0]}</p>
                      <p className="text-sm text-gray-500 truncate">{user.email}</p>
                    </div>
                    <Link
                      to="/profile"
                      className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 rtl:flex-row-reverse rtl:text-right"
                      onClick={() => setIsProfileMenuOpen(false)}
                    >
                      <User className="h-4 w-4 ltr:mr-2 rtl:ml-2" />
                      {t('header.profile')}
                    </Link>
                    <Link
                      to="/settings"
                      className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 rtl:flex-row-reverse rtl:text-right"
                      onClick={() => setIsProfileMenuOpen(false)}
                    >
                      <Settings className="h-4 w-4 ltr:mr-2 rtl:ml-2" />
                      {t('header.settings')}
                    </Link>
                    <Link
                      to="/chat-history"
                      className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 rtl:flex-row-reverse rtl:text-right"
                      onClick={() => setIsProfileMenuOpen(false)}
                    >
                      <MessageSquare className="h-4 w-4 ltr:mr-2 rtl:ml-2" />
                      {t('header.chatHistory')}
                    </Link>
                    <div className="border-t border-gray-100 my-1"></div>
                    <button
                      onClick={handleSignOut}
                      className="flex w-full items-center px-4 py-2 text-sm text-red-600 hover:bg-gray-100 rtl:flex-row-reverse rtl:text-right"
                    >
                      <LogOut className="h-4 w-4 ltr:mr-2 rtl:ml-2" />
                      {t('header.logout')}
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <Link
                to="/login"
                className="text-sm font-medium text-blue-600 hover:text-blue-800"
              >
                {t('header.login')}
              </Link>
            )}
          </div>

          {/* Mobile Navigation Toggle - now visible on screens below 1026px (lg breakpoint) */}
          <div className="lg:hidden">
            <button
              onClick={toggleMenu}
              className="text-gray-600 hover:text-blue-600 focus:outline-none"
            >
              {isOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation Menu - now visible on screens below 1026px (lg breakpoint) */}
      {isOpen && (
        <div className="lg:hidden bg-white shadow-lg">
          <div className="flex flex-col py-4 px-4">
            <Link
              to="/#features"
              onClick={toggleMenu}
              className="text-gray-700 py-3 border-b border-gray-100 rtl:text-right"
            >
              {t('header.features')}
            </Link>
            <Link
              to="/services"
              onClick={toggleMenu}
              className="text-gray-700 py-3 border-b border-gray-100 rtl:text-right"
            >
              {t('header.services')}
            </Link>
            <Link
              to="/vision"
              onClick={toggleMenu}
              className="text-gray-700 py-3 border-b border-gray-100 rtl:text-right"
            >
              {t('header.ourVision')}
            </Link>
            <Link
              to="/testimonials"
              onClick={toggleMenu}
              className="text-gray-700 py-3 border-b border-gray-100 rtl:text-right"
            >
              {t('header.testimonials')}
            </Link>
            <Link
              to="/blog"
              onClick={toggleMenu}
              className="text-gray-700 py-3 border-b border-gray-100 rtl:text-right"
            >
              {t('header.blog')}
            </Link>
            <Link
              to="/#faq"
              onClick={toggleMenu}
              className="text-gray-700 py-3 mb-4 rtl:text-right"
            >
              {t('header.faq')}
            </Link>
            <div className="flex items-center justify-between mb-4">
              <button
                onClick={() => {
                  handleConsultation();
                  toggleMenu();
                }}
                className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-6 rounded-full"
              >
                {t('header.startConsultation')}
              </button>

              <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <LanguageSelector />

                <button
                  onClick={toggleDarkMode}
                  className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                  aria-label="Toggle dark mode"
                >
                  {isDarkMode ? (
                    <Sun className="h-5 w-5 text-yellow-500" />
                  ) : (
                    <Moon className="h-5 w-5 text-gray-700" />
                  )}
                </button>
              </div>
            </div>

            {user ? (
              <>
                <Link
                  to="/profile"
                  onClick={toggleMenu}
                  className="text-gray-700 py-3 border-t border-gray-100 flex items-center rtl:flex-row-reverse rtl:text-right"
                >
                  <User className="h-4 w-4 ltr:mr-2 rtl:ml-2" />
                  {t('header.profile')}
                </Link>
                <Link
                  to="/chat-history"
                  onClick={toggleMenu}
                  className="text-gray-700 py-3 border-b border-gray-100 flex items-center rtl:flex-row-reverse rtl:text-right"
                >
                  <MessageSquare className="h-4 w-4 ltr:mr-2 rtl:ml-2" />
                  {t('header.chatHistory')}
                </Link>
                <button
                  onClick={() => {
                    handleSignOut();
                    toggleMenu();
                  }}
                  className="text-red-600 py-3 flex items-center w-full rtl:flex-row-reverse rtl:text-right"
                >
                  <LogOut className="h-4 w-4 ltr:mr-2 rtl:ml-2" />
                  {t('header.logout')}
                </button>
              </>
            ) : (
              <Link
                to="/login"
                onClick={toggleMenu}
                className="text-blue-600 py-3 border-t border-gray-100 rtl:text-right block"
              >
                {t('header.login')}
              </Link>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;